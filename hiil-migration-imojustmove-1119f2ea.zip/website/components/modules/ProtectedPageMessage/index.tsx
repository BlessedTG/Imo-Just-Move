import useSetting from "hooks/use-setting";

import Button from "components/partials/Button";

import styles from "./styles.module.scss";

export default function ProtectedPageMessage() {
    const message = useSetting("protected_page_not_authorized_message") ?? "";
    const homeButtonLabel = useSetting("protected_page_home_button_text") ?? "";
    return (
        <div className={styles["protected-page-message"]}>
            <div className={styles["protected-page-message__inner"]}>
                <div
                    className={styles["protected-page-message__message"]}
                    dangerouslySetInnerHTML={{ __html: message }}
                ></div>
                <div className={styles["protected-page-message__actions"]}>
                    <Button url="/">{homeButtonLabel}</Button>
                </div>
            </div>
        </div>
    );
}
