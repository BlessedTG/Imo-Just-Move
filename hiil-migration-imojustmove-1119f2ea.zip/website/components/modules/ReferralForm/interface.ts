import {
    FormConfig,
    FormConfigElementText,
    FormConfigElementTextArea,
} from "interfaces/form-config";

export default interface ComponentInterface {}

export interface ReferralFormConfig extends FormConfig {
    elements: {
        name: FormConfigElementText;
        surname: FormConfigElementText;
        phone_number: FormConfigElementText;
        email: FormConfigElementText;
        location: FormConfigElementText;
        expertise: FormConfigElementText;
        role: FormConfigElementText;
        enrolment_number: FormConfigElementText;
        additional_message: FormConfigElementTextArea;
    };
}
