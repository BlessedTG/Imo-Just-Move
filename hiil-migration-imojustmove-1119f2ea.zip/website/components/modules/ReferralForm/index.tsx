import { FormEvent, useRef, useState } from "react";
import type { SettingKey } from "types/generated";

import type ComponentInterface from "./interface";
import { ReferralFormConfig } from "./interface";

import type { ErrorMessageBag } from "utils/handle-form";
import type { FormHandlerResponse } from "utils/handle-form";
import handleForm from "utils/handle-form";

import useSettings from "hooks/use-settings";

import FormMessage from "components/partials/FormMessage";
import InputField from "components/partials/InputField";
import SubmitButton from "components/partials/SubmitButton";
import TextAreaField from "components/partials/TextAreaField";

import styles from "./styles.module.scss";

function formatErrorMessage(errors: ErrorMessageBag): string {
    let message = "Please correct the following errors:";
    for (const [key, value] of Object.entries(errors)) {
        message += `\n${key}: ${value.join(", ")}`;
    }
    return message;
}

function getFormConfig(
    settings: Record<SettingKey, string>
): ReferralFormConfig {
    const uniqueId = crypto.randomUUID();
    const prefixUid = (key: string) => `${uniqueId}-${key}`;
    return {
        version: "1",
        name: "referral_form",
        submitButtonLabel: settings.referral_form_submit_button_label,
        successTitle: settings.referral_form_success_title,
        successMessage: settings.referral_form_success_message,
        failedTitle: settings.referral_form_error_title,
        failedMessage: settings.referral_form_error_message,
        elements: {
            name: {
                id: prefixUid("name"),
                name: "name",
                type: "text",
                required: true,
                label: settings.referral_form_name_label,
                instruction: settings.referral_form_name_instruction,
            },
            surname: {
                id: prefixUid("surname"),
                name: "surname",
                type: "text",
                required: true,
                label: settings.referral_form_surname_label,
                instruction: settings.referral_form_surname_instruction,
            },
            email: {
                id: prefixUid("email"),
                name: "email",
                type: "email",
                required: false,
                label: settings.referral_form_email_label,
                instruction: settings.referral_form_email_instruction,
            },
            phone_number: {
                id: prefixUid("phone_number"),
                name: "phone_number",
                type: "tel",
                required: true,
                label: settings.referral_form_phone_number_label,
                instruction: settings.referral_form_phone_number_instruction,
            },
            location: {
                id: prefixUid("location"),
                name: "location",
                type: "text",
                required: true,
                label: settings.referral_form_location_label,
                instruction: settings.referral_form_location_instruction,
            },
            expertise: {
                id: prefixUid("expertise"),
                name: "expertise",
                type: "text",
                required: true,
                label: settings.referral_form_expertise_label,
                instruction: settings.referral_form_expertise_instruction,
            },
            role: {
                id: prefixUid("role"),
                name: "role",
                type: "text",
                required: true,
                label: settings.referral_form_role_label,
                instruction: settings.referral_form_role_instruction,
            },
            enrolment_number: {
                id: prefixUid("enrolment_number"),
                name: "enrolment_number",
                type: "text",
                required: false,
                label: settings.referral_form_enrolment_number_label,
                instruction:
                    settings.referral_form_enrolment_number_instruction,
            },
            additional_message: {
                id: prefixUid("additional_message"),
                name: "additional_message",
                type: "textarea",
                required: false,
                label: settings.referral_form_additional_message_label,
                instruction:
                    settings.referral_form_additional_message_instruction,
            },
        },
    };
}

export default function ReferralForm({}: ComponentInterface) {
    const settings = useSettings();
    const formConfig = getFormConfig(settings);

    const formMessageRef = useRef<HTMLDivElement>(null);
    const [formResponse, setFormResponse] =
        useState<FormHandlerResponse | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
        const form = event.currentTarget;
        setIsSubmitting(true);
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        const response = await handleForm(formData);
        if (response.success) {
            form.reset();
        }
        setFormResponse(response);
        formMessageRef?.current?.scrollIntoView();
        setIsSubmitting(false);
    };
    const formAction = process.env.NEXT_PUBLIC_FORM_HANDLER_ENDPOINT;
    const { elements } = formConfig;
    return (
        <form
            action={formAction}
            onSubmit={handleSubmit}
            className={styles["referral-form"]}
        >
            <input type="hidden" name="form_name" value="referral_form" />
            <InputField
                label={elements.name.label}
                instruction={elements.name.instruction}
                type="text"
                id={elements.name.id}
                name={elements.name.name}
                isRequired={elements.name.required}
            />
            <InputField
                label={elements.surname.label}
                instruction={elements.surname.instruction}
                type="text"
                id={elements.surname.id}
                name={elements.surname.name}
                isRequired={elements.surname.required}
            />
            <InputField
                label={elements.phone_number.label}
                instruction={elements.phone_number.instruction}
                type="tel"
                id={elements.phone_number.id}
                name={elements.phone_number.name}
                isRequired={elements.phone_number.required}
            />
            <InputField
                label={elements.email.label}
                instruction={elements.email.instruction}
                type="email"
                id={elements.email.id}
                name={elements.email.name}
                isRequired={elements.email.required}
            />
            <InputField
                label={elements.location.label}
                instruction={elements.location.instruction}
                type="text"
                id={elements.location.id}
                name={elements.location.name}
                isRequired={elements.location.required}
            />
            <InputField
                label={elements.expertise.label}
                instruction={elements.expertise.instruction}
                type="text"
                id={elements.expertise.id}
                name={elements.expertise.name}
                isRequired={elements.expertise.required}
            />
            <InputField
                label={elements.role.label}
                instruction={elements.role.instruction}
                type="text"
                id={elements.role.id}
                name={elements.role.name}
                isRequired={elements.role.required}
            />
            <InputField
                label={elements.enrolment_number.label}
                instruction={elements.enrolment_number.instruction}
                type="text"
                id={elements.enrolment_number.id}
                name={elements.enrolment_number.name}
                gapSize="medium"
                isRequired={elements.enrolment_number.required}
            />
            <TextAreaField
                label={elements.additional_message.label}
                instruction={elements.additional_message.instruction}
                id={elements.additional_message.id}
                name={elements.additional_message.name}
                gapSize="medium"
                isRequired={elements.additional_message.required}
            />

            <SubmitButton
                label={formConfig.submitButtonLabel}
                disabled={isSubmitting}
            />
            <div
                ref={formMessageRef}
                className={styles["referral-form__submit-message"]}
            >
                {formResponse && (
                    <FormMessage
                        status={formResponse.success ? "success" : "error"}
                        title={
                            formResponse.success
                                ? formConfig.successTitle
                                : formConfig.failedTitle
                        }
                        message={
                            formResponse.success
                                ? formConfig.successMessage
                                : formConfig.failedMessage
                        }
                    />
                )}
            </div>
        </form>
    );
}
