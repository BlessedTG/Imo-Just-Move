import { useContext, useEffect } from "react";

import { UIContext } from "../../../context/ui";

import getHomePath from "utils/get-home-path";
import getWithExpiry from "utils/get-with-expiry";
import setWithExpiry from "utils/set-with-expiry";

import useSetting from "hooks/use-setting";

import { LanguageContext } from "components/modules/WithMultilingual";
import Button from "components/partials/Button";

import OverlayContent from "../OverlayContent";

import styles from "./styles.module.scss";

export default function NotificationOverlay() {
    const { setOverlayContent, setOverlayIsClosing } = useContext(UIContext);
    const currentLanguage = useContext(LanguageContext);
    const labelForChangeButton = useSetting(
        "notification_overlay_change_button_label"
    );
    const resumeLabel = useSetting("notification_overlay_resume_button_label");
    const notificationOverlayContent = {
        title: useSetting("notification_overlay_title"),
        description: useSetting("notification_overlay_description"),
    };
    const localStorageIdentifier = "showNotificationOverlay";

    const overlayContent = (
        <OverlayContent overlayContent={notificationOverlayContent}>
            <div className={styles["notification-overlay"]}>
                <Button
                    url={getHomePath(currentLanguage)}
                    theme="secondary"
                    isFluid={true}
                >
                    {labelForChangeButton}
                </Button>
                <Button
                    isFluid={true}
                    onClick={() => setOverlayIsClosing(true)}
                >
                    {resumeLabel}
                </Button>
            </div>
        </OverlayContent>
    );

    useEffect(() => {
        const shouldOverlayOpen = getWithExpiry(localStorageIdentifier);
        // Check if the overlay should open
        if (shouldOverlayOpen) {
            // If it should open, set the overlay content
            setOverlayContent(overlayContent);
            // Also set the overlay to be hidden for the next 24 hours
            setWithExpiry(false, localStorageIdentifier);
        }
    }, []);

    return <></>;
}
