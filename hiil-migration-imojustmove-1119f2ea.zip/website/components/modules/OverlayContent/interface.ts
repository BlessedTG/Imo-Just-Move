import type { ReactElement } from "react";

export default interface ComponentInterface {
    overlayContent: {
        title: string;
        description: string;
        linkLabel?: string;
        linkURL?: string;
        icon?: React.FC<React.SVGProps<SVGSVGElement>>;
    };
    children?: React.ReactNode;
}
