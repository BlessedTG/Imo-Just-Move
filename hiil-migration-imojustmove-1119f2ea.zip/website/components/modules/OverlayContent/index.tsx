import type ComponentInterface from "./interface";

import Button from "../../partials/Button";
import RichContent from "../RichContent";

import styles from "./styles.module.scss";

export default function OverlayContent({
    overlayContent: { title, description, linkLabel, linkURL, icon },
    children,
}: ComponentInterface) {
    const Icon = icon;

    return (
        <>
            <header
                className={styles["overlay-content__header"]}
                data-has-icon={Icon ? true : false}
            >
                <h2 className={styles["overlay-content__title"]}>{title}</h2>
                {Icon && <Icon className={styles["overlay-content__icon"]} />}
            </header>
            <div className={styles["overlay-content__description"]}>
                <RichContent cmsContent={description} />
            </div>

            {children && children}

            {linkURL && linkLabel && (
                <Button url={linkURL} theme="primary" isFluid={true}>
                    {linkLabel}
                </Button>
            )}
        </>
    );
}
