import { useContext } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "context/ui";

import useSetting from "../../../hooks/use-setting";
import useTranslations from "../../../hooks/use-translations";

import Button from "../../partials/Button";
import CardButton from "../../partials/CardButton";
import ReadSpeakerButton from "../../partials/ReadSpeakerButton";
import { LanguageContext } from "../WithMultilingual";

import styles from "./styles.module.scss";

export default function Question({
    question,
    currentStep,
    nextStep,
    previousStep,
}: ComponentInterface) {
    const translations = useTranslations();
    const backButtonLabel = useSetting("back_button_label");
    const currentLanguage = useContext(LanguageContext);
    return (
        <div className={styles["question"]}>
            <div className={styles["question__question-container"]}>
                <div className={styles["question__question-inner"]}>
                    {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                        <div
                            className={
                                styles["question__speaker-button-wrapper"]
                            }
                        >
                            <ReadSpeakerButton />
                        </div>
                    )}
                    <section className={styles["question__question-content"]}>
                        <h1 className={styles["question__question-title"]}>
                            {question.question}
                        </h1>
                        <p className={styles["question__question-subtitle"]}>
                            {`${translations.questionnaire.question} ${currentStep}`}
                        </p>
                    </section>
                    {currentLanguage === "en" && (
                        <div
                            className={styles["question__back-button-wrapper"]}
                        >
                            {/*@TODO Add close overlay when leave the questionnaire */}
                            <Button
                                theme="link"
                                iconPosition="left"
                                hasChevronIcon={true}
                                onClick={previousStep}
                            >
                                {backButtonLabel}
                            </Button>
                        </div>
                    )}
                </div>
            </div>
            <div
                className={styles["question__answer-container"]}
                data-language={currentLanguage}
            >
                {question.answers.length > 0 && (
                    <ul className={styles["question__answer-list"]}>
                        {question.answers.map((answer) => (
                            <li
                                key={`question-${question.question}-answer-${answer.label}`}
                            >
                                <CardButton
                                    key={answer.label}
                                    title={answer.label}
                                    onClick={() => nextStep(answer)}
                                />
                            </li>
                        ))}
                    </ul>
                )}
                <div className={styles["question__back-button-wrapper"]}>
                    {/*@TODO Add close overlay when leave the questionnaire */}
                    <Button
                        theme="link"
                        iconPosition="left"
                        hasChevronIcon={true}
                        onClick={previousStep}
                    >
                        {backButtonLabel}
                    </Button>
                </div>
                <div className={styles["question__answer-back-button-wrapper"]}>
                    {/*@TODO Add close overlay when leave the questionnaire */}
                    <Button
                        theme="link"
                        iconPosition="left"
                        hasChevronIcon={true}
                        onClick={previousStep}
                    >
                        {backButtonLabel}
                    </Button>
                </div>
            </div>
        </div>
    );
}
