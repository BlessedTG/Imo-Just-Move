import type {
    PreparedAnswer,
    PreparedQuestion,
} from "../../flexibles/Questions/interface";

export default interface ComponentInterface {
    question: PreparedQuestion;
    currentStep: number;
    nextStep: (answer: PreparedAnswer) => void;
    previousStep: () => void;
}
