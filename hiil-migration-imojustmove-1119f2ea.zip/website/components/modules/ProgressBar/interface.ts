export default interface ComponentInterface {
    activeStep: number;
    steps: string[];
}
