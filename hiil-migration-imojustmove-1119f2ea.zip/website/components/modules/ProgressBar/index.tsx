import type ComponentInterface from "./interface";

import styles from "./styles.module.scss";

export default function ProgressBar({ activeStep, steps }: ComponentInterface) {
    return (
        <div className={styles["progress-bar"]}>
            <ol className={styles["progress-bar__list"]}>
                {steps.map((step, index) => (
                    <li
                        className={styles["progress-bar__list-item"]}
                        key={`${step}-${index}`}
                        aria-current={activeStep === index + 1 ? true : false}
                        data-step-is-finished={
                            activeStep > index + 1 ? true : false
                        }
                    >
                        <span className={styles["progress-bar__text"]}>
                            {step}
                        </span>
                    </li>
                ))}
            </ol>
        </div>
    );
}
