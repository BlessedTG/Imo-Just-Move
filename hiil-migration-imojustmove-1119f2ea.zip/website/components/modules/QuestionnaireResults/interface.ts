import { Problem } from "../../../content/problems-interfaces";
import type {
    GivenAnswer,
    PreparedAnswer,
    PreparedQuestion,
} from "../../flexibles/Questions/interface";

export default interface ComponentInterface {
    problem: Problem | null;
    givenAnswers: GivenAnswer[];
    restartButtonLabel: string;
    resultsTitle: string;
    outcomeButtonLabel: string;
    analysisTitle: string;
    analysisResultSubtitle: string;
    onRestart: () => void;
}
