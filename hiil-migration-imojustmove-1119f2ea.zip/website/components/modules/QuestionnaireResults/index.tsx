import Link from "next/link";
import { useContext } from "react";

import {
    GivenAnswer,
    PreparedAnswer,
} from "../../flexibles/Questions/interface";
import type ComponentInterface from "./interface";

import Button from "../../partials/Button";
import ReadSpeakerButton from "../../partials/ReadSpeakerButton";
import { LanguageContext } from "../WithMultilingual";

import styles from "./styles.module.scss";

export default function QuestionnaireResult({
    problem,
    givenAnswers,
    restartButtonLabel,
    resultsTitle,
    outcomeButtonLabel,
    analysisTitle,
    analysisResultSubtitle,
    onRestart,
}: ComponentInterface) {
    // Get the associated problem from the answers of a question
    const getProblemFromAnswers = (answers: PreparedAnswer[] | undefined) => {
        if (!answers) return null;

        return answers.find((answer) => answer.problem)?.problem;
    };
    const currentLanguage = useContext(LanguageContext);
    return (
        <div className={styles["questionnaire-results"]}>
            <div className={styles["questionnaire-results__result-container"]}>
                <div className={styles["questionnaire-results__result-inner"]}>
                    {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                        <div
                            className={
                                styles[
                                    "questionnaire-results__speaker-button-wrapper"
                                ]
                            }
                        >
                            <ReadSpeakerButton />
                        </div>
                    )}
                    <section
                        className={
                            styles["questionnaire-results__result-content"]
                        }
                    >
                        <h1
                            className={
                                styles["questionnaire-results__result-title"]
                            }
                        >
                            {resultsTitle}
                            <span
                                className={
                                    styles[
                                        "questionnaire-results__problem-title"
                                    ]
                                }
                            >
                                {problem?.attributes?.title}
                            </span>
                        </h1>
                        {currentLanguage === "ar" && (
                            <div
                                className={
                                    styles[
                                        "questionnaire-results__outcome-button-wrapper"
                                    ]
                                }
                                data-language="ar"
                            >
                                <Button
                                    url={problem?.attributes?.url}
                                    isFluid={false}
                                >
                                    {outcomeButtonLabel}
                                </Button>
                            </div>
                        )}
                    </section>
                    {currentLanguage === "en" && (
                        <div
                            className={
                                styles[
                                    "questionnaire-results__button-container"
                                ]
                            }
                        >
                            <Button
                                theme="link"
                                onClick={onRestart}
                                hasChevronIcon={false}
                            >
                                {restartButtonLabel}
                            </Button>
                        </div>
                    )}
                </div>
            </div>

            <div
                className={styles["questionnaire-results__analysis-container"]}
            >
                <h2 className={styles["questionnaire-results__analysis-title"]}>
                    {analysisTitle}
                </h2>
                {givenAnswers.length > 0 && (
                    <ol
                        className={
                            styles["questionnaire-results__analysis-list"]
                        }
                    >
                        {
                            // Show all given answers with the related question and answers
                            givenAnswers.map((givenAnswer: GivenAnswer) => (
                                <li
                                    className={
                                        styles[
                                            "questionnaire-results__analysis-list-item"
                                        ]
                                    }
                                    key={`analysis-item-question-${givenAnswer.question}`}
                                >
                                    <h3
                                        className={
                                            styles[
                                                "questionnaire-results__analysis-item-question"
                                            ]
                                        }
                                    >
                                        {givenAnswer.question}
                                    </h3>
                                    {givenAnswer.answers.length > 0 && (
                                        <ul
                                            className={
                                                styles[
                                                    "questionnaire-results__analysis-answer-list"
                                                ]
                                            }
                                        >
                                            {
                                                // Show all answers for the question related to the given answer
                                                givenAnswer.answers.map(
                                                    (answer) => (
                                                        <li
                                                            key={`analysis-item-answer-${answer.label}`}
                                                            className={
                                                                styles[
                                                                    "questionnaire-results__analysis-item-answer"
                                                                ]
                                                            }
                                                            aria-current={
                                                                answer.label ===
                                                                givenAnswer
                                                                    .givenAnswer
                                                                    .label
                                                            }
                                                        >
                                                            {answer.label}
                                                        </li>
                                                    )
                                                )
                                            }
                                        </ul>
                                    )}
                                    <p
                                        className={
                                            styles[
                                                "questionnaire-results__analysis-item-problem"
                                            ]
                                        }
                                    >
                                        {analysisResultSubtitle}{" "}
                                        {
                                            // Get the problem from the answers of the question to show the linked problem
                                            getProblemFromAnswers(
                                                givenAnswer?.answers
                                            ) && (
                                                <Link
                                                    href={
                                                        getProblemFromAnswers(
                                                            givenAnswer?.answers
                                                        )?.attributes.url ?? ""
                                                    }
                                                    className={
                                                        styles[
                                                            "questionnaire-results__analysis-item-problem-link"
                                                        ]
                                                    }
                                                >
                                                    {getProblemFromAnswers(
                                                        givenAnswer?.answers
                                                    )?.attributes?.title ?? ""}
                                                </Link>
                                            )
                                        }
                                    </p>
                                </li>
                            ))
                        }
                    </ol>
                )}

                {currentLanguage === "en" && (
                    <div
                        className={
                            styles[
                                "questionnaire-results__outcome-button-wrapper"
                            ]
                        }
                    >
                        <Button url={problem?.attributes?.url} isFluid={false}>
                            {outcomeButtonLabel}
                        </Button>
                    </div>
                )}

                {currentLanguage === "ar" && (
                    <div
                        className={
                            styles["questionnaire-results__button-container"]
                        }
                        data-language="ar"
                    >
                        <Button
                            theme="link"
                            onClick={onRestart}
                            hasChevronIcon={false}
                        >
                            {restartButtonLabel}
                        </Button>
                    </div>
                )}
            </div>
        </div>
    );
}
