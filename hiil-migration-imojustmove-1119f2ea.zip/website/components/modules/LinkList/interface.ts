import type { Link } from "../../../interfaces/link";

export default interface ComponentInterface {
    links: Link[];
}
