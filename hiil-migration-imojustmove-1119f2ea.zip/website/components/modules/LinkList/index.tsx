import type ComponentInterface from "./interface";

import Button from "components/partials/Button";

import styles from "./styles.module.scss";

export default function LinkList({ links }: ComponentInterface) {
    return (
        <ul className={styles["link-list"]}>
            {links.map(
                ({
                    attributes: {
                        label,
                        url,
                        urlType,
                        externalUrl,
                        targetBlank,
                    },
                }) => (
                    <li
                        key={`${label}-${url}`}
                        className={styles["link-list__item"]}
                    >
                        <Button
                            url={urlType === "external" ? externalUrl : url}
                            targetBlank={targetBlank}
                            isFluid={true}
                        >
                            {label}
                        </Button>
                    </li>
                )
            )}
        </ul>
    );
}
