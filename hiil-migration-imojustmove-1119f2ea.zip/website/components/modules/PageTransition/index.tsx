import { useRouter } from "next/router";
import { useEffect, useState } from "react";

import type ComponentInterface from "./interface";

export default function PageTransition({ children }: ComponentInterface) {
    const router = useRouter();
    const [showContent, setShowContent] = useState(true);

    /**
     * Handle simple page transition without any delays
     */
    useEffect(() => {
        const handleRouteStart = (url: String) => {
            // Bail out if the URL is the same as the clicked link.
            if (url === window.location.pathname) return () => {};

            // Disable smooth scroll to ensure no scrolling is visible while transitioning to next page.
            document.documentElement.style.scrollBehavior = "auto";
            setShowContent(false);
        };

        const handleRouteComplete = () => {
            setShowContent(true);
            document.documentElement.style.scrollBehavior = "smooth";
        };

        router.events.on("routeChangeStart", handleRouteStart);
        router.events.on("routeChangeComplete", handleRouteComplete);

        return () => {
            router.events.off("routeChangeStart", handleRouteStart);
            router.events.off("routeChangeComplete", handleRouteComplete);
        };
    }, [router]);

    return (
        <div data-page-transition-show-content={showContent}>{children}</div>
    );
}
