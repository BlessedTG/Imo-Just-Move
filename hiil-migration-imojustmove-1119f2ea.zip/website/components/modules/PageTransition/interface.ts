export default interface ComponentInterface {
    children: React.ReactNode;
}
