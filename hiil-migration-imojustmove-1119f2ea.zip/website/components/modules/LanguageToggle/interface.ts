import type { LocalizedUrls } from "../../../utils/get-translation-urls";

export default interface ComponentInterface {
    translationUrls: LocalizedUrls;
    isInOverlay?: boolean;
}
