import Link from "next/link";
import { useRouter } from "next/router";
import { useContext } from "react";

import type ComponentInterface from "./interface";

import useTranslation from "hooks/use-translations";

import { LanguageContext } from "../WithMultilingual";

import styles from "./styles.module.scss";

export default function LanguageToggle({
    translationUrls,
    isInOverlay = false,
}: ComponentInterface) {
    const translations = useTranslation();

    const currentLanguage = useContext(LanguageContext);
    const router = useRouter();
    const currentPath = router.asPath;

    const isAr = currentLanguage === "ar";
    const isEn = currentLanguage === "en";

    return (
        <span
            className={styles["language-toggle"]}
            data-current-language={currentLanguage}
            data-is-in-overlay={isInOverlay}
        >
            <Link
                href={isAr ? currentPath : translationUrls.ar}
                className={styles["language-toggle__link"]}
                aria-current={isAr ? "page" : false}
                hrefLang="ar-TN"
                lang="ar-TN"
            >
                <span
                    className={styles["language-toggle__link-label"]}
                    aria-hidden="true"
                >
                    TUN
                </span>
                <span className="sr-only">
                    {translations.languageToggle.goToARPage}
                </span>
            </Link>

            <span>/</span>

            <Link
                href={isEn ? currentPath : translationUrls.en}
                className={styles["language-toggle__link"]}
                hrefLang="en-US"
                lang="en-US"
                aria-current={isEn ? "page" : false}
            >
                <span
                    className={styles["language-toggle__link-label"]}
                    aria-hidden="true"
                >
                    EN
                </span>
                <span className="sr-only">
                    {translations.languageToggle.goToENPage}
                </span>
            </Link>
        </span>
    );
}
