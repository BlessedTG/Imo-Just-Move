import { useContext } from "react";

import { UIContext } from "../../../context/ui";

import useSetting from "../../../hooks/use-setting";
import useTranslations from "../../../hooks/use-translations";

import Phone from "public/icons/phone.svg";

import OverlayContent from "../OverlayContent";

import styles from "./styles.module.scss";

export default function EmergencyOverlayToggle() {
    const translations = useTranslations();
    const { setOverlayContent, overlayContent } = useContext(UIContext);

    const emergencyOverlayContent = {
        title: useSetting("emergency_overlay_title"),
        description: useSetting("emergency_overlay_description"),
        linkLabel: useSetting("emergency_overlay_link_label"),
        linkURL: `tel:${useSetting("emergency_overlay_phone_number")}`,
    };

    const emergencyOverlay = (
        <OverlayContent overlayContent={emergencyOverlayContent} />
    );
    return (
        <button
            className={styles["emergency-overlay-toggle"]}
            type="button"
            onClick={() => setOverlayContent(emergencyOverlay)}
            aria-expanded={overlayContent === null ? "false" : "true"}
        >
            <Phone
                className={styles["emergency-overlay-toggle__button-icon"]}
            />
            <span className="sr-only">
                {translations.emergencyOverlayToggle.openOverlay}
            </span>
        </button>
    );
}
