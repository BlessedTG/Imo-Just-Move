import FocusTrap from "focus-trap-react";
import { useRouter } from "next/router";
import { useContext, useEffect, useState, useCallback } from "react";
import type { MouseEvent } from "react";

import type OverlayProps from "./interface";

import { UIContext } from "../../../context/ui";

import useTranslations from "../../../hooks/use-translations";

import CloseIcon from "../../../public/icons/close.svg";

import styles from "./styles.module.scss";

export default function Overlay({ children }: OverlayProps) {
    const router = useRouter();

    const {
        focusSourceElement,
        setFocusSourceElement,
        overlayContent,
        setOverlayContent,
        overlayIsClosing,
        setOverlayIsClosing,
    } = useContext(UIContext);
    const [showContent, setShowContent] = useState<boolean>(false);

    const translations = useTranslations();

    const closeOverlay = useCallback(() => {
        setOverlayIsClosing(true);
    }, [setOverlayIsClosing]);

    const closeOnButtonClick = useCallback(
        (e: MouseEvent<HTMLButtonElement | HTMLDivElement> | KeyboardEvent) => {
            e.preventDefault();
            closeOverlay();
        },
        [closeOverlay]
    );

    const handleAnimationEnd = () => {
        if (!overlayIsClosing) {
            setShowContent(true);
            return;
        }

        setShowContent(false);
        setOverlayContent(null);
        setOverlayIsClosing(false);

        if (focusSourceElement) {
            // Return focus to the element that originally opened the modal.
            focusSourceElement.focus({
                preventScroll: true,
            });
            setFocusSourceElement(null);
        }
    };

    /**
     * Allow closing of the overlay with Escape.
     * This also traps the focus inside the modal (browser chrome stays available).
     */
    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.code === "Escape") {
                closeOnButtonClick(event);
                window.removeEventListener("keydown", handleKeyDown);
            }
        };
        window.addEventListener("keydown", handleKeyDown);

        const handleRouteChangeStart = () => closeOverlay();
        router.events.on("routeChangeStart", handleRouteChangeStart);
        return () => {
            window.removeEventListener("keydown", handleKeyDown);
            router.events.off("routeChangeStart", handleRouteChangeStart);
        };
    }, [
        overlayContent,
        setOverlayContent,
        closeOverlay,
        closeOnButtonClick,
        router.events,
    ]);

    return (
        <FocusTrap
            active={showContent}
            focusTrapOptions={{
                preventScroll: true,
                allowOutsideClick: true,
            }}
        >
            <div>
                <div
                    className={styles["overlay__page-mask"]}
                    data-is-closing={overlayIsClosing}
                    onClick={closeOverlay}
                />

                <div
                    id="overlay-widget"
                    aria-modal="true"
                    className={styles["overlay"]}
                    data-is-closing={overlayIsClosing}
                    onAnimationEnd={handleAnimationEnd}
                    data-in-overlay="true"
                >
                    <div className={styles["overlay__contents"]}>
                        {showContent && (
                            <>
                                <div
                                    className={
                                        styles["overlay__close-button-bar"]
                                    }
                                >
                                    <button
                                        className={
                                            styles["overlay__close-button"]
                                        }
                                        onClick={closeOnButtonClick}
                                        type="button"
                                        aria-label={translations.overlay.close}
                                    >
                                        <CloseIcon
                                            className={
                                                styles["overlay__close-icon"]
                                            }
                                        />
                                    </button>
                                </div>
                                <div
                                    className={
                                        styles["overlay__contents-inner"]
                                    }
                                >
                                    {children}
                                </div>
                            </>
                        )}
                    </div>
                </div>
            </div>
        </FocusTrap>
    );
}
