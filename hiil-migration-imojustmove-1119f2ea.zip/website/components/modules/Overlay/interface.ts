import React from "react";

export default interface Overlay {
    children: React.ReactNode;
    hasFilterElement?: boolean;
}
