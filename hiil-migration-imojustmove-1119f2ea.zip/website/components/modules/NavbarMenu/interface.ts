import type { MenuItem } from "../../../content/menus-interface";

import type { LocalizedUrls } from "../../../utils/get-translation-urls";

export default interface ComponentInterface {
    menuItems: MenuItem[];
    translationUrls: LocalizedUrls;
}
