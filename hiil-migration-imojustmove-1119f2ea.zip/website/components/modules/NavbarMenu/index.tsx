import type ComponentInterface from "./interface";

import LanguageToggle from "../LanguageToggle";
import NavList from "../NavList";

import styles from "./styles.module.scss";

export default function NavbarMenu({
    menuItems,
    translationUrls,
}: ComponentInterface) {
    return (
        <nav className={styles["navbar-menu"]} role="navigation">
            <div className={styles["navbar-menu__content"]}>
                <NavList type="primary" menuItems={menuItems} id={"main"} />
            </div>
            {process.env.NEXT_PUBLIC_SHOW_LANGUAGE_TOGGLE === "true" && (
                <div className={styles["navbar-menu__content"]}>
                    <span className={styles["navbar-menu__language-toggle"]}>
                        <LanguageToggle translationUrls={translationUrls} />
                    </span>
                </div>
            )}
        </nav>
    );
}
