import {
    FormConfig,
    FormConfigElementHidden,
    FormConfigElementText,
    FormConfigElementTextArea,
} from "interfaces/form-config";

export default interface ComponentInterface {
    problem?: string;
    outcome?: string;
}

export interface IntakeFormConfig extends FormConfig {
    elements: {
        owner_uuid: FormConfigElementHidden;
        name: FormConfigElementText;
        surname: FormConfigElementText;
        phone_number: FormConfigElementText;
        email: FormConfigElementText;
        location: FormConfigElementText;
        additional_message: FormConfigElementTextArea;
    };
}
