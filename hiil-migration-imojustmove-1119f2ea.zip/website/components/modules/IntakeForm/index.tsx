import { FormEvent, useContext, useRef, useState } from "react";
import { SettingKey } from "types/generated";

import ComponentInterface, { IntakeFormConfig } from "./interface";

import { UserLoginContext } from "context/user-login";

import handleForm, { FormHandlerResponse } from "utils/handle-form";

import useSettings from "hooks/use-settings";

import FormMessage from "components/partials/FormMessage";
import InputField from "components/partials/InputField";
import SubmitButton from "components/partials/SubmitButton";
import TextAreaField from "components/partials/TextAreaField";

import styles from "./styles.module.scss";

function getFormConfig(settings: Record<SettingKey, string>): IntakeFormConfig {
    const uniqueId = crypto.randomUUID();
    const prefixUid = (key: string) => `${uniqueId}-${key}`;
    return {
        version: "1",
        name: "intake_form",
        successTitle: settings.intake_form_success_title,
        successMessage: settings.intake_form_success_message,
        failedTitle: settings.intake_form_error_title,
        failedMessage: settings.intake_form_error_message,
        submitButtonLabel: settings.intake_form_submit_button_label,
        elements: {
            owner_uuid: {
                id: prefixUid("owner_uuid"),
                name: "owner_uuid",
                type: "hidden",
                required: false,
            },
            name: {
                id: prefixUid("name"),
                name: "name",
                type: "text",
                required: true,
                label: settings.intake_form_name_label,
                instruction: settings.intake_form_name_instruction,
            },
            surname: {
                id: prefixUid("surname"),
                name: "surname",
                type: "text",
                required: true,
                label: settings.intake_form_surname_label,
                instruction: settings.intake_form_surname_instruction,
            },
            email: {
                id: prefixUid("email"),
                name: "email",
                type: "email",
                required: true,
                label: settings.intake_form_email_label,
                instruction: settings.intake_form_email_instruction,
            },
            phone_number: {
                id: prefixUid("phone_number"),
                name: "phone_number",
                type: "tel",
                required: false,
                label: settings.intake_form_phone_number_label,
                instruction: settings.intake_form_phone_number_instruction,
            },
            location: {
                id: prefixUid("location"),
                name: "location",
                type: "text",
                required: true,
                label: settings.intake_form_location_label,
                instruction: settings.intake_form_location_instruction,
            },
            additional_message: {
                id: prefixUid("additional_message"),
                name: "additional_message",
                type: "textarea",
                required: false,
                label: settings.intake_form_additional_message_label,
                instruction:
                    settings.intake_form_additional_message_instruction,
            },
        },
    };
}

export default function IntakeForm({ problem, outcome }: ComponentInterface) {
    const { currentUser } = useContext(UserLoginContext);
    const settings = useSettings();
    const formConfig = getFormConfig(settings);

    const formMessageRef = useRef<HTMLDivElement>(null);
    const [formResponse, setFormResponse] =
        useState<FormHandlerResponse | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
        const form = event.currentTarget;
        setIsSubmitting(true);
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        const response = await handleForm(formData);
        if (response.success) {
            form.reset();
        }
        setFormResponse(response);
        formMessageRef?.current?.scrollIntoView();
        setIsSubmitting(false);
    };
    const formAction = process.env.NEXT_PUBLIC_FORM_HANDLER_ENDPOINT;
    const { elements } = formConfig;
    return (
        <form
            action={formAction}
            onSubmit={handleSubmit}
            className={styles["intake-form"]}
        >
            <input type="hidden" name="form_name" value={formConfig.name} />
            {currentUser && (
                <input
                    type="hidden"
                    name={elements.owner_uuid.name}
                    value={currentUser.uuid}
                />
            )}
            {problem && <input type="hidden" name="problem" value={problem} />}
            {outcome && <input type="hidden" name="outcome" value={outcome} />}
            <InputField
                label={elements.name.label}
                instruction={elements.name.instruction}
                type="text"
                name={elements.name.name}
                id={elements.name.id}
                isRequired={elements.name.required}
            />
            <InputField
                label={elements.surname.label}
                instruction={elements.surname.instruction}
                type="text"
                id={elements.surname.id}
                name={elements.surname.name}
                isRequired={elements.surname.required}
            />
            <InputField
                label={elements.email.label}
                type="email"
                id={elements.email.id}
                name={elements.email.name}
                instruction={elements.email.instruction}
                isRequired={elements.email.required}
            />
            <InputField
                label={elements.phone_number.label}
                instruction={elements.phone_number.instruction}
                type="tel"
                id={elements.phone_number.id}
                name={elements.phone_number.name}
                isRequired={elements.phone_number.required}
            />
            <InputField
                label={elements.location.label}
                instruction={elements.location.instruction}
                type="text"
                id={elements.location.id}
                name={elements.location.name}
                isRequired={true}
                gapSize="medium"
            />

            <TextAreaField
                label={elements.additional_message.label}
                id={elements.additional_message.id}
                name={elements.additional_message.name}
                instruction={elements.additional_message.instruction}
                isRequired={elements.additional_message.required}
            />

            <SubmitButton
                label={formConfig.submitButtonLabel}
                disabled={isSubmitting}
            />

            <div
                ref={formMessageRef}
                className={styles["intake-form__submit-message"]}
            >
                {formResponse && (
                    <FormMessage
                        status={formResponse.success ? "success" : "error"}
                        title={
                            formResponse.success
                                ? formConfig.successTitle
                                : formConfig.failedTitle
                        }
                        message={
                            formResponse.success
                                ? formConfig.successMessage
                                : formConfig.failedMessage
                        }
                    />
                )}
            </div>
        </form>
    );
}
