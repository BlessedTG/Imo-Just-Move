import CookiesPackage from "@grrr/cookie-consent";
import { useContext, useEffect, useMemo, useRef } from "react";
import type { DOMAttributes } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "../../../context/ui";

import useSettings from "hooks/use-settings";

interface CookiesFromPackage {
    accepted: boolean;
    id: string;
}

type CookieConsentElement = {
    ref?: React.RefObject<CookieConsentElement>;
    preferences: {
        get: () => {};
        getAll: () => {};
        getState: () => {};
        hasPreferences: () => {};
        store: () => {};
    };
    show: () => {};
    hide: () => {};
    on: (type: string, payload: (cookies: [CookiesFromPackage]) => void) => {};
};

type CustomElement<T> = Partial<T & DOMAttributes<T>>;

declare global {
    namespace JSX {
        interface IntrinsicElements {
            ["cookie-consent"]: CustomElement<CookieConsentElement>;
        }
    }
}

export default function CookieConsent({}: ComponentInterface) {
    const settings = useSettings();

    const {
        setCookiesAccepted,
        cookiesAccepted,
        setShowCookieConsent,
        showCookieConsent,
    } = useContext(UIContext);

    // We cannot use the HTMLELement here because the custom element
    // contains custom properties on the element itself that we set.
    const ref = useRef<CookieConsentElement>(null);

    useEffect(() => {
        // Only define cookie-consent when it hasn't been done yet
        if (window.customElements.get("cookie-consent") === undefined) {
            window.customElements.define("cookie-consent", CookiesPackage);
        }

        // Function is executed when custom element is mounted
        window.customElements.whenDefined("cookie-consent").then(() => {
            if (!ref.current) return;
            // Don't show if cookie preferences are saved
            // Show if no cookie preferences have been saved
            // SetTimeout is used to show the popup using a transition
            ref.current.preferences.hasPreferences()
                ? setTimeout(() => ref.current && ref.current.hide(), 100)
                : setTimeout(() => ref.current && ref.current.show(), 100);
        });
    }, []);

    const cookieConsent = useMemo(
        () => ({
            labels: {
                title: settings.cookiebanner_title || "Cookies",
                description:
                    settings.cookiebanner_introduction ||
                    "This website uses cookies",
                button: {
                    default:
                        settings.cookiebanner_save_preferences_label ||
                        "Save Preferences",
                    acceptAll:
                        settings.cookiebanner_accept_all_label || "Accept all",
                },
                aria: {
                    button: "Confirm cookie settings",
                    tabList: "List with cookie types",
                    tabToggle: "Toggle cookie tab",
                },
            },
            cookies: [
                {
                    id: "functional",
                    label:
                        settings.cookiebanner_functional_cookies_name ||
                        "Functional",
                    description:
                        settings.cookiebanner_functional_cookies_description ||
                        "Functional cookies info",
                    required: true,
                },
                {
                    id: "marketing",
                    label:
                        settings.cookiebanner_marketing_cookies_name ||
                        "Marketing",
                    description:
                        settings.cookiebanner_marketing_cookies_description ||
                        "Marketing cookies info",
                    checked: false,
                },
            ],
        }),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        []
    );

    // Function that gets executed once one of the cookie states gets updated
    useEffect(() => {
        if (!ref.current) return;
        // Function that fires on the custom update event
        ref.current.on("update", (cookies) => {
            // Find marketing cookie
            const marketingCookie = cookies.find(
                (cookie: CookiesFromPackage) => cookie.id == "marketing"
            );
            // Find functional cookie
            const functionalCookie = cookies.find(
                (cookie: CookiesFromPackage) => cookie.id == "functional"
            );
            // Set the cookies in UIContext to the new value
            setCookiesAccepted({
                marketingCookiesAccepted: marketingCookie?.accepted || false,
                functionalCookiesAccepted: functionalCookie?.accepted || false,
            });

            setShowCookieConsent(false);
        });

        showCookieConsent ? ref.current.show() : ref.current.hide();
    }, [
        cookieConsent,
        setCookiesAccepted,
        showCookieConsent,
        setShowCookieConsent,
    ]);

    return (
        <cookie-consent
            ref={ref}
            data-title={cookieConsent.labels.title}
            data-description={cookieConsent.labels.description}
            data-saveButtonText={cookieConsent.labels.button.default}
            data-cookies={JSON.stringify(cookieConsent.cookies)}
        />
    );
}
