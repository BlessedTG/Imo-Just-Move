export default interface ComponentInterface {}
