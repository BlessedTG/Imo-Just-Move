import Link from "next/link";
import { useRouter } from "next/router";
import { useContext, useEffect, useState } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "../../../context/ui";

import styles from "./styles.module.scss";

export default function Nav({ menuItems }: ComponentInterface) {
    const router = useRouter();
    const { menuIsOpen, setMenuIsOpen } = useContext(UIContext);
    const [pathName, setPathName] = useState(
        typeof window === "undefined" ? "" : window.location.pathname
    );

    /**
     * To update the PathName, we have to set the state with
     * the PathName again, after navigating to a different page.
     */
    useEffect(() => {
        setPathName(window.location.pathname);
        const handleRouteChangeComplete = () => {
            setPathName(window.location.pathname);
            setMenuIsOpen(false);
        };
        router.events.on("routeChangeComplete", handleRouteChangeComplete);
        return () => {
            router.events.off("routeChangeComplete", handleRouteChangeComplete);
        };
    }, [router.events, setMenuIsOpen]);

    return (
        <nav className={styles["site-menu"]} role="navigation">
            <ul className={styles["site-menu__list"]}>
                {menuItems?.map(({ attributes: { name, value } }) => (
                    <li
                        key={`navigation-item-${value}`}
                        className={styles["site-menu__item"]}
                    >
                        <Link
                            href={value}
                            className={styles["site-menu__link"]}
                            aria-current={pathName === `${value}/`}
                            tabIndex={menuIsOpen ? 0 : -1}
                        >
                            {name}
                        </Link>
                    </li>
                ))}
            </ul>
        </nav>
    );
}
