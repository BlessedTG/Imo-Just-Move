import Button from "components/partials/Button/interface";

export default interface ComponentInterface {
    label: string;
    theme?: Button["theme"];
}
