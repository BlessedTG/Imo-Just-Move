import { useContext } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "../../../context/ui";

import useSetting from "hooks/use-setting";

import Button from "components/partials/Button";

import OverlayContent from "../OverlayContent";
import ReferralForm from "../ReferralForm";

import styles from "./styles.module.scss";

export default function ReferralFormOverlayToggle({
    label,
    theme = "secondary-light",
}: ComponentInterface) {
    const { setOverlayContent, overlayContent } = useContext(UIContext);
    const referralFormOverlayContent = {
        title: useSetting("referral_form_title"),
        description: useSetting("referral_form_description"),
    };

    const referralFormOverlay = (
        <OverlayContent overlayContent={referralFormOverlayContent}>
            <ReferralForm />
        </OverlayContent>
    );

    return (
        <div className={styles["referral-form-overlay-toggle"]}>
            <Button
                theme={theme}
                onClick={() => setOverlayContent(referralFormOverlay)}
                aria-expanded={overlayContent === null ? "false" : "true"}
            >
                {label}
            </Button>
        </div>
    );
}
