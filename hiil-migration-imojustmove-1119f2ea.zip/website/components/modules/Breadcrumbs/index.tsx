import Link from "next/link";

import type ComponentInterface from "./interface";

import ChevronRightIcon from "../../../public/icons/chevron-right.svg";

import styles from "./styles.module.scss";

export default function Breadcrumbs({ breadcrumbs }: ComponentInterface) {
    if (!breadcrumbs.length) {
        return null;
    }

    const formattedBreadcrumbs = breadcrumbs.map((breadcrumb) => {
        // Remove spaces
        const labelWithSpaces = breadcrumb.label.replace(/-/g, " ");

        return {
            label: labelWithSpaces,
            url: breadcrumb.url,
        };
    });

    return (
        <nav className={styles["breadcrumbs"]}>
            <ol
                aria-labelledby="breadcrumb-label"
                className={styles["breadcrumbs__list"]}
            >
                {formattedBreadcrumbs.map((breadcrumb, index) => (
                    <li
                        key={breadcrumb.url}
                        className={styles["breadcrumbs__item"]}
                        aria-current={index === breadcrumbs.length - 1}
                    >
                        <Link
                            className={styles["breadcrumbs__link"]}
                            href={breadcrumb.url}
                        >
                            {breadcrumb.label}
                        </Link>
                        {index !== breadcrumbs.length - 1 && (
                            <span
                                aria-hidden="true"
                                className={styles["breadcrumbs__separator"]}
                            >
                                <ChevronRightIcon />
                            </span>
                        )}
                    </li>
                ))}
            </ol>
        </nav>
    );
}
