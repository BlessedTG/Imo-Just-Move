export interface Breadcrumb {
    label: string;
    url: string;
}

export default interface ComponentInterface {
    breadcrumbs: Breadcrumb[];
}
