import { ChangeEvent, SyntheticEvent, useState, useContext } from "react";

import type ComponentInterface from "./interface";

import useSetting from "hooks/use-setting";

import Button from "components/partials/Button";

import ChevronDown from "../../../public/icons/chevron-down.svg";

import { LanguageContext } from "../WithMultilingual";

import styles from "./styles.module.scss";

export default function ReferralFilter({
    regions,
    activeRegion,
    onRegionChange,
}: ComponentInterface) {
    const [showRegions, setShowRegions] = useState<boolean>(false);
    const currentLanguage = useContext(LanguageContext);

    const toggleDropdown = (event: SyntheticEvent) => {
        event.preventDefault();
        setShowRegions(!showRegions);
    };

    const handleRegionChange = (event: ChangeEvent<HTMLInputElement>) => {
        onRegionChange(event.target.value as string);
        toggleDropdown(event);
    };

    return (
        <form className={styles["referral-filter"]}>
            <div className={styles["referral-filter__filter-button-wrapper"]}>
                <Button
                    icon={ChevronDown}
                    label={useSetting("referral_filter_label")}
                    theme="secondary-light"
                    onClick={toggleDropdown}
                    rotateIcon={showRegions}
                    aria-expanded={showRegions}
                    aria-controls="referral-filter__dropdown"
                >
                    {useSetting("referral_filter_label")}
                </Button>
            </div>
            <fieldset
                className={styles["referral-filter__dropdown"]}
                id="referral-filter__dropdown"
                data-show-regions={showRegions}
            >
                <legend className={styles["referral-filter__legend"]}>
                    {currentLanguage === "en"
                        ? "Referral filter"
                        : "Referral filter translation"}
                </legend>

                <div
                    className={styles["referral-filter__dropdown-item"]}
                    key={`region-all-regions`}
                >
                    <input
                        className={styles["referral-filter__input"]}
                        type="radio"
                        id="All-regions"
                        name="outcome-region-filter"
                        onChange={handleRegionChange}
                        value="All-regions"
                        checked={activeRegion === "All-regions"}
                    />
                    <label
                        className={styles["referral-filter__label"]}
                        htmlFor="All-regions"
                    >
                        {useSetting("referral_filter_all_option")}
                    </label>
                </div>

                {regions.map((region) => (
                    <div
                        key={`region-${region}`}
                        className={styles["referral-filter__dropdown-item"]}
                    >
                        <input
                            className={styles["referral-filter__input"]}
                            type="radio"
                            id={region.slug[currentLanguage]!}
                            name="outcome-region-filter"
                            onChange={handleRegionChange}
                            checked={
                                activeRegion === region.slug[currentLanguage]
                            }
                            value={region.slug[currentLanguage]!}
                        />
                        <label
                            className={styles["referral-filter__label"]}
                            htmlFor={region.slug[currentLanguage]!}
                        >
                            {region.name[currentLanguage]}
                        </label>
                    </div>
                ))}
            </fieldset>
        </form>
    );
}
