import type { Region } from "content/regions-interfaces";

export default interface ComponentInterface {
    regions: Region["attributes"][];
    onRegionChange: (region: string) => void;
    activeRegion: string;
}
