import { useContext } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "../../../context/ui";

import useSetting from "hooks/use-setting";

import CardButton from "../../partials/CardButton";
import ReadSpeakerButton from "../../partials/ReadSpeakerButton";
import IntakeForm from "../IntakeForm";
import OverlayContent from "../OverlayContent";

import styles from "./styles.module.scss";

export default function QuestionnaireNoResult({
    title,
    customLink,
    restartButtonLabel,
    requestAssistanceLabel,
    onRestart,
}: ComponentInterface) {
    const { setOverlayContent } = useContext(UIContext);
    const requestSupportFormOverlayContent = {
        title: useSetting("request_support_form_title"),
        description: useSetting("request_support_form_description"),
    };

    const overlayContentWithForm = (
        <OverlayContent overlayContent={requestSupportFormOverlayContent}>
            <IntakeForm />
        </OverlayContent>
    );

    return (
        <div className={styles["questionnaire-no-result"]}>
            <div className={styles["questionnaire-no-result__title-container"]}>
                <section
                    className={styles["questionnaire-no-result__title-inner"]}
                >
                    {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                        <div
                            className={
                                styles[
                                    "questionnaire-no-result__speaker-button-wrapper"
                                ]
                            }
                        >
                            <ReadSpeakerButton />
                        </div>
                    )}
                    <h1 className={styles["questionnaire-no-result__title"]}>
                        {title}
                    </h1>
                </section>
            </div>

            <div
                className={
                    styles["questionnaire-no-result__link-list-container"]
                }
            >
                <ul className={styles["questionnaire-no-result__link-list"]}>
                    <li>
                        <CardButton
                            onClick={onRestart}
                            title={restartButtonLabel}
                        />
                    </li>
                    {customLink && (
                        <li>
                            <CardButton
                                url={customLink.url}
                                title={customLink.label}
                            />
                        </li>
                    )}
                    <li>
                        <CardButton
                            onClick={() =>
                                setOverlayContent(overlayContentWithForm)
                            }
                            title={requestAssistanceLabel}
                        />
                    </li>
                </ul>
            </div>
        </div>
    );
}
