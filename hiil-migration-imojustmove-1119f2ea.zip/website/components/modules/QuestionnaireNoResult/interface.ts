import { Problem } from "../../../content/problems-interfaces";
import type {
    GivenAnswer,
    PreparedAnswer,
    PreparedQuestion,
} from "../../flexibles/Questions/interface";

export default interface ComponentInterface {
    title: string;
    customLink?: {
        label: string;
        url: string;
    };
    restartButtonLabel: string;
    requestAssistanceLabel: string;
    onRestart: () => void;
}
