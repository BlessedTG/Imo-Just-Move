import { useContext, useEffect } from "react";

import type LayoutInterface from "./interface";

import { UIContext } from "../../../context/ui";

import NotificationOverlay from "components/modules/NotificationOverlay";

import Overlay from "../../modules/Overlay";
import SiteFooter from "../../modules/SiteFooter";
import SiteHeader from "../../modules/SiteHeader";

export default function Layout({
    children,
    menus,
    translationUrls,
    isInProblemFlow,
    isHomePageLayout = false,
}: LayoutInterface) {
    const { overlayContent, hasVisitedHomePage, setHasVisitedHomePage } =
        useContext(UIContext);

    useEffect(() => {
        // this should be only triggered on page load
        isHomePageLayout && setHasVisitedHomePage(true);
    }, []);

    useEffect(() => {
        // Add class to the HTML element to set some overflow styles
        const doc = document.documentElement;
        doc?.setAttribute(
            "data-has-active-overlay",
            (!!overlayContent).toString()
        );
    }, [overlayContent]);

    return (
        <>
            <SiteHeader
                mainNavigationItems={menus.main}
                translationUrls={translationUrls}
                isInProblemFlow={isInProblemFlow}
            />

            <main id="content" role="main">
                {children}
                {!isInProblemFlow && <SiteFooter menus={menus} />}
            </main>

            {overlayContent && <Overlay>{overlayContent}</Overlay>}
            {!hasVisitedHomePage && isInProblemFlow && <NotificationOverlay />}
        </>
    );
}
