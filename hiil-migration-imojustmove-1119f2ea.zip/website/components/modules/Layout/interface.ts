import React from "react";

import { Menus } from "../../../content/menus-interface";

import { LocalizedUrls } from "../../../utils/get-translation-urls";

export default interface Layout {
    children: React.ReactNode;
    menus: Menus;
    translationUrls: LocalizedUrls;
    isInProblemFlow?: boolean;
    isHomePageLayout?: boolean;
}
