import type RichContentInterface from "./interface";

import styles from "./styles.module.scss";

export default function RichContent({
    children,
    cmsContent,
}: RichContentInterface) {
    if (cmsContent) {
        return (
            <div
                className={styles["rich-content"]}
                dangerouslySetInnerHTML={{ __html: cmsContent }}
            />
        );
    }

    if (children) {
        return <div className={styles["rich-content"]}>{children}</div>;
    }

    return null;
}
