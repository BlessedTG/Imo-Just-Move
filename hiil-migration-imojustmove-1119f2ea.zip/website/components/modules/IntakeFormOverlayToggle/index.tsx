import { useContext } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "../../../context/ui";

import useSetting from "hooks/use-setting";

import Button from "components/partials/Button";

import SaveIntakeForm from "../IntakeForm";
import OverlayContent from "../OverlayContent";

export default function IntakeFormOverlayToggle({
    label,
    problem,
    outcome,
}: ComponentInterface) {
    const { setOverlayContent, overlayContent } = useContext(UIContext);

    const intakeFormOverlayContent = {
        title: useSetting("intake_form_title"),
        description: useSetting("intake_form_description"),
    };

    const overlayContentWithForm = (
        <OverlayContent overlayContent={intakeFormOverlayContent}>
            <SaveIntakeForm {...{ problem, outcome }} />
        </OverlayContent>
    );

    return (
        <Button
            theme="primary"
            onClick={() => setOverlayContent(overlayContentWithForm)}
            isFluid={true}
            aria-expanded={overlayContent === null ? "false" : "true"}
        >
            {label}
        </Button>
    );
}
