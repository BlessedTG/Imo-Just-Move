export default interface ComponentInterface {
    label: string;
    problem?: string;
    outcome?: string;
}
