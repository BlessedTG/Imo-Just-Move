import type { Layout, LayoutIdentifier } from "./interface";

import type { Flexible } from "../../../utils/create-full-page-data/with-prepare";

import CallToAction from "../../flexibles/CallToAction";
import DefaultHeader from "../../flexibles/DefaultHeader";
import Example from "../../flexibles/Example";
import Faq from "../../flexibles/Faq";
import FeedbackForm from "../../flexibles/FeedbackForm";
import HomeHeader from "../../flexibles/HomeHeader";
import Images from "../../flexibles/Images";
import LargeText from "../../flexibles/LargeText";
import LinkThrough from "../../flexibles/LinkThrough";
import OutcomeHeader from "../../flexibles/OutcomeHeader";
import ProblemIdentification from "../../flexibles/ProblemIdentification";
import Questions from "../../flexibles/Questions";
import ReferralSignup from "../../flexibles/ReferralSignup";
import Resources from "../../flexibles/Resources";
import ShareThisPage from "../../flexibles/ShareThisPage";
import Text from "../../flexibles/Text";
import TextMedia from "../../flexibles/TextMedia";
import WhatToExpect from "../../flexibles/WhatToExpect";

interface Props {
    sections: Layout[];
}

type LayoutMap = {
    [_ in LayoutIdentifier]:
        | Flexible<any, any>
        | ((props: any) => JSX.Element | null);
};

export const layoutToComponent: LayoutMap = {
    defaultHeader: DefaultHeader,
    homeHeader: HomeHeader,
    example: Example,
    feedback_form: FeedbackForm,
    faq: Faq,
    images: Images,
    text: Text,
    text_media: TextMedia,
    large_text: LargeText,
    link_through: LinkThrough,
    problem_identification: ProblemIdentification,
    outcome_header: OutcomeHeader,
    call_to_action: CallToAction,
    questions: Questions,
    resources: Resources,
    referral_signup: ReferralSignup,
    what_to_expect: WhatToExpect,
    share_this_page: ShareThisPage,
};

export default function FlexibleContent({ sections }: Props) {
    return (
        <div>
            {sections.map(({ layout, attributes, media }: Layout, index) => {
                const Component = layoutToComponent[layout];
                if ("render" in Component) {
                    return (
                        <Component.render
                            key={`${layout}-${index}`}
                            {...attributes}
                            {...media}
                        />
                    );
                }

                return (
                    <Component
                        key={`${layout}-${index}`}
                        {...attributes}
                        {...media}
                    />
                );
            })}
        </div>
    );
}
