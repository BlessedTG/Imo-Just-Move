import type Image from "../../../interfaces/image";
import type CallToAction from "../../flexibles/CallToAction/interface";
import type DefaultHeader from "../../flexibles/DefaultHeader/interface";
import type Example from "../../flexibles/Example/interface";
import type Faq from "../../flexibles/Faq/interface";
import type FeedbackForm from "../../flexibles/FeedbackForm/interface";
import type HomeHeader from "../../flexibles/HomeHeader/interface";
import type Images from "../../flexibles/Images/interface";
import type LargeText from "../../flexibles/LargeText/interface";
import type LinkThrough from "../../flexibles/LinkThrough/interface";
import type OutcomeHeader from "../../flexibles/OutcomeHeader/interface";
import type ProblemIdentification from "../../flexibles/ProblemIdentification/interface";
import type Questions from "../../flexibles/Questions/interface";
import type ReferralSignup from "../../flexibles/ReferralSignup/interface";
import type Resources from "../../flexibles/Resources/interface";
import type ShareThisPage from "../../flexibles/ShareThisPage/interface";
import type Text from "../../flexibles/Text/interface";
import type TextMedia from "../../flexibles/TextMedia/interface";
import type WhatToExpect from "../../flexibles/WhatToExpect/interface";

export type ContentItem<Name, Attr> = {
    layout: Name;
    attributes: Attr;
    key: string;
    media: Image[];
};

export type Layout =
    | ContentItem<"defaultHeader", DefaultHeader>
    | ContentItem<"homeHeader", HomeHeader>
    | ContentItem<"example", Example>
    | ContentItem<"feedback_form", FeedbackForm>
    | ContentItem<"text", Text>
    | ContentItem<"text_media", TextMedia>
    | ContentItem<"large_text", LargeText>
    | ContentItem<"outcome_header", OutcomeHeader>
    | ContentItem<"call_to_action", CallToAction>
    | ContentItem<"link_through", LinkThrough>
    | ContentItem<"problem_identification", ProblemIdentification>
    | ContentItem<"questions", Questions>
    | ContentItem<"faq", Faq>
    | ContentItem<"resources", Resources>
    | ContentItem<"referral_signup", ReferralSignup>
    | ContentItem<"share_this_page", ShareThisPage>
    | ContentItem<"images", Images>
    | ContentItem<"what_to_expect", WhatToExpect>;

export type LayoutIdentifier = Layout["layout"];
