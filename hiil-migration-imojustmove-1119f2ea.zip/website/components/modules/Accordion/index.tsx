import React, { useState, useRef } from "react";

import type AccordionInterface from "./interface";

import Button from "components/partials/Button";

import ChevronDown from "public/icons/chevron-down.svg";

import RichContent from "../RichContent";

import styles from "./styles.module.scss";

export default function Accordion({
    title,
    html,
    subtitle,
}: AccordionInterface) {
    const [isActive, setIsActive] = useState(false);
    const [height, setHeight] = useState("0px");
    const content = useRef<HTMLDivElement>(null);

    const toggleAccordion = () => {
        setIsActive(isActive === false ? true : false);

        if (content.current !== null) {
            setHeight(
                isActive === true ? "0px" : `${content.current.scrollHeight}px`
            );
        }
    };

    return (
        <>
            <button
                onClick={toggleAccordion}
                className={`${styles["accordion__button"]} ${isActive}`}
                aria-expanded={isActive}
            >
                <span className={`${styles["accordion__button-inner"]}`}>
                    <h3 className={`${styles["accordion__button-title"]}`}>
                        {title}
                    </h3>
                    {subtitle && (
                        <span
                            className={`${styles["accordion__button-subtitle"]}`}
                        >
                            {subtitle}
                        </span>
                    )}
                </span>
                <span className={styles["accordion__icon-wrapper"]}>
                    <ChevronDown className={`${styles["accordion__icon"]}`} />
                </span>
            </button>

            <div
                ref={content}
                style={{ maxHeight: `${height}` }}
                className={styles["accordion__content"]}
            >
                <div className={styles["accordion__content-inner"]}>
                    <RichContent cmsContent={html} />
                </div>
            </div>
        </>
    );
}
