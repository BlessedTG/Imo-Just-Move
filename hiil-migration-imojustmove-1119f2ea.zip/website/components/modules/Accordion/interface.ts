import type { Link } from "../../../interfaces/link";

export default interface Accordion {
    title: string;
    html: string;
    subtitle?: string;
}
