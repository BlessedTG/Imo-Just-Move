import type { MenuItem } from "../../../content/menus-interface";

export default interface ComponentInterface {
    menuItems: MenuItem[];
    id: string;
    type: "primary" | "secondary";
    isInOverlay?: boolean;
}
