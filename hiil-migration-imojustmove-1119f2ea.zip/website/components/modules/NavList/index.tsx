import Link from "next/link";
import { usePathname } from "next/navigation";
import { useRouter } from "next/router";
import { useContext, useEffect } from "react";

import type ComponentInterface from "./interface";

import { UIContext } from "context/ui";

import stripTrailingSlashFromUrl from "utils/strip-trailing-slash-from-url";

import useSettings from "hooks/use-settings";
import useTranslations from "hooks/use-translations";

import styles from "./styles.module.scss";

export default function NavList({
    id: menuId,
    menuItems,
    type,
    isInOverlay = false,
}: ComponentInterface) {
    const router = useRouter();
    const translations = useTranslations();
    const { menuIsOpen, setMenuIsOpen } = useContext(UIContext);
    const pathname = usePathname();

    const ariaLabel =
        type === "primary"
            ? translations.navigation.primaryNavigationLabel
            : translations.navigation.secondaryNavigationLabel;

    /**
     * To update the PathName, we have to set the state with
     * the PathName again, after navigating to a different page.
     */
    useEffect(() => {
        const handleRouteChangeComplete = () => {
            setMenuIsOpen(false);
        };
        router.events.on("routeChangeComplete", handleRouteChangeComplete);
        return () => {
            router.events.off("routeChangeComplete", handleRouteChangeComplete);
        };
    }, [router.events, setMenuIsOpen]);

    return (
        <ul
            className={styles["nav-list"]}
            aria-label={ariaLabel}
            data-type={type}
        >
            {menuItems.map(({ id, attributes: { name, value } }) => (
                <li
                    key={`${menuId}-nav-list-item-${id}`}
                    className={styles["nav-list__item"]}
                >
                    <Link
                        href={value}
                        className={styles["nav-list__link"]}
                        aria-current={
                            stripTrailingSlashFromUrl(pathname) === value
                        }
                        tabIndex={menuIsOpen || !isInOverlay ? 0 : -1}
                    >
                        {name}
                    </Link>
                </li>
            ))}
        </ul>
    );
}
