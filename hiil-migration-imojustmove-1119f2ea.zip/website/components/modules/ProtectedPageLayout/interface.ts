import React from "react";

import { Menus } from "../../../content/menus-interface";

import { LocalizedUrls } from "../../../utils/get-translation-urls";

export default interface ProjectedPageLayout {
    menus: Menus;
    translationUrls: LocalizedUrls;
}
