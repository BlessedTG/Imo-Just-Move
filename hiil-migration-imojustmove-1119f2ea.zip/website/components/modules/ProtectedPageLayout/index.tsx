import type LayoutInterface from "./interface";

import CustomHead from "components/partials/CustomHead";

import Layout from "../Layout";
import ProtectedPageMessage from "../ProtectedPageMessage";

export default function ProtectedPageLayout({
    menus,
    translationUrls,
}: LayoutInterface) {
    return (
        <>
            <CustomHead title={"Protected"} />

            <Layout menus={menus} translationUrls={translationUrls}>
                <ProtectedPageMessage />
            </Layout>
        </>
    );
}
