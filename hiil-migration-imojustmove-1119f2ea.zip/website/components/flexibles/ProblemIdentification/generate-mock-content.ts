import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import mockProblems from "../../../content/problems-categories";
import problemsCategories from "content/problems-categories";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;
type PartialPreparedComponentInterface = Subset<PreparedComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            description: "Make a choice",
            problem_categories: ["problem-category-1", "problem-category-2"],
            link: [
                {
                    layout: "link",
                    key: "key",
                    attributes: {
                        label: "Help me decide",
                        url: "/",
                    },
                },
            ],
            back_link: [
                {
                    layout: "link",
                    key: "key",
                    attributes: {
                        label: "Back",
                        url: "/",
                    },
                },
            ],
        },
        overwrite
    );

export const generateMockContentWithPrepare = (
    overwrite: PartialPreparedComponentInterface = {}
): PreparedComponentInterface =>
    deepMerge<PreparedComponentInterface>(
        {
            problemsCategories: mockProblems,
        },
        overwrite
    );
