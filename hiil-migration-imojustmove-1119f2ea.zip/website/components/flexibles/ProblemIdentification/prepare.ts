import type { JsonApiObject } from "../../../content/api-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import { api as problemCategoriessApi } from "../../../content/problems-categories";

import sortByOrder from "utils/sort-by-order";

export default async function prepare(
    props: ComponentInterface,
    pageData: JsonApiObject
): Promise<PreparedComponentInterface> {
    const problemIds = props.problem_categories;
    const problemsResponse = await problemCategoriessApi
        .where("id", problemIds)
        .getAll();

    let problemCategories = problemsResponse.data.sort(
        sortByOrder(problemIds, "id")
    );

    return {
        ...props,
        problemCategories: problemCategories,
        title: props.title ? props.title : pageData.attributes.title,
    };
}
