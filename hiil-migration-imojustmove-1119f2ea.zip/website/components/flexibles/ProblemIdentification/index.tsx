import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";
import type { ProblemCategory } from "content/problem-categories-interfaces";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";
import getPreparedLink from "utils/get-prepared-link";

import useSetting from "hooks/use-setting";

import ProgressBar from "components/modules/ProgressBar";
import StepGrid from "components/modules/StepGrid";
import CardButton from "components/partials/CardButton";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function ProblemIdentification({
    title,
    description,
    link,
    problemCategories,
    back_link,
}: PreparedComponentInterface) {
    const steps = [
        useSetting("first_step_label"),
        useSetting("second_step_label"),
        useSetting("third_step_label"),
        useSetting("fourth_step_label"),
    ];
    const backLink = getPreparedLink(back_link?.[0]);
    const nextLink = getPreparedLink(link?.[0]);

    return (
        <>
            <ProgressBar steps={steps} activeStep={1} />
            <StepGrid
                title={title}
                description={description}
                backButtonLabel={
                    typeof backLink !== "undefined"
                        ? backLink!.label
                        : back_link![0].attributes.label
                }
                backButtonUrl={
                    typeof backLink !== "undefined"
                        ? backLink?.url
                        : back_link![0].attributes.url
                }
                showNextButton={nextLink ? true : false}
                nextButtonUrl={nextLink?.url}
                nextButtonLabel={nextLink?.label}
            >
                <ul className={styles["problem-identification__link-list"]}>
                    {problemCategories.map(
                        (problemCategory: ProblemCategory, index: number) =>
                            problemCategory.attributes.url && (
                                <li
                                    className={
                                        styles[
                                            "problem-identification__link-list-item"
                                        ]
                                    }
                                    key={index}
                                >
                                    <CardButton
                                        title={problemCategory.attributes.title}
                                        subtitle={
                                            problemCategory.attributes
                                                .description
                                        }
                                        url={problemCategory.attributes.url}
                                    />
                                </li>
                            )
                    )}
                </ul>
            </StepGrid>
        </>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(ProblemIdentification);
