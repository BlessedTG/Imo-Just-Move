import type { ProblemCategory } from "content/problem-categories-interfaces";
import type { Link } from "interfaces/link";

export default interface ComponentInterface {
    title: string;
    description?: string;
    link: Link[];
    back_link: Link[];
    problem_categories: string[];
}

export interface PreparedComponentInterface extends ComponentInterface {
    problemCategories: ProblemCategory[];
}
