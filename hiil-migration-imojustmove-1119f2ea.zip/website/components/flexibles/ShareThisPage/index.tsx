import { useEffect, useState } from "react";

import type ComponentInterface from "./interface";

import useSetting from "hooks/use-setting";

import Button from "components/partials/Button";

import styles from "./styles.module.scss";

export default function ShareThisPage({
    title,
    intro,
    email_label,
    whatsapp_label,
    print_label,
}: ComponentInterface) {
    const [pageUrl, setPageUrl] = useState<string>("");
    const emailSubject = useSetting("email_share_subject");

    useEffect(() => {
        setPageUrl(window.location.href);
    }, []);

    return (
        <div className={styles["share-this-page"]}>
            <div
                className={styles["share-this-page__inner"]}
                data-has-intro={intro ? true : false}
            >
                <h2 className={styles["share-this-page__title"]}>{title}</h2>

                <div className={styles["share-this-page__content"]}>
                    {intro && (
                        <p className={styles["share-this-page__intro"]}>
                            {intro}
                        </p>
                    )}

                    <div className={styles["share-this-page__button-wrapper"]}>
                        <Button
                            theme="secondary"
                            isFluid={true}
                            url={`mailto:?body=${pageUrl}&subject=${emailSubject}`}
                        >
                            {email_label}
                        </Button>

                        <Button
                            theme="secondary"
                            isFluid={true}
                            onClick={() => window.print()}
                        >
                            {print_label}
                        </Button>

                        <Button
                            theme="secondary"
                            isFluid={true}
                            url={`https://wa.me/?text=${encodeURI(pageUrl)}`}
                        >
                            {whatsapp_label}
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    );
}
