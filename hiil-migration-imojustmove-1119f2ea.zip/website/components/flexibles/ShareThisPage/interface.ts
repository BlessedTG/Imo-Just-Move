export default interface ComponentInterface {
    title: string;
    intro?: string;
    email_label: string;
    whatsapp_label: string;
    print_label: string;
}
