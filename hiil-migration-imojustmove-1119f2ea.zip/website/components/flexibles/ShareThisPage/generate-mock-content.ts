import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "Share this page",
            intro: "Share this page with yourself to easily access this information in the future:",
            print_label: "Print",
            email_label: "Email",
            whatsapp_label: "WhatsApp",
        },
        overwrite
    );
