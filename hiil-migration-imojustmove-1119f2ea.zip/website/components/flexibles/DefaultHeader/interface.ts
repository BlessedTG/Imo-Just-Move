import type { Breadcrumb } from "components/modules/Breadcrumbs/interface";
import type Image from "interfaces/image";

export default interface ComponentInterface {}

export interface PreparedComponentInterface extends ComponentInterface {
    title: string;
    intro?: string;
    image?: Image;
    breadcrumbList: Breadcrumb[];
}
