import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";

import Breadcrumbs from "components/modules/Breadcrumbs";
import Image from "components/partials/Image";
import { defaultFullScreenSrcset } from "components/partials/Image";
import ReadSpeakerButton from "components/partials/ReadSpeakerButton";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function DefaultHeader({
    title,
    intro,
    image,
    breadcrumbList,
}: PreparedComponentInterface) {
    return (
        <header className={styles["default-header"]}>
            {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                <div
                    data-readspeaker-theme="dark"
                    className={styles["default-header__read-speaker-button"]}
                >
                    <ReadSpeakerButton />
                </div>
            )}

            {breadcrumbList.length > 1 && (
                <div className={styles["default-header__breadcrumbs"]}>
                    <Breadcrumbs breadcrumbs={breadcrumbList} />
                </div>
            )}

            <div
                className={styles["default-header__text-container"]}
                data-has-intro={intro ? "true" : "false"}
            >
                <h1 className={styles["default-header__title"]}>{title}</h1>
                {intro && (
                    <p className={styles["default-header__intro"]}>{intro}</p>
                )}
            </div>

            {image && (
                <figure className={styles["default-header__figure"]}>
                    <Image
                        className={styles["default-header__image"]}
                        srcset={defaultFullScreenSrcset}
                        image={image}
                    />
                </figure>
            )}
        </header>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(DefaultHeader);
