import type { JsonApiObject } from "../../../content/api-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";
import { isDefaultPage, isPage } from "content/pages-interfaces";

import generateBreadcrumbs from "utils/generate-breadcrumbs";
import type { RenderedResources } from "utils/page-render-helpers";

export default async function prepare(
    props: ComponentInterface,
    pageData: RenderedResources,
    included?: JsonApiObject[]
): Promise<PreparedComponentInterface> {
    // Breadcrumbs are generated based on the page's parent pages
    // this works only for pages since other resources don't have
    // a parent-child relationship.
    const breadcrumbs = isPage(pageData)
        ? await generateBreadcrumbs(pageData)
        : [];

    if (isDefaultPage(pageData)) {
        const intro = pageData.attributes.metadata?.intro;
        const headerImage = pageData.attributes.media?.header_image
            ? pageData.attributes.media.header_image[0]
            : undefined;
        return {
            ...props,
            title: pageData.attributes.title,
            ...(intro && { intro }),
            ...(headerImage && { image: headerImage }),
            breadcrumbList: breadcrumbs,
        };
    }

    return {
        ...props,
        title: pageData.attributes.title,
        breadcrumbList: breadcrumbs,
    };
}
