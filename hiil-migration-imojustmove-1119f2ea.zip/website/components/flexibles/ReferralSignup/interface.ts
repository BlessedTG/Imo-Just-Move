export default interface ComponentInterface {
    title?: string;
    text: string;
    referral_signup_trigger_label?: string;
}
