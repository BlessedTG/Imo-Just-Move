import type ComponentInterface from "./interface";

import ReferralFormOverlayToggle from "components/modules/ReferralFormOverlayToggle";

import RichContent from "../../modules/RichContent";

import styles from "./styles.module.scss";

export default function ReferralSignup({
    title,
    text,
    referral_signup_trigger_label,
}: ComponentInterface) {
    return (
        <div className={styles["referral_signup"]}>
            <section className={styles["referral_signup__inner"]}>
                <div className={styles["referral_signup__left-column"]}>
                    {title && (
                        <h2 className={styles["referral_signup__title"]}>
                            {title}
                        </h2>
                    )}
                </div>

                <div className={styles["referral_signup__right-column"]}>
                    <div className={styles["referral_signup__text"]}>
                        <RichContent cmsContent={text} />
                    </div>
                    {referral_signup_trigger_label && (
                        <div
                            className={
                                styles["referral_signup__form-trigger-wrapper"]
                            }
                        >
                            <ReferralFormOverlayToggle
                                label={referral_signup_trigger_label}
                                theme="secondary"
                            />
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}
