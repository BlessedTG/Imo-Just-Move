import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            text: "Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices.",
        },
        overwrite
    );
