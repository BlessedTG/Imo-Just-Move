export default interface ComponentInterface {
    text: string;
}
