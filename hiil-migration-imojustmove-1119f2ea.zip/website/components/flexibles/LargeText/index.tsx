import type ComponentInterface from "./interface";

import styles from "./styles.module.scss";

export default function LargeText({ text }: ComponentInterface) {
    return (
        <div className={styles["large-text"]}>
            <div className={styles["large-text__inner"]}>
                <p className={styles["large-text__text"]}>{text}</p>
            </div>
        </div>
    );
}
