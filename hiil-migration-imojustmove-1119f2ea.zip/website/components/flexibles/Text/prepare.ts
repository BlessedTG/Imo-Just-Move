import type { JsonApiObject } from "../../../content/api-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";
import { isOutcome } from "content/outcomes-interfaces";

export default async function prepare(
    props: ComponentInterface,
    pageData: JsonApiObject,
    included?: JsonApiObject[]
): Promise<PreparedComponentInterface> {
    if (isOutcome(pageData)) {
        return {
            ...props,
            problem: pageData.relationships.problem.data.attributes.title,
            outcome: pageData.attributes.title,
        };
    }

    return {
        ...props,
    };
}
