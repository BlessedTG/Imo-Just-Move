import { Link } from "../../../interfaces/link";

export default interface ComponentInterface {
    title?: string;
    text: string;
    links?: Link[];
    save_intake_trigger_label?: string;
}

export interface PreparedComponentInterface extends ComponentInterface {
    problem?: string;
    outcome?: string;
}
