import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "This is a text block!",
            text: "<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's <strong>standard dummy text</strong> ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was <a href='/'>popularised</a> in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's <strong>standard dummy text</strong> ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was <a href='/'>popularised</a> in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p><ul><li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus, rerum?</li><li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Corporis, ea!</li><li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores, ipsum.</li></ul><ol><li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Consequuntur, nobis.</li><li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est, quaerat?</li><li>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, veritatis.</li></ol>",
            links: [
                {
                    layout: "link",
                    key: "link-text-1",
                    attributes: {
                        label: "Link 1",
                        url: "/",
                    },
                },
                {
                    layout: "link",
                    key: "link-text-2",
                    attributes: {
                        label: "Link 2",
                        url: "/",
                    },
                },
            ],
        },
        overwrite
    );
