import ComponentInterface, { PreparedComponentInterface } from "./interface";

import withPrepare from "utils/create-full-page-data/with-prepare";

import IntakeFormOverlayToggle from "components/modules/IntakeFormOverlayToggle";

import LinkList from "../../modules/LinkList";
import RichContent from "../../modules/RichContent";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function Text({
    title,
    text,
    links,
    save_intake_trigger_label,
    problem,
    outcome,
}: PreparedComponentInterface) {
    return (
        <div className={styles["text"]}>
            <section className={styles["text__inner"]}>
                <div className={styles["text__left-column"]}>
                    {title && (
                        <h2 className={styles["text__title"]}>{title}</h2>
                    )}
                </div>

                <div className={styles["text__right-column"]}>
                    <div className={styles["text__text"]}>
                        <RichContent cmsContent={text} />
                    </div>
                    {links && links.length > 0 && (
                        <div className={styles["text__links-container"]}>
                            <LinkList links={links} />
                        </div>
                    )}
                    {save_intake_trigger_label && (
                        <div className={styles["text__form-trigger-wrapper"]}>
                            <IntakeFormOverlayToggle
                                label={save_intake_trigger_label}
                                {...(problem && { problem })}
                                {...(outcome && { outcome })}
                            />
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(Text);
