import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "Title of this CTA",
            text: "Lorem ipsum dolor sit amet consectetur. Semper fringilla neque maecenas in quisque pellentesque vestibulum viverra.",
            links: [
                {
                    layout: "link",
                    key: "link-cta",
                    attributes: {
                        label: "Call to action",
                        url: "/flexibles",
                    },
                },
            ],
        },
        overwrite
    );
