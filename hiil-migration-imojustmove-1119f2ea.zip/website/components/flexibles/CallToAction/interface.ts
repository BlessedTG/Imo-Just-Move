import type { Link } from "../../../interfaces/link";

export default interface ComponentInterface {
    title: string;
    text?: string;
    links: Link[];
}
