import type ComponentInterface from "./interface";

import Button from "components/partials/Button";

import styles from "./styles.module.scss";

export default function CallToAction({
    title,
    text,
    links,
}: ComponentInterface) {
    const link = links?.[0];
    const isExternalLink = link.attributes.urlType === "external";

    return (
        <div className={styles["call-to-action"]}>
            <div className={styles["call-to-action__inner"]}>
                <section className={styles["call-to-action__content-wrapper"]}>
                    <h2 className={styles["call-to-action__title"]}>{title}</h2>

                    {text && (
                        <p className={styles["call-to-action__text"]}>{text}</p>
                    )}

                    {link && (
                        <div className={styles["call-to-action__link-wrapper"]}>
                            <Button
                                url={
                                    isExternalLink
                                        ? link.attributes.externalUrl
                                        : link.attributes.url
                                }
                                isExternalLink={isExternalLink}
                                isFluid={true}
                                targetBlank={link.attributes.targetBlank}
                            >
                                {link.attributes.label}
                            </Button>
                        </div>
                    )}
                </section>
            </div>
        </div>
    );
}
