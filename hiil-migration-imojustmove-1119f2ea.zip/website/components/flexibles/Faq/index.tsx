import type ComponentInterface from "./interface";

import Accordion from "components/modules/Accordion";
import Button from "components/partials/Button";

import styles from "./styles.module.scss";

export default function Faq({ title, faqs, link }: ComponentInterface) {
    const isExternalLink =
        link?.length === 1 ? link[0].attributes?.urlType === "external" : false;
    return (
        <div className={styles["faq"]}>
            <section className={styles["faq__inner"]}>
                <h2 className={styles["faq__title"]}>{title}</h2>

                <div className={styles["faq__list-wrapper"]}>
                    <ul className={styles["faq__list"]}>
                        {faqs.map((faq: any) => (
                            <li
                                key={faq.key}
                                className={styles["expand-list__item"]}
                            >
                                <Accordion
                                    title={faq.attributes.question}
                                    html={faq.attributes.answer}
                                    subtitle={faq.attributes.subtitle}
                                />
                            </li>
                        ))}
                    </ul>
                    {link?.length === 1 && (
                        <div className={styles["faq__link-wrapper"]}>
                            <Button
                                url={
                                    isExternalLink
                                        ? link[0].attributes.externalUrl
                                        : link[0].attributes.url
                                }
                                isExternalLink={isExternalLink}
                                isFluid={true}
                                theme="secondary"
                                targetBlank={link[0].attributes.targetBlank}
                            >
                                {link[0].attributes.label}
                            </Button>
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}
