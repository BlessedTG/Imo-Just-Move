import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "Here are the proposed steps to take",
            faqs: [
                {
                    layout: "faq",
                    key: "faq-question-1",
                    attributes: {
                        question: "Title of step 1",
                        subtitle: "Subtitle of step 1",
                        answer: "<p>Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices. Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices.</p>",
                    },
                },
                {
                    layout: "faq",
                    key: "faq-question-2",
                    attributes: {
                        question: "Title of step 2",
                        subtitle: "Subtitle of step 2",
                        answer: "<p>Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices. Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices.</p>",
                    },
                },
                {
                    layout: "faq",
                    key: "faq-question-3",
                    attributes: {
                        question: "Title of step 3",
                        subtitle: "Subtitle of step 3",
                        answer: "<p>Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices. Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis. Diam sapien nunc parturient congue donec. Tempor purus eu donec diam mollis lectus sed at ultrices.</p>",
                    },
                },
            ],
            link: [
                {
                    layout: "link",
                    key: "link-faq",
                    attributes: {
                        label: "Choose a different outcome",
                        url: "/flexibles",
                    },
                },
            ],
        },
        overwrite
    );
