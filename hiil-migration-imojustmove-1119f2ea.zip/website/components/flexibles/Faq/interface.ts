import type { Link } from "../../../interfaces/link";

interface Faq {
    question: string;
    answer: string;
    subtitle?: string;
}

export default interface ComponentInterface {
    title: string;
    faqs: Faq[];
    link?: Link[];
}
