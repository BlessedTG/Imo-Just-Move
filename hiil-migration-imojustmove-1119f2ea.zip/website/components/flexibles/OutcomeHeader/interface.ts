import type { Referral } from "content/referrals-interfaces";

export default interface ComponentInterface {}

export interface PreparedComponentInterface extends ComponentInterface {
    title: string;
    referrals: Referral[];
    problem: string | null;
}
