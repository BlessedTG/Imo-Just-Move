import type { JsonApiObject } from "../../../content/api-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";
import { isOutcome } from "content/outcomes-interfaces";
import { Referral } from "content/referrals-interfaces";

export default async function prepare(
    props: ComponentInterface,
    pageData: JsonApiObject
): Promise<PreparedComponentInterface> {
    return {
        ...props,
        title: pageData.attributes.title,
        referrals: pageData.relationships?.referrals?.data as Referral[],
        problem: isOutcome(pageData)
            ? pageData.relationships.problem.data.attributes.title
            : null,
    };
}
