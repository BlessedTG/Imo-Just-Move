import { useContext, useState } from "react";

import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";
import type {
    Referral,
    ReferralAttributes,
} from "content/referrals-interfaces";

import { UIContext } from "context/ui";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";
import interpolate from "utils/interpolate";

import useTranslations from "../../../hooks/use-translations";
import useFilter from "hooks/use-filter";
import useSetting from "hooks/use-setting";

import OverlayContent from "components/modules/OverlayContent";
import ProgressBar from "components/modules/ProgressBar";
import ReferralFilter from "components/modules/ReferralFilter";
import ReferralFormOverlayToggle from "components/modules/ReferralFormOverlayToggle";
import { LanguageContext } from "components/modules/WithMultilingual";
import CardButton from "components/partials/CardButton";
import ReadSpeakerButton from "components/partials/ReadSpeakerButton";
import ReferralDetail from "components/partials/ReferralDetail";

import prepare from "./prepare";
import styles from "./styles.module.scss";

export interface FilterState {
    region: "All-regions" | "None" | string;
}

function OutcomeHeader({
    title,
    referrals,
    problem,
}: PreparedComponentInterface) {
    const { setOverlayContent, overlayContent } = useContext(UIContext);
    const translations = useTranslations();

    const [filterState, setFilterState] = useState<FilterState>({
        region: "None",
    });
    const steps = [
        useSetting("first_step_label"),
        useSetting("second_step_label"),
        useSetting("third_step_label"),
        useSetting("fourth_step_label"),
    ];
    const currentLanguage = useContext(LanguageContext);
    const outcomeTitle = useSetting("outcome_title");

    const interpolatedTitle = interpolate(outcomeTitle, {
        problem: problem!,
        outcome: title,
    });

    const outcomeContent = {
        title: interpolatedTitle,
    };

    const regions = referrals
        .map((referral) => referral.attributes.region)
        .filter((region) => region !== null)
        .sort((a: any, b: any) => a.id - b.id);

    const mapFromRegions = new Map(
        regions
            .filter((identity) => identity) // only keep not-null regions
            .map((region: any) => [region.id, region])
    );

    const uniqueRegions = Array.from(mapFromRegions.values());

    const checkEmptyAttribute = (attribute: string) =>
        attribute && attribute !== "-"; // some fields are required but have been filled in with "-"

    const attributesToRender = [
        "phone_number",
        "email",
        "expertise",
        "location",
    ] as (keyof ReferralAttributes)[];

    const setOverlayContentWithReferral = (referral: Referral) => {
        return (
            <OverlayContent
                overlayContent={{
                    title:
                        referral.attributes.name +
                        " " +
                        (checkEmptyAttribute(referral.attributes.surname)
                            ? referral.attributes.surname
                            : ""),
                    description: referral.attributes.role,
                }}
            >
                <dl>
                    {attributesToRender.map((attr, index) => {
                        const value = referral.attributes[attr] as string;
                        if (!checkEmptyAttribute(value)) return false;

                        return (
                            <ReferralDetail
                                key={`referral-detail--${index}`}
                                text={value}
                                label={translations.referral[attr]}
                            />
                        );
                    })}
                </dl>
            </OverlayContent>
        );
    };

    const regionFilter = (state: FilterState) => (referral: Referral) => {
        const region = referral.attributes.region;
        if (region === null || state.region === "None") return false;

        if (state.region === "All-regions") return true;

        if (typeof region === "undefined") {
            // Region on a referral can be undefined,
            // in that case we don't want to show it when a region is selected
            return false;
        }
        return state.region === region.slug[currentLanguage];
    };

    const { filteredItems } = useFilter<Referral, FilterState>(
        referrals,
        [regionFilter],
        filterState
    );

    const handleRegionChange = (region: "All-regions" | "None" | string) => {
        setFilterState({
            ...filterState,
            region,
        });
    };

    return (
        <>
            <ProgressBar steps={steps} activeStep={4} />
            <div className={styles["outcome-header"]}>
                <div className={styles["outcome-header__inner"]}>
                    {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                        <div
                            className={
                                styles[
                                    "outcome-header__read-speaker-button-wrapper"
                                ]
                            }
                        >
                            <ReadSpeakerButton />
                        </div>
                    )}

                    <h1 className={styles["outcome-header__title"]}>
                        <span className={styles["outcome-header__title-inner"]}>
                            {`${outcomeContent.title}`}
                        </span>
                    </h1>

                    <div className={styles["outcome-header__content"]}>
                        <h2 className={styles["outcome-header__subtitle"]}>
                            {useSetting("outcome_help_title")}
                        </h2>

                        <div className={styles["outcome-header__list-wrapper"]}>
                            <ReferralFilter
                                regions={uniqueRegions}
                                activeRegion={filterState.region}
                                onRegionChange={handleRegionChange}
                            />

                            <ul className={styles["outcome-header__list"]}>
                                {filteredItems.map((referral) => (
                                    <li
                                        className={
                                            styles["outcome-header__list-item"]
                                        }
                                        key={`referral-${referral.id}`}
                                    >
                                        <CardButton
                                            title={referral.attributes.name}
                                            subtitle={referral.attributes.role}
                                            onClick={() =>
                                                setOverlayContent(
                                                    setOverlayContentWithReferral(
                                                        referral
                                                    )
                                                )
                                            }
                                            aria-expanded={
                                                overlayContent === null
                                                    ? "false"
                                                    : "true"
                                            }
                                            aria-controls="overlay-widget"
                                        />
                                    </li>
                                ))}
                            </ul>

                            {process.env
                                .NEXT_PUBLIC_ENABLE_SIGNUP_AS_REFERRAL ===
                                "true" && (
                                <ReferralFormOverlayToggle label="Sign up as a referral" />
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(OutcomeHeader);
