import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;
type PartialPreparedComponentInterface = Subset<PreparedComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            children: "<h1>This is a auto generated block</h1>",
        },
        overwrite
    );

export const generateMockContentWithPrepare = (
    overwrite: PartialPreparedComponentInterface = {}
): PreparedComponentInterface =>
    deepMerge<PreparedComponentInterface>(
        {
            children: "<h1>This is a auto generated block</h1>",
        },
        overwrite
    );
