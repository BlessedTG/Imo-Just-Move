import { Metadata } from "next";

import type { JsonApiObject } from "../../../content/api-interfaces";
import { isHomePage, type HomePage } from "../../../content/pages-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import { RenderedResources } from "utils/page-render-helpers";

export default function prepare(
    props: ComponentInterface,
    pageData: RenderedResources,
    included?: JsonApiObject[]
): PreparedComponentInterface {
    if (!("template" in pageData.attributes)) {
        throw new Error("The pageData is missing the template attribute");
    }
    const homePageData = pageData as HomePage;

    if (!isHomePage(pageData)) {
        throw new Error("The pageData is not a home page");
    }

    const headerImage = pageData.attributes.media?.header_home_image
        ? pageData.attributes.media.header_home_image[0]
        : undefined;

    const intro = pageData.attributes.metadata.intro;
    const videoID = pageData.attributes.metadata.videoID;
    const is_background_image =
        pageData.attributes.metadata.is_background_image;

    return {
        ...props,
        title: homePageData.attributes.title,
        subtitle: homePageData.attributes?.metadata?.subtitle,
        ...(intro && { intro }),
        ...(videoID && { videoID }),
        ...(is_background_image && { is_background_image }),
        ...(headerImage && { image: headerImage }),
    };
}
