import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";

import RichContent from "components/modules/RichContent";
import Image from "components/partials/Image";
import { defaultFullScreenSrcset } from "components/partials/Image";
import ReadSpeakerButton from "components/partials/ReadSpeakerButton";
import Video from "components/partials/Video";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function HomeHeader({
    title,
    subtitle,
    image,
    intro,
    is_background_image,
    videoID,
}: PreparedComponentInterface) {
    const hasMedia = videoID || (image && !is_background_image) ? true : false;

    return (
        <div className={styles["home-header"]}>
            <div className={styles["home-header__background"]}>
                {image && is_background_image && (
                    <figure
                        className={styles["home-header__background-figure"]}
                    >
                        <Image
                            className={styles["home-header__image"]}
                            srcset={defaultFullScreenSrcset}
                            image={image}
                        />
                    </figure>
                )}
            </div>

            {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                <div className={styles["home-header__speaker-button-wrapper"]}>
                    <ReadSpeakerButton />
                </div>
            )}
            <div
                className={styles["home-header__inner"]}
                data-has-media={hasMedia}
            >
                <div className={styles["home-header__text"]}>
                    <h1 className={styles["home-header__title"]}>{title}</h1>
                    <span className={styles["home-header__subtitle"]}>
                        <RichContent cmsContent={subtitle} />
                    </span>
                    <RichContent cmsContent={intro} />
                </div>

                {hasMedia && (
                    <div className={styles["home-header__media"]}>
                        {videoID && <Video videoID={videoID} />}
                        {!videoID && image && !is_background_image && (
                            <figure className={styles["home-header__figure"]}>
                                <Image
                                    className={styles["home-header__image"]}
                                    srcset={defaultFullScreenSrcset}
                                    image={image}
                                />
                            </figure>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(HomeHeader);
