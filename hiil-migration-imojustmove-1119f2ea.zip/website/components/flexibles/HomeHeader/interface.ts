import type Image from "interfaces/image";

export default interface ComponentInterface {}

export interface PreparedComponentInterface extends ComponentInterface {
    title: string;
    subtitle: string;
    intro?: string;
    image?: Image;
    is_background_image?: boolean;
    videoID?: string;
}
