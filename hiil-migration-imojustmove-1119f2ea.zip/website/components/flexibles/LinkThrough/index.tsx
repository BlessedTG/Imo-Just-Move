import type ComponentInterface from "./interface";

import Button from "../../partials/Button";
import ImagePartial from "../../partials/Image";

import styles from "./styles.module.scss";

export const defaultFullScreenSrcset = [{ vw: 400, width: 200 }];

export default function LinkThrough({
    title,
    content_with_links,
}: ComponentInterface) {
    return (
        <div className={styles["link-through"]}>
            <section className={styles["link-through__inner"]}>
                <h2 className={styles["link-through__title"]}>{title}</h2>
                <ul
                    className={styles["link-through__link-list"]}
                    data-has-four-rows={content_with_links.length === 4}
                >
                    {content_with_links.map(
                        (
                            { attributes: { title, description, link, image } },
                            index
                        ) => (
                            <li
                                key={`content-link-${index}-${title}`}
                                className={styles["link-through__list-item"]}
                            >
                                {image && (
                                    <figure
                                        className={
                                            styles[
                                                "link-through__list-item-figure"
                                            ]
                                        }
                                    >
                                        <ImagePartial
                                            image={image}
                                            className={
                                                styles[
                                                    "link-through__list-item-image"
                                                ]
                                            }
                                            srcset={defaultFullScreenSrcset}
                                            customWidth={100}
                                        />
                                    </figure>
                                )}
                                <h3
                                    className={
                                        styles["link-through__list-item-title"]
                                    }
                                >
                                    {title}
                                </h3>
                                <p
                                    className={
                                        styles[
                                            "link-through__list-item-description"
                                        ]
                                    }
                                >
                                    {description}
                                </p>
                                {
                                    // The link is always an array even if it only contains one item.
                                    // This is because the CMS always returns an array.
                                    // We have to access the first item in the array to get the actual link data.
                                    link && link.length > 0 && (
                                        <div
                                            className={
                                                styles[
                                                    "link-through__list-item-link-wrapper"
                                                ]
                                            }
                                        >
                                            <Button
                                                url={
                                                    link?.[0].attributes
                                                        ?.urlType === "external"
                                                        ? link?.[0].attributes
                                                              .externalUrl
                                                        : link?.[0].attributes
                                                              .url
                                                }
                                                isExternalLink={
                                                    link?.[0].attributes
                                                        ?.urlType === "external"
                                                }
                                                isFluid={true}
                                                targetBlank={
                                                    link?.[0].attributes
                                                        .targetBlank
                                                }
                                            >
                                                {link?.[0].attributes?.label}
                                            </Button>
                                        </div>
                                    )
                                }
                            </li>
                        )
                    )}
                </ul>
            </section>
        </div>
    );
}
