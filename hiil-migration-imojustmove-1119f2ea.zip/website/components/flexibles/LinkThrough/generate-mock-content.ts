import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "This is a link through block!",
            content_with_links: [
                {
                    attributes: {
                        title: "Content 1",
                        description: "This is the first content link item",
                        link: [
                            {
                                layout: "link",
                                key: "link-text-1",
                                attributes: {
                                    label: "Link 1",
                                    value: "/",
                                },
                            },
                        ],
                    },
                },
                {
                    attributes: {
                        title: "Content 2",
                        description: "This is the second content link item",
                        link: [
                            {
                                layout: "link",
                                key: "link-text-2",
                                attributes: {
                                    label: "Link 2",
                                    value: "/",
                                },
                            },
                        ],
                    },
                },
                {
                    attributes: {
                        title: "Content 3",
                        description: "This is the third content link item",
                        link: [
                            {
                                layout: "link",
                                key: "link-text-3",
                                attributes: {
                                    label: "Link 3",
                                    value: "/",
                                },
                            },
                        ],
                    },
                },
            ],
        },
        overwrite
    );
