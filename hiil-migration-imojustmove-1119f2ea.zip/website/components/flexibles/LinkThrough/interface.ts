import Image from "../../../interfaces/image";
import { Link } from "../../../interfaces/link";

export interface ContentWithLinks {
    attributes: {
        title: string;
        description: string;
        link: Link[];
        image?: Image;
    };
}

export default interface ComponentInterface {
    title: string;
    content_with_links: ContentWithLinks[];
}
