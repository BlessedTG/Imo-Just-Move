import type ComponentInterface from "./interface";

import Figcaption from "components/partials/Figcaption";

import ImagePartial, { defaultFullScreenSrcset } from "../../partials/Image";

import styles from "./styles.module.scss";

export default function Images({
    image1,
    figcaption1,
    image2,
    figcaption2,
}: ComponentInterface) {
    if (!image1) return null;

    const hasTwoImages = image2?.length > 0;
    const srcset = [
        { vw: 1400, width: 700 },
        { vw: 1100, width: 610 },
        { vw: 800, width: 450 },
        { vw: 400, width: 330 },
    ];

    /**
     * The customWidth is set to the maximum width specified in srcset to ensure that the image resolution
     * does not exceed what is necessary for optimal display. This approach optimizes data usage and enhances
     * performance by avoiding the loading of images larger than needed, thus preventing excessive bandwidth consumption.
     */
    const customWidthImage = 700;

    return (
        <div className={styles["images"]} data-single-image={!hasTwoImages}>
            <div className={styles["images__inner"]}>
                <figure className={styles["images__figure"]}>
                    <ImagePartial
                        image={image1[0]}
                        className={styles["images__image"]}
                        srcset={hasTwoImages ? srcset : defaultFullScreenSrcset}
                        customWidth={customWidthImage}
                    />

                    {figcaption1 && <Figcaption text={figcaption1} />}
                </figure>

                {hasTwoImages && (
                    <figure className={styles["images__figure"]}>
                        <ImagePartial
                            image={image2[0]}
                            className={styles["images__image"]}
                            srcset={srcset}
                            customWidth={customWidthImage}
                        />

                        {figcaption2 && <Figcaption text={figcaption2} />}
                    </figure>
                )}
            </div>
        </div>
    );
}
