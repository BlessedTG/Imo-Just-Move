import Image from "../../../interfaces/image";

export default interface ComponentInterface {
    image1: Image[];
    figcaption1?: string;
    image2: Image[];
    figcaption2?: string;
}
