import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            image1: [
                {
                    filename:
                        "https://staging.assets.melkweg.nl/mock/event-2.jpg",
                    alt: "image 1",
                },
            ],
            figcaption1: "This is the figcaption",
            image2: [
                {
                    filename:
                        "https://staging.assets.melkweg.nl/mock/event-1.jpg",
                    alt: "image 2",
                },
            ],
            figcaption2: "This is the figcaption",
        },
        overwrite
    );
