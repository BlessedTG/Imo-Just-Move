import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

const mockQuestions: ComponentInterface["questions"] = [
    {
        key: "question-0",
        layout: "question",
        attributes: {
            question: "Are you dealing with a problem?",
            answers: [
                {
                    key: "answer-0",
                    layout: "answer",
                    attributes: {
                        label: "Yes",
                        problem: "problem-1",
                    },
                },
                {
                    key: "answer-1",
                    layout: "answer",
                    attributes: {
                        label: "No",
                        problem: null,
                    },
                },
            ],
        },
    },
];

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            questions: mockQuestions,
        },
        overwrite
    );
