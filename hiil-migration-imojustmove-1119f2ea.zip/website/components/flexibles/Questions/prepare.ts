import type {
    JsonApiObject,
    JsonApiResponse,
} from "../../../content/api-interfaces";
import type { Problem } from "../../../content/problems-interfaces";
import type ComponentInterface from "./interface";
import type {
    PreparedComponentInterface,
    PreparedQuestion,
    PreparedAnswer,
} from "./interface";

import { api as problemsApi } from "../../../content/problems";

import onlyUnique from "utils/only-unique";

export default async function prepare(
    props: ComponentInterface,
    pageData: JsonApiObject,
    included?: JsonApiObject[]
): Promise<PreparedComponentInterface> {
    const questions = props.questions;

    // Get all the possible connected problem ids from the questions
    // We will use this to prepare the answers with fetched problem data
    let problemIds: string[] = [];
    questions.forEach((question) => {
        question.attributes.answers.forEach((answer) => {
            if (answer.attributes.problem) {
                problemIds.push(answer.attributes.problem);
            }
        });
    });
    problemIds = problemIds.filter(onlyUnique);

    const problemsResponse = (await problemsApi
        .where("id", problemIds)
        .getAll()) as JsonApiResponse<Problem>;

    const problems: Problem[] = problemsResponse.data;

    let preparedQuestions: PreparedQuestion[] = questions.map((question) => {
        const preparedAnswers: PreparedAnswer[] =
            question.attributes.answers.map((answer) => {
                return {
                    label: answer.attributes.label,
                    problem: answer.attributes.problem
                        ? problems.find(
                              (problem) =>
                                  problem.id === answer.attributes.problem
                          ) || null
                        : null,
                };
            });
        return {
            question: question.attributes.question,
            answers: preparedAnswers,
        };
    });

    return {
        ...props,
        preparedQuestions: preparedQuestions,
    };
}
