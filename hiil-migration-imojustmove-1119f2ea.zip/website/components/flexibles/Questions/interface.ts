import type { Problem } from "../../../content/problems-interfaces";

type Answer = {
    key: string;
    layout: "answer";
    attributes: {
        label: string;
        problem: string | null;
    };
};

type Question = {
    key: string;
    layout: "question";
    attributes: {
        question: string;
        answers: Answer[];
    };
};

export interface PreparedAnswer {
    label: string;
    problem: Problem | null;
}

export interface PreparedQuestion {
    question: string;
    answers: PreparedAnswer[];
}

export interface GivenAnswer extends PreparedQuestion {
    givenAnswer: PreparedAnswer;
}

export default interface ComponentInterface {
    questions: Question[];
}

export interface PreparedComponentInterface extends ComponentInterface {
    preparedQuestions: PreparedQuestion[];
}
