import { useRouter } from "next/router";
import { useContext, useEffect } from "react";

import type ComponentInterface from "./interface";
import type { PreparedAnswer, GivenAnswer } from "./interface";
import type { PreparedComponentInterface } from "./interface";

import { TargetAudienceContext } from "context/target-audience";
import { UIContext } from "context/ui";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";

import useQuestionnaireAnswersState from "../../../hooks/use-questionnaire-answers-state";
import useQuestionnaireCompletedState from "../../../hooks/use-questionnaire-completed-state";
import useSetting from "../../../hooks/use-setting";
import useStepTrackerState from "../../../hooks/use-step-tracker-state";

import Question from "../../../components/modules/Question";
import OverlayContent from "components/modules/OverlayContent";

import ProgressBar from "../../modules/ProgressBar";
import QuestionnaireNoResult from "../../modules/QuestionnaireNoResult";
import QuestionnaireResults from "../../modules/QuestionnaireResults";

import prepare from "./prepare";

function Questions({ preparedQuestions }: PreparedComponentInterface) {
    const router = useRouter();
    const { setOverlayContent, overlayContent } = useContext(UIContext);
    const { homeUrl: targetAudienceHomeUrl } = useContext(
        TargetAudienceContext
    );
    // Get the current step, the next step, the previous step, and the reset function from the step tracker hook
    const { currentStep, nextStep, previousStep, resetTracker, isFirstStep } =
        useStepTrackerState(preparedQuestions.length);
    // Get the prepared question for the current step
    const preparedQuestion = preparedQuestions[currentStep - 1];
    // Get the given answers state and the function to set the given answers state from the questionnaire answers state hook
    const [givenAnswers, setGivenAnswers] = useQuestionnaireAnswersState([]);
    // Get the questionnaire completion state and the function to set the questionnaire completion state from the questionnaire completed hook
    const [questionnaireIsCompleted, setQuestionnaireIsCompleted] =
        useQuestionnaireCompletedState(false);

    const closeQuestionnaireOverlayContent = {
        title: useSetting("close_questionnaire_overlay_title"),
        description: useSetting("close_questionnaire_overlay_description"),
        linkLabel: useSetting("close_questionnaire_overlay_link_label"),
        linkURL: targetAudienceHomeUrl,
    };

    const closeQuestionnaireOverlay = (
        <OverlayContent overlayContent={closeQuestionnaireOverlayContent} />
    );

    const faqPageLinkLabel = useSetting("questionnaire_faq_page_link_label");
    const faqPageLink = useSetting("questionnaire_faq_page_link");

    const customLink = faqPageLinkLabel &&
        faqPageLink && { label: faqPageLinkLabel, url: faqPageLink };

    const handleNextStep = (answer: PreparedAnswer) => {
        // If the answer is null, then the user didn't select any answer and we need to return
        if (!answer) return;

        // If answer is already in the answers state, then we need to filter it out to replace it with the new one
        const filteredAnswers = givenAnswers?.filter(
            ({ question }) => question !== preparedQuestion.question
        );

        // Add the new given answer to the given answers state
        setGivenAnswers([
            ...filteredAnswers,
            {
                ...preparedQuestion,
                givenAnswer: answer,
            },
        ]);

        // If the answer has a problem, then the questionnaire is completed
        if (
            answer?.problem?.attributes?.url ||
            currentStep === preparedQuestions.length
        ) {
            setQuestionnaireIsCompleted(true);
            return;
        }

        // Go to the next step
        nextStep();
    };

    // Remove the last answer from the given answers state and go to the previous step so the answer is removed from the given answers state
    const handlePreviousStep = () => {
        setGivenAnswers((givenAnswers: GivenAnswer[]) =>
            givenAnswers.slice(0, -1)
        );
        if (isFirstStep()) {
            setOverlayContent(closeQuestionnaireOverlay);
            return;
        }
        previousStep();
    };

    // Reset the questionnaire by resetting the step tracker, the given answers state, and the questionnaire completion state
    const resetQuestionnaire = () => {
        resetTracker();
        setGivenAnswers([]);
        setQuestionnaireIsCompleted(false);
    };

    // Get the problem from the given answers state.
    // This is not stored in the state because else it needs to be stored in the local storage as well.
    // Instead, we get it from the given answers state when needed.
    const getProblemFromGivenAnswers = () =>
        givenAnswers?.find(
            (answer: GivenAnswer) => answer?.givenAnswer?.problem
        )?.givenAnswer?.problem ?? null;

    const steps = [
        useSetting("first_step_label"),
        useSetting("second_step_label"),
        useSetting("third_step_label"),
        useSetting("fourth_step_label"),
    ];

    // Reset the stored questionnaire state when the route changes
    useEffect(() => {
        router.events.on("routeChangeComplete", resetQuestionnaire);

        return () => {
            router.events.off("routeChangeComplete", resetQuestionnaire);
        };
    }, [router]);

    const questionnaireSettings = {
        restartButtonLabel: useSetting("questionnaire_restart_button_label"),
        resultsTitle: useSetting("questionnaire_results_title"),
        outcomeButtonLabel: useSetting("questionnaire_outcome_button_label"),
        analysisTitle: useSetting("questionnaire_analysis_title"),
        analysisResultSubtitle: useSetting("questionnaire_result_subtitle"),
        noResultTitle: useSetting("questionnaire_no_result_title"),
        requestAssistanceLabel: useSetting(
            "questionnaire_request_assistance_button_label"
        ),
    };

    const showResults =
        questionnaireIsCompleted && getProblemFromGivenAnswers();
    const showNoResult =
        questionnaireIsCompleted && !getProblemFromGivenAnswers();

    return (
        <div>
            <ProgressBar steps={steps} activeStep={1} />
            {!questionnaireIsCompleted && (
                <Question
                    question={preparedQuestion}
                    currentStep={currentStep}
                    nextStep={handleNextStep}
                    previousStep={handlePreviousStep}
                />
            )}
            {showResults && (
                <QuestionnaireResults
                    problem={getProblemFromGivenAnswers()}
                    givenAnswers={givenAnswers}
                    restartButtonLabel={
                        questionnaireSettings.restartButtonLabel
                    }
                    resultsTitle={questionnaireSettings.resultsTitle}
                    outcomeButtonLabel={
                        questionnaireSettings.outcomeButtonLabel
                    }
                    analysisTitle={questionnaireSettings.analysisTitle}
                    analysisResultSubtitle={
                        questionnaireSettings.analysisResultSubtitle
                    }
                    onRestart={resetQuestionnaire}
                />
            )}
            {showNoResult && (
                <QuestionnaireNoResult
                    title={questionnaireSettings.noResultTitle}
                    {...(customLink && { customLink })}
                    restartButtonLabel={
                        questionnaireSettings.restartButtonLabel
                    }
                    requestAssistanceLabel={
                        questionnaireSettings.requestAssistanceLabel
                    }
                    onRestart={resetQuestionnaire}
                />
            )}
        </div>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(Questions);
