import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "Give feedback",
            text: "Lorem ipsum dolor sit amet consectetur. Massa libero nulla pharetra parturient ipsum amet aliquet venenatis.",
            label: "Did you find the information on this page useful?",
            placeholder: "Please type your feedback...",
        },
        overwrite
    );
