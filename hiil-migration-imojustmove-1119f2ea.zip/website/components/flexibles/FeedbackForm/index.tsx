import { FormEvent, useContext, useMemo, useRef, useState } from "react";
import { SettingKey } from "types/generated";

import type ComponentInterface from "./interface";
import type { FeedbackFormConfig } from "./interface";

import handleForm, { FormHandlerResponse } from "utils/handle-form";

import useSettings from "hooks/use-settings";

import RichContent from "components/modules/RichContent";
import { LanguageContext } from "components/modules/WithMultilingual";
import FormMessage from "components/partials/FormMessage";
import SubmitButton from "components/partials/SubmitButton";

import HappySmiley from "public/icons/happy-smiley.svg";
import SadSmiley from "public/icons/sad-smiley.svg";

import styles from "./styles.module.scss";

function getFormConfig(
    settings: Record<SettingKey, string>
): FeedbackFormConfig {
    const uniqueId = crypto.randomUUID();
    const prefixUid = (key: string) => `${uniqueId}-${key}`;
    return {
        version: "1",
        name: "feedback_form",
        successTitle: settings.feedback_form_success_title,
        successMessage: settings.feedback_form_success_message,
        failedTitle: settings.feedback_form_error_title,
        failedMessage: settings.feedback_form_error_message,
        submitButtonLabel: settings.feedback_form_submit_button_label,
        elements: {
            sentiment: {
                id: prefixUid("sentiment"),
                name: "sentiment",
                type: "radio",
                required: true,
                options: [
                    {
                        label: settings.feedback_form_positive_label,
                        value: "positive",
                    },
                    {
                        label: settings.feedback_form_negative_label,
                        value: "negative",
                    },
                ],
                instruction: settings.intake_form_name_instruction,
            },
            message: {
                id: prefixUid("message"),
                name: "message",
                type: "textarea",
                required: true,
                label: settings.feedback_form_message_label,
                instruction: settings.feedback_form_instruction,
            },
        },
    };
}

export default function FeedbackForm({ title, text }: ComponentInterface) {
    const settings = useSettings();
    const currentLanguage = useContext(LanguageContext);
    const formConfig = useMemo(() => getFormConfig(settings), []);

    const formMessageRef = useRef<HTMLDivElement>(null);
    const [formResponse, setFormResponse] =
        useState<FormHandlerResponse | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
        const form = event.currentTarget;
        setIsSubmitting(true);
        event.preventDefault();
        const formData = new FormData(event.currentTarget);
        const response = await handleForm(formData);
        if (response.success) {
            form.reset();
        }
        setFormResponse(response);
        formMessageRef?.current?.scrollIntoView();
        setIsSubmitting(false);
    };

    const formAction = process.env.NEXT_PUBLIC_FORM_HANDLER_ENDPOINT;
    const { elements } = formConfig;

    return (
        <div className={styles["feedback-form"]}>
            <div className={styles["feedback-form__inner"]}>
                <div className={styles["feedback-form__content"]}>
                    <h2 className={styles["feedback-form__title"]}>{title}</h2>
                </div>

                <form
                    action={formAction}
                    onSubmit={handleSubmit}
                    className={styles["feedback-form__form"]}
                >
                    <input
                        type="hidden"
                        name="form_name"
                        value={formConfig.name}
                    />
                    <div className={styles["feedback-form__description"]}>
                        <RichContent cmsContent={text} />
                    </div>

                    <fieldset
                        className={styles["feedback-form__radio-wrapper"]}
                    >
                        <legend className={styles["feedback-form__legend"]}>
                            {/* TODO change the Arabic translation */}
                            {currentLanguage === "en"
                                ? "General experience"
                                : "General experience"}
                        </legend>

                        <input
                            className={styles["feedback-form__radio-input"]}
                            type="radio"
                            id={`${elements.sentiment.name}-positive`}
                            name={elements.sentiment.name}
                            value="positive"
                            required
                        />
                        <label
                            className={styles["feedback-form__label"]}
                            htmlFor={`${elements.sentiment.name}-positive`}
                        >
                            <span
                                className={styles["feedback-form__label-text"]}
                            >
                                {/* @TODO change the Arabic translation */}

                                {currentLanguage === "en"
                                    ? "Positive feedback"
                                    : "Positive feedback"}
                            </span>
                            <HappySmiley
                                className={styles["feedback-form__icon"]}
                            />
                        </label>

                        <input
                            className={styles["feedback-form__radio-input"]}
                            type="radio"
                            id={`${elements.sentiment.name}-negative`}
                            name={formConfig.elements.sentiment.name}
                            value="negative"
                            required
                        />
                        <label
                            className={styles["feedback-form__label"]}
                            htmlFor={`${elements.sentiment.name}-negative`}
                        >
                            <span
                                className={styles["feedback-form__label-text"]}
                            >
                                {/* TODO change the Arabic translation */}
                                Negative feedback
                                {currentLanguage === "en"
                                    ? "Negative feedback"
                                    : "Negative feedback"}
                            </span>
                            <SadSmiley
                                className={styles["feedback-form__icon"]}
                            />
                        </label>
                    </fieldset>

                    <fieldset className={styles["feedback-form__text-wrapper"]}>
                        <legend className={styles["feedback-form__legend"]}>
                            Detailed experience
                        </legend>

                        <label
                            className={styles["feedback-form__label"]}
                            htmlFor={elements.message.name}
                        >
                            {elements.message.label}
                        </label>
                        <textarea
                            className={styles["feedback-form__textarea"]}
                            placeholder={elements.message.instruction}
                            id={elements.message.name}
                            name={elements.message.name}
                            required
                        />
                    </fieldset>

                    <SubmitButton label={formConfig.submitButtonLabel} />
                    <div
                        ref={formMessageRef}
                        className={styles["intake-form__submit-message"]}
                    >
                        {formResponse && (
                            <FormMessage
                                status={
                                    formResponse.success ? "success" : "error"
                                }
                                title={
                                    formResponse.success
                                        ? formConfig.successTitle
                                        : formConfig.failedTitle
                                }
                                message={
                                    formResponse.success
                                        ? formConfig.successMessage
                                        : formConfig.failedMessage
                                }
                            />
                        )}
                    </div>
                </form>
            </div>
        </div>
    );
}
