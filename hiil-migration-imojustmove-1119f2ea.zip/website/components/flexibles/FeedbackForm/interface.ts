import { FormConfig, FormConfigElement } from "interfaces/form-config";

export default interface ComponentInterface {
    title: string;
    text: string;
}

export interface FeedbackFormConfig extends FormConfig {
    name: "feedback_form";
    elements: {
        sentiment: FormConfigElement;
        message: FormConfigElement;
    };
}
