import type ComponentInterface from "./interface";

import RichContent from "components/modules/RichContent";
import Button from "components/partials/Button";
import Image from "components/partials/Image";
import Video from "components/partials/Video";

import styles from "./styles.module.scss";

const srcset = [
    { vw: 500, width: 800 },
    { vw: 300, width: 500 },
];

/**
 * The customWidth is set to the maximum width specified in srcset to ensure that the image resolution
 * does not exceed what is necessary for optimal display. This approach optimizes data usage and enhances
 * performance by avoiding the loading of images larger than needed, thus preventing excessive bandwidth consumption.
 */
const customWidthImage = 900;

export default function TextMedia({
    title,
    text,
    image,
    link,
    videoID,
}: ComponentInterface) {
    return (
        <div className={styles["text-media"]}>
            <div className={styles["text-media__inner"]}>
                {!videoID && image && (
                    <figure className={styles["text-media__media"]}>
                        <Image
                            image={image[0]}
                            srcset={srcset}
                            customWidth={customWidthImage}
                            className={styles["text-media__image"]}
                        />
                    </figure>
                )}
                {videoID && (
                    <div className={styles["text-media__video"]}>
                        <Video videoID={videoID} />
                    </div>
                )}
                <div className={styles["text-media__content"]}>
                    <h2 className={styles["text-media__title"]}>{title}</h2>
                    <div className={styles["text-media__text"]}>
                        <RichContent cmsContent={text} />
                    </div>
                    {
                        // The link is always an array even if it only contains one item.
                        // This is because the CMS always returns an array.
                        // We have to access the first item in the array to get the actual link data.
                        link && link.length > 0 && (
                            <div
                                className={
                                    styles[
                                        "link-through__list-item-link-wrapper"
                                    ]
                                }
                            >
                                <Button
                                    url={
                                        link?.[0].attributes?.urlType ===
                                        "external"
                                            ? link?.[0].attributes.externalUrl
                                            : link?.[0].attributes.url
                                    }
                                    isExternalLink={
                                        link?.[0].attributes?.urlType ===
                                        "external"
                                    }
                                    theme="link"
                                    targetBlank={
                                        link?.[0].attributes.targetBlank
                                    }
                                    hasChevronIcon={true}
                                >
                                    {link?.[0].attributes?.label}
                                </Button>
                            </div>
                        )
                    }
                </div>
            </div>
        </div>
    );
}
