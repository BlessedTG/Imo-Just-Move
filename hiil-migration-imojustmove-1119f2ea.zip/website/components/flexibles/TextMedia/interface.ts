import type Image from "../../../interfaces/image";
import { Link } from "../../../interfaces/link";

export default interface ComponentInterface {
    title: string;
    text: string;
    image?: Image[];
    link?: Link[];
    videoID?: string;
}
