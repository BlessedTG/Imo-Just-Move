import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "Title",
            text: "Tincidunt iaculis morbi cras ut malesuada pulvinar purus. Eget auctor dictumst volutpat, amet duis ac.",
            image: [
                {
                    filename:
                        "https://staging.assets.melkweg.nl/mock/event-3.jpg",
                    alt: "background image 3",
                },
            ],
            link: [
                {
                    layout: "link",
                    key: "link-text-2",
                    attributes: {
                        label: "Link 2",
                        value: "/",
                    },
                },
            ],
        },
        overwrite
    );
