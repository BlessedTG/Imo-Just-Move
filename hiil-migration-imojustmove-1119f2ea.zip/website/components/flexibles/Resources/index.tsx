import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";

import CardButton from "../../partials/CardButton";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function Resources({ title, pages }: PreparedComponentInterface) {
    return (
        <div className={styles["resources"]}>
            <section className={styles["resources__inner"]}>
                <h2 className={styles["resources__title"]}>{title}</h2>
                <ul className={styles["resources__page-previews-list"]}>
                    {pages.map(
                        ({ id, attributes: { url, title, metadata } }) => (
                            <li key={`page-previews-list-item-${id}`}>
                                {/* @TODO Add the image from the page when this has been added in the CMS */}
                                <CardButton
                                    title={title}
                                    subtitle={metadata?.page_preview_subtext}
                                    url={url}
                                />
                            </li>
                        )
                    )}
                </ul>
            </section>
        </div>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(Resources);
