import type { DefaultPage } from "../../../content/pages-interfaces";

export default interface ComponentInterface {
    title: string;
    page_previews: string[];
}

export interface PreparedComponentInterface extends ComponentInterface {
    title: string;
    pages: DefaultPage[];
}
