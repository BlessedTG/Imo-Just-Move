import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import mockPages from "../../../content/pages";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;
type PartialPreparedComponentInterface = Subset<PreparedComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            title: "Resources",
            page_previews: ["page-1", "page-2"],
        },
        overwrite
    );

export const generateMockContentWithPrepare = (
    overwrite: PartialPreparedComponentInterface = {}
): PreparedComponentInterface =>
    deepMerge<PreparedComponentInterface>(
        {
            title: "Resources",
            pages: mockPages,
        },
        overwrite
    );
