import type {
    JsonApiObject,
    JsonApiResponse,
} from "../../../content/api-interfaces";
import type { DefaultPage } from "../../../content/pages-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import { api as pagesApi } from "../../../content/pages";

import sortByOrder from "../../../utils/sort-by-order";

export default async function prepare(
    props: ComponentInterface,
    pageData: JsonApiObject,
    included?: JsonApiObject[]
): Promise<PreparedComponentInterface> {
    const pageIds = props.page_previews;
    const pagesResponse = (await pagesApi
        .where("id", pageIds)
        .getAll()) as JsonApiResponse<DefaultPage>;

    return {
        ...props,
        title: props.title,
        pages: pagesResponse.data
            .filter((page: DefaultPage) =>
                props.page_previews.includes(page.id)
            )
            .sort(sortByOrder(pageIds, "id")),
    };
}
