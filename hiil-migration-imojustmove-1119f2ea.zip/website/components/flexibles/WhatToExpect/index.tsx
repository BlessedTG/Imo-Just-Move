import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";

import Button from "../../partials/Button";
import Image from "../../partials/Image";
import ReadSpeakerButton from "../../partials/ReadSpeakerButton";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function WhatToExpect({
    title,
    steps,
    return_link,
    continue_link,
}: PreparedComponentInterface) {
    const returnLink = return_link?.[0];
    const continueLink = continue_link?.[0];

    return (
        <div className={styles["what-to-expect"]}>
            <section className={styles["what-to-expect__inner"]}>
                {process.env.NEXT_PUBLIC_SHOW_READSPEAKER === "true" && (
                    <div
                        className={
                            styles["what-to-expect__speaker-button-wrapper"]
                        }
                    >
                        <ReadSpeakerButton />
                    </div>
                )}
                <h1 className={styles["what-to-expect__title"]}>{title}</h1>
                <ol className={styles["what-to-expect__step-list"]}>
                    {steps.map(
                        ({ layout, key, attributes: { text, image } }) => (
                            <li
                                key={`${layout}-${key}`}
                                className={styles["what-to-expect__step"]}
                            >
                                {image && (
                                    <figure
                                        className={
                                            styles["what-to-expect__step-image"]
                                        }
                                    >
                                        <Image
                                            image={image}
                                            srcset={[]}
                                            customWidth={200}
                                        />
                                    </figure>
                                )}
                                {text}
                            </li>
                        )
                    )}
                </ol>
                <div className={styles["what-to-expect__button-container"]}>
                    {returnLink && (
                        <div
                            className={
                                styles["what-to-expect__return-button-wrapper"]
                            }
                        >
                            {/* There are two buttons here, one for desktop and one for mobile.
                            The mobile button has a different theme (secondary-light) then the desktop button (link).
                            [data-is-visible-on-mobile] is used to hide the desktop button on mobile and vice versa via CSS instead of JS. */}
                            <Button
                                url={
                                    returnLink?.attributes?.urlType ===
                                    "external"
                                        ? returnLink.attributes.externalUrl
                                        : returnLink.attributes.url
                                }
                                theme="link"
                                iconPosition="left"
                                data-is-visible-on-mobile="false"
                                isExternalLink={
                                    returnLink?.attributes?.urlType ===
                                    "external"
                                }
                                hasChevronIcon={true}
                            >
                                {returnLink?.attributes?.label}
                            </Button>
                            <Button
                                url={
                                    returnLink?.attributes?.urlType ===
                                    "external"
                                        ? returnLink.attributes.externalUrl
                                        : returnLink.attributes.url
                                }
                                theme="secondary-light"
                                isFluid={true}
                                data-is-visible-on-mobile="true"
                            >
                                {returnLink?.attributes?.label}
                            </Button>
                        </div>
                    )}
                    {continueLink && (
                        <div>
                            <Button
                                url={
                                    continueLink?.attributes?.urlType ===
                                    "external"
                                        ? continueLink.attributes.externalUrl
                                        : continueLink.attributes.url
                                }
                                theme="primary"
                                iconPosition="left"
                                isFluid={true}
                            >
                                {continueLink.attributes.label}
                            </Button>
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(WhatToExpect);
