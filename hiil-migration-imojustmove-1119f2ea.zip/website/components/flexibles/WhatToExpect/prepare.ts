import type { JsonApiObject } from "../../../content/api-interfaces";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import type { RenderedResources } from "utils/page-render-helpers";

export default function prepare(
    props: ComponentInterface,
    pageData: RenderedResources,
    included?: JsonApiObject[]
): PreparedComponentInterface {
    if (!("template" in pageData.attributes)) {
        throw new Error("The pageData is missing the template attribute");
    }

    return {
        ...props,
        title: pageData?.attributes.title,
    };
}
