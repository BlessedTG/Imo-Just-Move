import Image from "../../../interfaces/image";
import { Link } from "../../../interfaces/link";

export default interface ComponentInterface {
    steps: Step[];
    return_link: Link[];
    continue_link: Link[];
}

export interface Step {
    layout: "step";
    key: string;
    attributes: {
        text: string;
        image: Image;
    };
}

export interface PreparedComponentInterface extends ComponentInterface {
    title: string;
    steps: Step[];
}
