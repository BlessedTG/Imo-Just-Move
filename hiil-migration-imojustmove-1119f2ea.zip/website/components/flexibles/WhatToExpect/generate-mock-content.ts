import type { Subset } from "../../../interfaces/subset";
import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import deepMerge from "../../../utils/deep-merge";

type PartialComponentInterface = Subset<ComponentInterface>;
type PartialPreparedComponentInterface = Subset<PreparedComponentInterface>;

export default (
    overwrite: PartialComponentInterface = {}
): ComponentInterface =>
    deepMerge<ComponentInterface>(
        {
            steps: [
                {
                    layout: "step",
                    key: "step-1",
                    attributes: {
                        text: "You need to select the overall category you problem belongs to",
                    },
                },
                {
                    layout: "step",
                    key: "step-2",
                    attributes: {
                        text: "You will be asked questions to better understand the nature of the problem",
                    },
                },
                {
                    layout: "step",
                    key: "step-3",
                    attributes: {
                        text: "You will be asked to choose the outcome",
                    },
                },
                {
                    layout: "step",
                    key: "step-4",
                    attributes: {
                        text: "In the end you will be offered the right steps and contacts that can help you solve your problem",
                    },
                },
            ],
            return_link: [
                {
                    layout: "return_link",
                    key: "return-link",
                    attributes: {
                        label: "Go back",
                        url: "/",
                    },
                },
            ],
            continue_link: [
                {
                    layout: "continue_link",
                    key: "continue-link",
                    attributes: {
                        label: "I understand",
                        url: "/",
                    },
                },
            ],
        },
        overwrite
    );

export const generateMockContentWithPrepare = (
    overwrite: PartialPreparedComponentInterface = {}
): PreparedComponentInterface =>
    deepMerge<PreparedComponentInterface>(
        {
            steps: [
                {
                    layout: "step",
                    key: "step-1",
                    attributes: {
                        title: "You need to select the overall category you problem belongs to",
                    },
                },
                {
                    layout: "step",
                    key: "step-2",
                    attributes: {
                        title: "You will be asked questions to better understand the nature of the problem",
                    },
                },
                {
                    layout: "step",
                    key: "step-3",
                    attributes: {
                        title: "You will be asked to choose the outcome",
                    },
                },
                {
                    layout: "step",
                    key: "step-4",
                    attributes: {
                        title: "In the end you will be offered the right steps and contacts that can help you solve your problem",
                    },
                },
            ],
            return_link: [
                {
                    layout: "return_link",
                    key: "return-link",
                    attributes: {
                        label: "Go back",
                        url: "/",
                    },
                },
            ],
            continue_link: [
                {
                    layout: "continue_link",
                    key: "continue-link",
                    attributes: {
                        label: "I understand",
                        url: "/",
                    },
                },
            ],
        },
        overwrite
    );
