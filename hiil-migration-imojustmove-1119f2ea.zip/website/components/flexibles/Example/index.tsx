import type ComponentInterface from "./interface";
import type { PreparedComponentInterface } from "./interface";

import withPrepare from "../../../utils/create-full-page-data/with-prepare";

import prepare from "./prepare";
import styles from "./styles.module.scss";

function Example({ title, menuItems }: PreparedComponentInterface) {
    return (
        <section className={styles["example"]}>
            <h2 className={styles["example__title"]}>{title}</h2>

            <ul>
                {menuItems.map((menuItem) => (
                    <li key={menuItem.id}>{menuItem.attributes.name}</li>
                ))}
            </ul>
        </section>
    );
}

export default withPrepare<ComponentInterface, PreparedComponentInterface>(
    prepare
)(Example);
