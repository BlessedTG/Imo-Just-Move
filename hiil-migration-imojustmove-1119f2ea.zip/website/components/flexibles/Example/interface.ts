import type { MenuItem } from "../../../content/menus-interface";

export default interface ComponentInterface {
    title: string;
}

export interface PreparedComponentInterface extends ComponentInterface {
    menuItems: MenuItem[];
}
