import type { JsonApiObject } from "../../../content/api-interfaces";
import type { Page } from "../../../content/pages-interfaces";
import type ComponentInterface from "./interface";

import type { RenderedResources } from "../../../utils/page-render-helpers";

export default function prepare(
    props: ComponentInterface,
    page: RenderedResources,
    included?: JsonApiObject[]
) {
    return {
        ...props,
        menuItems: [],
    };
}
