# Next.js website

This repository contains the code for the Next.js website. The website is a statically generated Next.js application. It uses the Next.js Pages router to generate static pages for the website. It is published from within the CMS via a Nova Action that builds the site and deploys it to the server. See [DEPLOYMENT.md](../DEPLOYMENT.md) for details.

## Table of contents

- [Requirements](#requirements)
- [Setup](#setup)
- [Editor setup](#editor-setup)
    - [Update VSCode settings JSON](#update-vscode-settings-json)
- [Import order](#import-order)
- [Adding new flexibles, modules or partials](#adding-new-flexibles-modules-or-partials)

## Requirements

- Node 20.x
- npm

## Setup

Install the app

- `npm install`
- `cp .env.example .env`

CLI commands

- `npm run dev` or `npm run watch`: run the app in development mode: http://localhost:3000
- `npm run static`: run a statically generated version of the app
- `npm run deploy`: build the site in production mode

Format and test commands

- `npm run format`: Format all files with Prettier
- `npm run test`: Run Jest, currently only containing unit-tests
- `npm run lint`: Run ESLint and StyleLint
    - `npm run lint:js`: Run ESLint
    - `npm run lint:css`: Run StyleLint
    - `npm run lint:ts`: Run TSLint

## Theming

### Colors

There is a environment variable `SITE_VARIANT` that is used for theming. The `styles/theme-colors.scss` file contains different color themes for each variant.

### Logos

Each site variant has its own logo in the `public` folder, named `site-logo-<SITE-VARIANT>.svg` (e.g. `site-logo-tunisia.svg`).

## API Authentication

To authenticate with the API, you will need an api token. This can be generated in Nova. Add the token to the `.env` file as `API_TOKEN`.

## Editor setup

For a nicer dev experience install the `ESLint`, `StyleLint` and `Prettier` extensions.

### Update VSCode settings (JSON)

- Add `"editor.defaultFormatter": "esbenp.prettier-vscode",` to make prettier the default formatter
- Add `"editor.formatOnSave": true,` to auto-format the file each time you safe it

## Import order

Given each page or component can contain a lot of dependencies, it's advisable to order the dependencies based on type. Below you can find the correct order, each group should be imported with a newline between them.

- **Root dependencies**: mostly live in the node modules and are included in the package.json
- **Interfaces**: Of global, package or modules. Add `type` before the interface name
- **Content/Context**: Lives inside the content folder
- **Mock**: Mock data, mostly lives in the mock folder
- **Config**: Static configuration
- **Utils**: Simple util functions
- **Components**: Live inside the components folder, preferably included in order: Flexibles, Modules, Parts, motion.
- **Prepare**: Live inside same folder as the corresponding component
- **Styles**: Live inside same folder as the corresponding component

## Adding new flexibles, modules or partials

To reduce the manual work of setting up the boilerplate code for a new component, we introduces a [generate component util](https://github.com/MartijnNieuwenhuizen/generate-component).
This util will add all the necessary files with the correct file/variable names. The possible commands are:

- `npm run make-flexible [ComponentName]`: Make a flexible without a prepare function.
- `npm run make-flexible-with-prepare [ComponentName]`: Make a flexible with a prepare function.
- `npm run make-module [ComponentName]`: Make a module
- `npm run make-partial [ComponentName]`: Make a partial

### Flexible prepare option

A Flexible contains an option to contain a prepare function. This function is used to get data needed in the component that cannot come directly from the Flexible CMS part. Examples of these types of data are:

Global Settings
Other pages like (3 relevant projects)
Page data like a page theme or page type
The prepare function can fetch this data during the build step and pass it through to the Flexible. This prevents Next.js from containing too much data in the **NEXT_DATA** object inside the HTML.

### Modules

Components that are bigger than a single element like a button or a heading. These modules are often used as building blocks by the flexibles. A module doesn't have the possibility to contain a prepare function, therefore, all data should be passed into the module directly

### Partials

Components that are really small blocks. Think of buttons, links, logos etc.
