<?php
namespace Deployer;

use Deployer\Exception\RunException;

require 'recipe/laravel.php';

// Config
set('bin/php', '/opt/remi/php82/root/usr/bin/php');
set('bin/npm', '/usr/bin/npm'); // Define the absolute path to the npm binary

// Fill out these application details:
set('application', 'HiiL CMS'); // TODO: Can this be a variable? as option
set('repository', 'git@github.com:norday-agency/hiil.git');
set('keep_releases', 2);

set('sub_directory', 'cms');

// [Optional] Allocate tty for git clone. Default value is false.
set('git_tty', true);

// Shared files/dirs between deploys
add('shared_files', ['website/.env']);
add('shared_dirs', []);
add('writable_dirs', []);
set('allow_anonymous_stats', false);
set('writable_mode', 'chmod'); // By default it's ACL, but the servers don't support that.

// Use timestamps for releases, instead of numbers.
// See https://stackoverflow.com/questions/48296476/deployer-org-how-to-change-releases-folders-name
set('release_name', function () {
    return (string) run('date +"%Y%m%d%H%M%S"');
});

// Hosts

host('admin.imojustmove.org')
    ->setLabels([
        'hosting_strategy' => 'one_server_with_multiple_vhosts',
    ])
    ->set('hostname', 'hiil-cms1.cust.webslice.eu')
    ->set('remote_user', 'hiil')
    ->set('deploy_path', '/home/hiil/html/admin.imojustmove.org')
    ->set('ssh_path', '~{{remote_user}}/.ssh')
    ->set('git_ssh_command', 'ssh -i {{ssh_path}}/id_ed25519');

// Tasks
desc('Create the deploy key for GitHub and output the public key.');
task('github:create_deploy_key', function () {
    $keyAlreadyExists = test('[[ -f {{ssh_path}}/id_ed25519.pub ]]');

    // Check whether the key already exists.
    if ($keyAlreadyExists) {
        $existingKey = run('cat {{ssh_path}}/id_ed25519.pub');
        info("A key already exists: $existingKey");
        info(
            'If you want to recreate the key, please login to the server and remove the existing key first.'
        );
        return;
    }
    info('Creating a new deploy key...');

    run("ssh-keygen -t ed25519 -N \"\" -f {{ssh_path}}/id_ed25519");
    $key = run('cat {{ssh_path}}/id_ed25519.pub');
    /**
     * Change git@github.com:grrr-amsterdam/example.git into https://github.com/grrr-amsterdam/example/settings/keys
     */
    $settingsUrl =
        str_replace(
            [':', 'git@', '.git'],
            ['/', 'https://', ''],
            get('repository')
        ) . '/settings/keys';

    info("Your deploy key is ready: $key");
    info(
        "Go to your repository on GitHub, and add the key to your settings: {$settingsUrl}"
    );
});

desc('Use ssh-keyscan to add github.com to the known_hosts file.');
task('github:allow_connection', function () {
    run(
        'ssh-keyscan -F github.com || ssh-keyscan -t rsa github.com >> {{ssh_path}}/known_hosts',
        ['no_throw' => true]
    );
    info('Added github.com to known_hosts');
});

desc(
    'Execute ssh -T git@github.com on the server to verify this server can connect to the given repository.'
);
task('github:verify_connection', function () {
    try {
        run('ssh -T git@github.com -i {{ssh_path}}/id_ed25519');
    } catch (RunException $e) {
        // Unfortunately the exit code of the ssh -T command is not 0, so it's marked as an error.
        $output = trim($e->getErrorOutput());
        if (
            str_ends_with(
                $output,
                "You've successfully authenticated, but GitHub does not provide shell access."
            )
        ) {
            info($output);
            return;
        }
        throw $e;
    }
});

// Project version, use current branch when tag is not provided
desc('Store app version in .env');
task('app:store_version', function () {
    $version = get('target');
    run(
        "sed -i 's@^APP_VERSION.*@APP_VERSION=\"$version\"@g' {{deploy_path}}/shared/.env"
    );
});

desc('Create .env file for laravel');
task('laravel:setup-env', function () {
    $sharedPath = '{{deploy_path}}/shared';
    $envFile = "$sharedPath/.env";

    $releasePath = get('release_path');
    $envExampleFile = "$releasePath/.env.example";

    if (!test("[ -d $sharedPath ]")) {
        run("mkdir $sharedPath");
    }

    if (!test("[ -f $envFile ]")) {
        run("cp $envExampleFile $envFile");
    }
});
// Ensure .env file is populated with .env.example.
before('deploy:shared', 'laravel:setup-env');

desc('Create .env file for website');
task('website:setup-env', function () {
    $sharedPath = '{{deploy_path}}/shared';
    $envDir = "$sharedPath/website";
    $envFile = "$envDir/.env";

    // Local path to .env.example
    $localEnvExample = realpath(__DIR__ . '/../website/.env.example');

    if (!file_exists($localEnvExample)) {
        throw new \RuntimeException('Local website/.env.example not found.');
    }

    // Ensure shared/website directory exists on server
    if (!test("[ -d $envDir ]")) {
        run("mkdir -p $envDir");
    }

    // If .env does not exist on server, upload .env.example as .env
    if (!test("[ -f $envFile ]")) {
        upload($localEnvExample, $envFile);
    }
})->select('hosting_strategy=one_server_with_multiple_vhosts');
// Ensure .env file is populated with .env.example.
before('deploy:shared', 'website:setup-env');

desc(
    'Copy Next.js website files to the release path, excluding build/output directories (no rsync, use gzip/ungzip)'
);
task('deploy:copy_website_files', function () {
    info(
        'Copying Next.js website source files to the release path excluding .gitignore patterns'
    );
    $releasePath = get('release_path');
    $websiteFilesPath = "$releasePath/website";
    $localWebsitePath = realpath(__DIR__ . '/../website');

    info('Creating website files directory: ' . $localWebsitePath);

    // Use .gitignore patterns for excludes
    $gitignoreFile = $localWebsitePath . '/.gitignore';
    $excludes = [];
    if (file_exists($gitignoreFile)) {
        $lines = file(
            $gitignoreFile,
            FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES
        );
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line === '' || $line[0] === '#') {
                continue;
            }
            // Remove leading slash for consistency
            $line = ltrim($line, '/');
            // Remove trailing slash for directories
            $line = rtrim($line, '/');
            $excludes[] = $line;
        }
    }

    info(
        'Excluding the following directories/files from the website files copy: ' .
            implode(', ', $excludes)
    );

    // Add .git folder to the excludes if it exists
    if (is_dir($localWebsitePath . '/.git')) {
        $excludes[] = '.git';
    }

    // Build find exclude params
    $excludeParams = '';
    foreach ($excludes as $exclude) {
        // If the exclude is ".env", make sure not to exclude ".env.example"
        if ($exclude === '.env') {
            $excludeParams .= " -not \\( -path './.env' \\)";
        } else {
            $excludeParams .= " -not -path './$exclude*'";
        }
    }

    // Create a file list of files to include
    $fileList = tempnam(sys_get_temp_dir(), 'website_files');
    runLocally(
        "cd \"$localWebsitePath\" && find . -type f $excludeParams > \"$fileList\""
    );

    // Create a tar archive (since gzip/ungzip only compresses single files, not directories)
    $archiveFile = tempnam(sys_get_temp_dir(), 'website') . '.tar';
    $tarCmd = "tar -cf \"$archiveFile\" -T \"$fileList\"";
    // On macOS, prevent AppleDouble files (._) by using --disable-copyfile
    if (strtoupper(substr(PHP_OS, 0, 6)) === 'DARWIN') {
        $tarCmd = "COPYFILE_DISABLE=1 tar --disable-copyfile -cf \"$archiveFile\" -T \"$fileList\"";
    }
    runLocally("cd \"$localWebsitePath\" && $tarCmd");

    // Compress the tar archive with gzip
    $gzFile = $archiveFile . '.gz';
    runLocally("gzip -c \"$archiveFile\" > \"$gzFile\"");

    // Upload the gzipped tarball to the server
    upload($gzFile, "$websiteFilesPath.tar.gz");

    // Extract on the server
    run("mkdir -p $websiteFilesPath");
    run("gunzip -c $websiteFilesPath.tar.gz | tar -xf - -C $websiteFilesPath");
    run("rm $websiteFilesPath.tar.gz");

    // Remove local temp files
    runLocally("rm \"$fileList\" \"$archiveFile\" \"$gzFile\"");

    // Install npm dependencies on the server
    run("cd $websiteFilesPath && {{bin/npm}} install --no-audit");
})->select('hosting_strategy=one_server_with_multiple_vhosts');
after('deploy:prepare', 'deploy:copy_website_files');

desc('Authenticate Nova');
task('app:authenticate_nova', function () {
    $novaIsAuthenticated = test(
        '{{bin/composer}} config --global --list | grep -q http-basic.nova.laravel.com'
    );
    if ($novaIsAuthenticated) {
        info('Nova credentials have been configured.');
        return;
    }
    $username = ask('Nova username');
    $password = askHiddenResponse('Nova password');
    run(
        "{{bin/composer}} config --global http-basic.nova.laravel.com $username $password"
    );
});

desc('Seeds default settings if they not exist already.');
task('artisan:app:seed-settings', artisan('app:seed-settings'));

desc('Seed default roles and permissions');
task(
    'app:seed-roles-and-permissions',
    artisan('db:seed --force --class=RolesAndPermissionsSeeder')
);
desc('Seed default intake statuses');
task(
    'app:seed-intake-statuses',
    artisan('db:seed --force --class=IntakeStatusSeeder')
);
desc('Seed default referral statuses');

task(
    'app:seed-referral-statuses',
    artisan('db:seed --force --class=ReferralStatusSeeder')
);

before('deploy:symlink', 'artisan:migrate');
after('artisan:migrate', 'artisan:app:seed-settings');
after('artisan:migrate', 'app:seed-roles-and-permissions');
after('artisan:migrate', 'app:seed-intake-statuses');
after('artisan:migrate', 'app:seed-referral-statuses');

// Ensure the database credentials are filled in the .env file, *before* optimizing and running the migrations.
task('app:update_database_credentials', function () {
    $databaseHasDefaultName = test(
        'cat {{deploy_path}}/shared/.env | grep -q DB_DATABASE=laravel'
    );
    if (!$databaseHasDefaultName) {
        info('Database credentials already set in .env.');
        return;
    }
    $databaseCredentials = [
        'DB_CONNECTION' => ask('Database connection?', 'mysql'),
        'DB_HOST' => ask('Database host?', '127.0.0.1'),
        'DB_PORT' => ask('Database port?', '3306'),
        'DB_DATABASE' => ask('Database name?', 'laravel'),
        'DB_USERNAME' => ask('Database username?', 'root'),
        'DB_PASSWORD' => askHiddenResponse('Database password?'),
    ];
    foreach ($databaseCredentials as $key => $value) {
        run(
            "sed -i 's@^{$key}.*@{$key}=\"{$value}\"@g' {{deploy_path}}/shared/.env"
        );
    }
});

desc('Reload PHP FPM');
task('reload:php-fpm', function () {
    run('sudo service php82-php-fpm reload');
});
after('deploy:success', 'reload:php-fpm');
after('deploy:success', 'artisan:queue:restart');

after('deploy:failed', 'deploy:unlock');

/**
 * Main deploy task.
 */
desc('Deploy your project');
task('deploy', [
    'deploy:prepare',
    'app:authenticate_nova',
    'deploy:vendors',
    'artisan:storage:link',
    'app:store_version',
    'app:update_database_credentials',
    'artisan:optimize',
    'deploy:publish',
]);
