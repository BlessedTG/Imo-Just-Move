module.exports = {
    // Whatever plugins you need here:
    plugins: [require.resolve("@prettier/plugin-php")],
    overrides: [
        {
            documentSelectors: ["**/*.php"],
            files: ["*.php"],
            options: {
                parser: "php", // vscode will not be able to infer the parser for some reason so we need to explicitly specify it.
                singleQuote: true,
            },
        },
    ],
};
