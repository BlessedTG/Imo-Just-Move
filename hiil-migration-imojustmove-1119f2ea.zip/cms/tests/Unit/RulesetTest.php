<?php

namespace Tests\Unit;

use App\FormHandler\FormConfig;
use App\FormHandler\Rules\ConditionallyRequired;
use App\FormHandler\Ruleset;
use Tests\TestCase;

final class RulesetTest extends TestCase
{
    /** @test */
    public function should_not_create_ruleset_for_all_optional_elements(): void
    {
        $allOptional = FormConfig::fromConfigFile(
            app_path() . '/../tests/fixtures/all_optional.json'
        );
        $ruleset = Ruleset::fromFormConfig($allOptional);

        $this->assertEquals(
            [
                'a8acbff1-ed8a-4ff9-9811-e2259336c125' => ['nullable'],
                '4851995d-ae0c-4abe-b7d3-dcc4ec2a24ce' => ['nullable'],
            ],
            $ruleset
        );
    }

    /** @test */
    public function should_create_rules_for_form_config(): void
    {
        $formConfig = FormConfig::fromConfigFile(
            app_path() . '/../tests/fixtures/with_validation.json'
        );
        $ruleset = Ruleset::fromFormConfig($formConfig);

        $this->assertEquals(
            [
                '4851995d-ae0c-4abe-b7d3-dcc4ec2a24ce' => [
                    'required',
                    'max:50',
                ],
                '7811995d-gh1l-5pok-h31u-dcc4ec2a24ce' => [
                    'nullable',
                    'email:strict',
                ],
                'a8acbff1-ed8a-4ff9-9811-e2259336c125' => [
                    'required',
                    'in:Rood,Groen,Blauw',
                ],
                '8e514f98-f7b0-4b37-b051-780c0e6882fb' => [
                    'nullable',
                    $formConfig->elements[3]?->conditionallyRequired
                        ? new ConditionallyRequired(
                            $formConfig->elements[3]->conditionallyRequired
                        )
                        : null,
                ],
                '5e33f869-af33-43bc-830c-396c0824b5f1' => [
                    'nullable',
                    $formConfig->elements[4]?->conditionallyRequired
                        ? new ConditionallyRequired(
                            $formConfig->elements[4]->conditionallyRequired
                        )
                        : null,
                ],
                '4e7f3a66-900f-4ace-a652-9fe98ca329cf' => [
                    'required',
                    'numeric',
                    'min:1000',
                    'max:1000000',
                ],
                'b0b6ebb8-e21e-4a50-a365-2c9cf5479b10' => [
                    'required',
                    'numeric',
                ],
                'a6715c88-7658-4173-a1d4-d236b085bda1' => [
                    'required',
                    'array',
                    'in:Optie 1,Optie 2,Optie 3',
                ],
                '7ff0d9a6-4cf2-4ad1-b237-d7e4edb0b8ec' => ['required'],
                '2e7007a8-ab4e-4f78-91a7-12fef085fe6f' => ['nullable'],
                '33b328d8-0e41-45b6-83a5-a44b07dd43e4' => [
                    'required',
                    'in:Premium,Schemium',
                ],
                'e75b75b1-dd39-431c-8312-d973106b74a4' => [
                    'nullable',
                    'date',
                    'after:1985-02-11',
                ],
            ],
            $ruleset
        );
    }
}
