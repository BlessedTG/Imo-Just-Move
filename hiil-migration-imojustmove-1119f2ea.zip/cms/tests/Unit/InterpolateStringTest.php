<?php

namespace Tests\Unit;

use Tests\TestCase;

final class InterpolateStringTest extends TestCase
{
    public function testInterpolateString(): void
    {
        $template =
            'Available variables: {reference_id} {name}, {surname}, {phone_number}, {email}, {location}, {problem}, {outcome}, {additional_message}';
        $variables = [
            'reference_id' => '12345',
            'name' => 'John',
            'surname' => 'Doe',
            'phone_number' => '555-1234',
            'email' => 'john.doe@example.com',
            'location' => 'New York',
            'problem' => 'Issue with product',
            'outcome' => 'Resolved',
            'additional_message' => 'Thank you for your patience',
        ];

        $expected =
            'Available variables: 12345 John, Doe, 555-1234, john.doe@example.com, New York, Issue with product, Resolved, Thank you for your patience';
        $actual = interpolateString($template, $variables);

        $this->assertEquals($expected, $actual);
    }

    public function testInterpolateStringWithMissingVariable(): void
    {
        $template =
            'Available variables: {reference_id} {name}, {surname}, {phone_number}, {email}, {location}, {problem}, {outcome}, {additional_message}';
        $variables = [
            'reference_id' => '12345',
            'name' => 'John',
            'surname' => 'Doe',
            'phone_number' => '555-1234',
            'email' => 'john.doe@example.com',
            'location' => 'New York',
            'problem' => 'Issue with product',
            'outcome' => 'Resolved',
            // 'additional_message' is intentionally missing
        ];

        $expected =
            'Available variables: 12345 John, Doe, 555-1234, john.doe@example.com, New York, Issue with product, Resolved, {additional_message}';
        $actual = interpolateString($template, $variables);

        $this->assertEquals($expected, $actual);
    }
}
