<?php

namespace Tests\Unit;

use App\FormHandler\FormConfig;
use App\FormHandler\UnableToReadFormConfig;
use Tests\TestCase;

final class FormConfigTest extends TestCase
{
    /** @test */
    public function it_should_read_from_json_string(): void
    {
        $formConfig = FormConfig::fromJson('{
            "version": 1,
            "name": "My form",
            "description": "My description",
            "followUpActions": [],
            "elements": []
        }');
        $this->assertInstanceOf(FormConfig::class, $formConfig);
    }

    /** @test */
    public function it_should_read_from_file(): void
    {
        $formConfig = FormConfig::fromConfigFile(
            app_path() . '/../tests/fixtures/all_optional.json'
        );
        $this->assertInstanceOf(FormConfig::class, $formConfig);
    }

    /** @test */
    public function it_should_throw_on_missing_file(): void
    {
        $this->expectException(UnableToReadFormConfig::class);

        FormConfig::fromConfigFile('non-existent.json');
    }

    /** @test */
    public function it_should_throw_on_existing_file_with_invalid_json(): void
    {
        $this->expectException(UnableToReadFormConfig::class);

        FormConfig::fromConfigFile(__FILE__);
    }

    /** @test */
    public function it_should_throw_on_invalid_json(): void
    {
        $this->expectException(UnableToReadFormConfig::class);

        FormConfig::fromJson('invalid json');
    }
}
