<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class DotNotationToBracketNotationTest extends TestCase
{
    function testConvertsDotNotationToBracketNotation(): void
    {
        $this->assertSame(
            'foo[bar][baz]',
            dot_notation_to_bracket_notation('foo.bar.baz')
        );
    }
}
