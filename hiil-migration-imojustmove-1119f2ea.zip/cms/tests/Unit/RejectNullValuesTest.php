<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase;

class RejectNullValuesTest extends TestCase
{
    /**
     * @dataProvider dataProvider
     * @param iterable<string, mixed> $input
     * @param array<mixed> $fixture
     * @return void
     */
    public function testRejectsNullValues(iterable $input, array $fixture): void
    {
        $this->assertSame($fixture, reject_null_values($input));
    }

    /**
     * @return array<string,array<mixed>>
     */
    public static function dataProvider(): array
    {
        return [
            'simple_array' => [
                [
                    'foo' => 'bar',
                    'ouch' => null,
                    'numbers' => [1, 2, 3, 4],
                ],
                [
                    'foo' => 'bar',
                    'numbers' => [1, 2, 3, 4],
                ],
            ],
            'numeric_array' => [[1, 2, 3, 4, null, 6, 7], [1, 2, 3, 4, 6, 7]],
            'collection' => [
                collect([
                    'foo' => 'bar',
                    'something' => 'else',
                    'false' => false,
                    'null' => null,
                ]),
                [
                    'foo' => 'bar',
                    'something' => 'else',
                    'false' => false,
                ],
            ],
            'nested_array' => [
                [
                    'foo' => [
                        'bar' => [
                            [
                                'name' => 'Henk',
                                'is_null' => false,
                            ],
                            [
                                'name' => null,
                                'is_null' => true,
                            ],
                            [
                                'name' => 'Miep',
                                'is_null' => false,
                            ],
                        ],
                    ],
                ],
                [
                    'foo' => [
                        'bar' => [
                            [
                                'name' => 'Henk',
                                'is_null' => false,
                            ],
                            [
                                'is_null' => true,
                            ],
                            [
                                'name' => 'Miep',
                                'is_null' => false,
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }
}
