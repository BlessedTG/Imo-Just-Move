<?php

namespace Tests\Unit;

use App\FormHandler\FormConfig;
use App\FormHandler\FormData;
use DateTime;
use PHPUnit\Framework\TestCase;

class FormDataTest extends TestCase
{
    /** @test */
    public function payload_can_be_retrieved_in_bracket_notation(): void
    {
        $formData = new FormData(
            'some-id',
            [
                'foo.bar' => 'baz',
                'foo.baz.1' => 'buz',
            ],
            FormConfig::fake(),
            'some-form',
            new DateTime()
        );

        $this->assertSame(
            [
                'foo[bar]' => 'baz',
                'foo[baz][1]' => 'buz',
            ],
            $formData->payloadWithBracketNotation()
        );
    }
}
