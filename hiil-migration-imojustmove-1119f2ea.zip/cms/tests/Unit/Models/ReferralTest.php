<?php

namespace Tests\Unit\Models;

use App\Mail\ReferralConfirmation;
use App\Models\Referral;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

final class ReferralTest extends TestCase
{
    public function test_creating_referral_should_send_email_to_requester(): void
    {
        Referral::factory()->create(['email' => 'harmen.janssen@norday.nl']);

        Mail::assertQueued(ReferralConfirmation::class, function (
            ReferralConfirmation $mail
        ) {
            return $mail->hasTo('harmen.janssen@norday.nl');
        });
    }
}
