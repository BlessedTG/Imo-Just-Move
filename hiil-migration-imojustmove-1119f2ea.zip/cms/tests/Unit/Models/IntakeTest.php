<?php

namespace Tests\Unit\Models;

use App\Mail\IntakeConfirmation;
use App\Models\Intake;
use App\Models\User;
use Illuminate\Support\Facades\Mail;
use Tests\TestCase;

final class IntakeTest extends TestCase
{
    public function test_intake_should_auto_create_unique_reference_id(): void
    {
        $intake1 = Intake::factory()->create();
        $this->assertNotNull($intake1->reference_id);

        $intake2 = Intake::factory()->create();
        $this->assertNotEquals($intake1->reference_id, $intake2->reference_id);
    }

    public function test_creating_intake_should_send_email_to_requester(): void
    {
        Intake::factory()->create(['email' => 'harmen.janssen@norday.nl']);

        Mail::assertQueued(IntakeConfirmation::class, function (
            IntakeConfirmation $mail
        ) {
            return $mail->hasTo('harmen.janssen@norday.nl');
        });
    }

    public function test_an_intake_may_belong_to_an_owner(): void
    {
        $user = User::factory()->create();

        $intake = Intake::factory()->create();
        $this->assertNull($intake->owner);

        $intake->owner()->associate($user);
        $intake->save();

        $this->assertInstanceOf(User::class, $intake->owner);
        $this->assertEquals($user->id, $intake->owner->id);
    }
}
