<?php

namespace Tests\Unit\Models;

use App\Models\User;
use Tests\TestCase;

final class UserTest extends TestCase
{
    public function test_should_create_uuid_automatically(): void
    {
        $user1 = User::factory()->create();
        $this->assertNotNull($user1->uuid);

        $user2 = User::factory()->create();
        $this->assertNotNull($user2->uuid);

        $this->assertNotEquals($user1->uuid, $user2->uuid);
    }
}
