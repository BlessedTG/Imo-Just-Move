<?php

namespace Tests\Feature;

use App\FrontendUrl;
use App\Models\Problem;
use App\Models\ProblemCategory;
use App\Models\User;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Laravel\Sanctum\Sanctum;
use LaravelJsonApi\Testing\MakesJsonApiRequests;
use Tests\TestCase;

class ProblemCategoriesApiTest extends TestCase
{
    use DatabaseTransactions;
    use MakesJsonApiRequests;

    public function test_index_problem_categories(): void
    {
        Sanctum::actingAs(User::factory()->create());

        $categories = ProblemCategory::factory()->count(3)->create();

        $response = $this->jsonApi()
            ->expects('problem-categories')
            ->get('/api/v1/problem-categories');

        $response->assertFetchedMany($categories);
    }

    public function test_problems_relation(): void
    {
        Sanctum::actingAs(User::factory()->create());

        $category = ProblemCategory::factory()->create();

        $problems = Problem::factory()
            ->count(4)
            ->create([
                'problem_category_id' => $category->id,
            ]);

        /** @var int */
        $routeKey = $category->getRouteKey();

        $response = $this->jsonApi()
            ->expects('problems')
            ->get("/api/v1/problem-categories/{$routeKey}/problems");

        $response->assertFetchedMany($problems);
    }

    public function test_include_problems(): void
    {
        Sanctum::actingAs(User::factory()->create());

        $category = ProblemCategory::factory()->create();

        $problems = Problem::factory()
            ->count(4)
            ->create([
                'problem_category_id' => $category->id,
            ]);

        /** @var int */
        $routeKey = $category->getRouteKey();

        $response = $this->jsonApi()
            ->expects('problem-categories')
            ->includePaths('problems')
            ->get("/api/v1/problem-categories/{$routeKey}");

        $response->assertFetchedOne($category)->assertIncluded(
            $problems->map(
                fn(Problem $problem) => [
                    'type' => 'problems',
                    'id' => (string) $problem->id,
                ]
            )
        );
    }

    public function test_url_generation(): void
    {
        Sanctum::actingAs(User::factory()->create());

        $categories = ProblemCategory::factory()
            ->count(4)
            ->sequence(function ($sequence) {
                return [
                    'title' => "Category {$sequence->index}",
                    'slug' => "category-{$sequence->index}",
                ];
            })
            ->create();

        $response = $this->jsonApi()
            ->expects('problem-categories')
            ->sparseFields('problem-categories', ['url'])
            ->get('/api/v1/problem-categories');

        $response->assertFetchedMany(
            $categories->map(
                fn(ProblemCategory $category) => [
                    'attributes' => [
                        'url' => FrontendUrl::fromProblemCategory($category),
                    ],
                ]
            )
        );
    }
}
