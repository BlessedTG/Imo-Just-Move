<?php

namespace Tests\Feature;

use App\Models\ReferralStatus;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ReferralStatusTest extends TestCase
{
    use RefreshDatabase;

    public function test_there_should_be_one_default_referral_status_at_all_time(): void
    {
        $statuses = ReferralStatus::factory()->count(3)->create();
        $this->assertCount(3, $statuses);

        $firstStatus = ReferralStatus::findOrFail(1);
        $secondStatus = ReferralStatus::findOrFail(2);
        $thirdStatus = ReferralStatus::findOrFail(3);

        $firstStatus->is_default = true;
        $firstStatus->save();

        $this->assertTrue($firstStatus->fresh()?->is_default);
        $this->assertFalse($secondStatus->fresh()?->is_default);
        $this->assertFalse($thirdStatus->fresh()?->is_default);

        $secondStatus->is_default = true;
        $secondStatus->save();

        $this->assertFalse($firstStatus->fresh()->is_default);
        $this->assertTrue($secondStatus->fresh()->is_default);
        $this->assertFalse($thirdStatus->fresh()->is_default);
    }
}
