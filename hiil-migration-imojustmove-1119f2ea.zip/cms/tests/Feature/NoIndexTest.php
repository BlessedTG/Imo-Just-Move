<?php

namespace Tests\Feature;

use Tests\TestCase;

class NoIndexTest extends TestCase
{
    public function testBasicTest(): void
    {
        $response = $this->get('/');
        $response->assertHeader('X-Robots-Tag', 'noindex');
    }
}
