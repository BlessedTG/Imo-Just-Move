<?php

namespace Tests\Feature;

use App\Models\IntakeStatus;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

final class IntakeStatusTest extends TestCase
{
    use RefreshDatabase;

    public function test_there_should_be_one_default_intake_at_all_time(): void
    {
        $statuses = IntakeStatus::factory()->count(3)->create();
        $this->assertCount(3, $statuses);

        $firstStatus = IntakeStatus::findOrFail(1);
        $secondStatus = IntakeStatus::findOrFail(2);
        $thirdStatus = IntakeStatus::findOrFail(3);

        $firstStatus->is_default = true;
        $firstStatus->save();

        $this->assertTrue($firstStatus->fresh()?->is_default);
        $this->assertFalse($secondStatus->fresh()?->is_default);
        $this->assertFalse($thirdStatus->fresh()?->is_default);

        $secondStatus->is_default = true;
        $secondStatus->save();

        $this->assertFalse($firstStatus->fresh()->is_default);
        $this->assertTrue($secondStatus->fresh()->is_default);
        $this->assertFalse($thirdStatus->fresh()->is_default);
    }
}
