<?php

namespace Tests\Feature;

use App\Models\Outcome;
use App\Models\Problem;
use App\Models\Referral;
use App\Models\Region;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use LaravelJsonApi\Testing\MakesJsonApiRequests;
use Tests\TestCase;

class ReferralTest extends TestCase
{
    use MakesJsonApiRequests;
    use DatabaseTransactions;

    /**
     * The referral  be attached to multiple outcomes.
     */
    public function test_outcomes_relation(): void
    {
        // Given a referral
        $referral = Referral::factory()->create();

        // And an an outcome
        $outcome = Outcome::factory()->create();

        // When I attach the outcome to the referral

        $referral->outcomes()->attach($outcome);

        // Then the outcome should be attached to the referral
        $this->assertInstanceOf(Collection::class, $referral->outcomes);
        // $actual = $outcome->problem;

        // $referral->outcomes()->attach($outcome1);

        // $outcomes = $referral->outcomes;
        // dd($outcomes);
        // $this->assertEquals(
        //     $outcome1->id,
        //     $referral->fresh()->outcomes?->first()?->id,
        //     'The outcome is not attached to the referral'
        // );
    }
    public function test_it_can_have_a_related_region(): void
    {
        $referral = Referral::factory()->create();

        $this->assertNull($referral->region);

        $region = Region::factory()->create();

        $referral->region()->associate($region)->save();
        $referral->refresh();

        $this->assertEquals($region->id, $referral->region?->id);
    }
}
