<?php

namespace Tests\Feature;

use App\Models\ProblemCategory;
use App\Models\Questionnaire;
use App\Models\TargetAudience;
use App\Nova\Flexible\Layouts\Question;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use Tests\TestCase;

class ProblemCategoryTest extends TestCase
{
    use DatabaseTransactions;

    public function test_sluggable(): void
    {
        $category = ProblemCategory::factory()->create([
            'title' => 'Some problem',
        ]);

        $this->assertEquals('some-problem', $category->slug);
    }

    public function test_it_can_have_a_related_questionnaire(): void
    {
        $category = ProblemCategory::factory()->create();

        $this->assertNull($category->questionnaire);

        $questionnaire = Questionnaire::factory()->create();

        $category->questionnaire()->associate($questionnaire)->save();
        $category->refresh();

        $this->assertEquals($questionnaire->id, $category->questionnaire?->id);
    }

    public function test_it_can_have_a_related_target_audience(): void
    {
        $target_audience = TargetAudience::factory()->create();
        $category = ProblemCategory::factory()->create([
            'target_audience_id' => $target_audience->id,
        ]);

        $this->assertEquals(
            $target_audience->id,
            $category->target_audience?->id
        );
    }
}
