<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Illuminate\Support\Facades\Mail;

abstract class TestCase extends BaseTestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        Mail::fake();

        $this->app->bind(
            \App\FormHandler\IsFormSubmissionRepository::class,
            \App\FormHandler\FormSubmissionsRepositories\InMemoryRepository::class
        );
    }
}
