<template>
    <modal
        @modal-close="handleClose"
        data-testid="ApiTokenCopier"
        tabindex="-1"
        role="dialogue"
    >
        <div class="max-w-xl mx-auto">
            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                <div class="px-8 py-6">
                    <p class="text-gray-600 mb-2">
                        Deze token wordt eenmalig getoond. Kopieer deze voordat
                        u doorgaat.
                    </p>
                    <textarea
                        readonly
                        class="text-gray-800 text-lg font-semibold bg-transparent w-full resize-none"
                        rows="1"
                        id="tokenTextarea"
                        style="border: none; outline: none"
                        >{{ data.token }}</textarea
                    >
                    <button class="btn btn-blue ml-4" @click="copyToken()">
                        <span>{{ copyMessage }}</span>
                    </button>
                </div>
                <div class="flex justify-end px-6 py-4 bg-gray-100">
                    <button class="btn btn-gray" @click.prevent="handleClose()">
                        Close
                    </button>
                </div>
            </div>
        </div>
    </modal>
</template>

<script>
export default {
    props: {
        data: { type: Object },
    },

    methods: {
        copyToken() {
            navigator.clipboard
                .writeText(this.data.token)
                .then(() => {
                    this.copyMessage = "Token gekopieerd";
                    setTimeout(() => {
                        this.copyMessage = "Kopieer token";
                    }, 3000);
                })
                .catch((error) => {
                    console.error("Failed to copy token to clipboard", error);
                });
        },
        handleClose() {
            this.$emit("close");
        },
    },
    data() {
        return {
            copyMessage: "Kopieer token",
        };
    },
};
</script>
