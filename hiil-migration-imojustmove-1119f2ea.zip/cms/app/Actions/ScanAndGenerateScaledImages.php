<?php

namespace App\Actions;

use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class ScanAndGenerateScaledImages
{
    /**
     * Scan all media items and generate scaled images for those without them
     *
     * @return array Statistics about the processing
     */
    public function execute(): array
    {
        $stats = [
            'total' => 0,
            'processed' => 0,
            'skipped' => 0,
            'errors' => 0,
        ];

        // Get all media items
        $mediaItems = Media::all();
        $stats['total'] = $mediaItems->count();

        foreach ($mediaItems as $media) {
            try {
                if ($this->shouldProcessMedia($media)) {
                    GenerateScaledImages::dispatch($media);
                    $stats['processed']++;
                } else {
                    $stats['skipped']++;
                }
            } catch (\Exception $e) {
                Log::error(
                    "Error processing media {$media->id}: " . $e->getMessage(),
                    [
                        'media_id' => $media->id,
                        'collection' => $media->collection_name,
                    ]
                );
                $stats['errors']++;
            }
        }

        return $stats;
    }

    /**
     * Determine if the media item should be processed by checking if it is an image and if the scaled directory exists
     *
     * @param Media $media
     * @return bool
     */
    private function shouldProcessMedia(Media $media): bool
    {
        // Skip if not an image or if it's an SVG
        if (
            strpos(strval($media->mime_type), 'image') !== 0 ||
            strpos(strval($media->mime_type), 'image/svg') === 0
        ) {
            return false;
        }

        // Check if scaled directory already exists
        $directory = dirname($media->getPathRelativeToRoot());
        $scaledPath = "{$directory}/scaled";

        // If we're using a local disk, check if directory exists
        if ($media->disk === 'local') {
            return !is_dir(Storage::disk($media->disk)->path($scaledPath));
        }

        // For remote disks, check if any files exist in the scaled directory
        return !Storage::disk($media->disk)->exists($scaledPath);
    }
}
