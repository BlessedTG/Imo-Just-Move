<?php namespace App\Actions;

use App\FormHandler\FormName;
use App\Models\Feedback;
use App\Models\FormSubmission;
use Illuminate\Support\Facades\DB;

class ImportFeedback
{
    public function handle(): void
    {
        DB::transaction(function () {
            /** @var \Illuminate\Support\LazyCollection<int, FormSubmission> */
            $formSubmissions = FormSubmission::where(
                'form_name',
                FormName::Feedback->value
            )
                ->whereDoesntHave('feedback')
                ->cursor();

            $formSubmissions->each(
                fn($formSubmission) => $this->createFeedback($formSubmission)
            );
        });
    }

    /**
     * Create an feedback item from a form submission and associate it with the form submission
     */
    protected function createFeedback(FormSubmission $formSubmission): void
    {
        /** @var array<string, string> $payload */
        $payload = $formSubmission->payload;
        Feedback::create([
            'form_submission_id' => $formSubmission->id,
            'sentiment' => $payload['sentiment'] ?? '',
            'message' => $payload['message'] ?? '',
        ]);
    }
}
