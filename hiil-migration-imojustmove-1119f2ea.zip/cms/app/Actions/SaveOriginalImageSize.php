<?php

namespace App\Actions;

use Spatie\MediaLibrary\MediaCollections\Models\Media;

final class SaveOriginalImageSize
{
    public function execute(Media $media): void
    {
        if (strpos(strval($media->mime_type), 'image') !== 0) {
            return;
        }

        /**
         * We cannot reach the private files to obtain the image size.
         */
        if ($media->disk === 'private_attachments') {
            return;
        }

        $mediaUrl =
            $media->getDiskDriverName() === 'public' ||
            $media->getDiskDriverName() === 'local'
                ? $media->getPath()
                : $media->getFullUrl();

        $imageSize = getimagesize($mediaUrl);

        if (!$imageSize) {
            return;
        }
        $media->setCustomProperty('original_width', $imageSize[0]);
        $media->setCustomProperty('original_height', $imageSize[1]);
        $media->save();
    }
}
