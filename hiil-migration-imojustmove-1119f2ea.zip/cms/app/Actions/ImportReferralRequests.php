<?php namespace App\Actions;

use App\FormHandler\FormName;
use App\Languages;
use App\Models\FormSubmission;
use App\Models\Referral;
use App\Models\ReferralStatus;
use Illuminate\Support\Facades\DB;

class ImportReferralRequests
{
    public function __construct(protected Languages $languages) {}

    public function handle(): void
    {
        $defaultStatus = ReferralStatus::where(
            'is_default',
            true
        )->firstOrFail();

        DB::transaction(function () use ($defaultStatus) {
            /** @var \Illuminate\Support\LazyCollection<int, FormSubmission> */
            $formSubmissions = FormSubmission::where(
                'form_name',
                FormName::Referral->value
            )
                ->whereDoesntHave('referral')
                ->cursor();

            $formSubmissions->each(
                fn($formSubmission) => $this->createReferral(
                    $formSubmission,
                    $defaultStatus
                )
            );
        });
    }

    /**
     * Create an referral from a form submission and associate it with the form submission
     */
    protected function createReferral(
        FormSubmission $formSubmission,
        ReferralStatus $defaultStatus
    ): void {
        logger('Creating referral from form submission', [
            'form_submission_id' => $formSubmission->id,
        ]);
        /** @var array<string, string> $payload */
        $payload = $formSubmission->payload;
        Referral::create([
            'form_submission_id' => $formSubmission->id,
            'referral_status_id' => $defaultStatus->id,
            'status' => Referral::STATUS_DRAFT,
            'name' => $payload['name'] ?? '',
            'surname' => $payload['surname'] ?? '',
            'email' => $payload['email'] ?? null,
            'phone_number' => $payload['phone_number'] ?? '',
            'location' => $payload['location'] ?? '',
            'expertise' => $payload['expertise'] ?? '',
            'role' => $payload['role'] ?? '',
            'enrolment_number' => $payload['enrolment_number'] ?? null,
            'additional_message' => $payload['additional_message'] ?? null,
            'language' => $this->languages->default(),
        ]);
    }
}
