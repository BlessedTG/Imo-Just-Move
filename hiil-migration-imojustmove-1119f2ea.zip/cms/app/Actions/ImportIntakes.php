<?php namespace App\Actions;

use App\FormHandler\FormName;
use App\Models\FormSubmission;
use App\Models\Intake;
use App\Models\IntakeStatus;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class ImportIntakes
{
    public function handle(): void
    {
        $defaultIntakeStatus = IntakeStatus::where(
            'is_default',
            true
        )->firstOrFail();
        DB::transaction(function () use ($defaultIntakeStatus) {
            /** @var \Illuminate\Support\LazyCollection<int, FormSubmission> */
            $formSubmissions = FormSubmission::where(
                'form_name',
                FormName::Intake->value
            )
                ->whereDoesntHave('intake')
                ->cursor();

            $formSubmissions->each(
                fn($formSubmission) => $this->createIntake(
                    $formSubmission,
                    $defaultIntakeStatus
                )
            );
        });
    }

    /**
     * Create an intake from a form submission and associate it with the form submission
     */
    protected function createIntake(
        FormSubmission $formSubmission,
        IntakeStatus $defaultIntakeStatus
    ): void {
        logger('Creating intake from form submission', [
            'form_submission_id' => $formSubmission->id,
        ]);
        /** @var array<string, string> $payload */
        $payload = $formSubmission->payload;

        Intake::create([
            'form_submission_id' => $formSubmission->id,
            'name' => $payload['name'] ?? '',
            'surname' => $payload['surname'] ?? '',
            'email' => $payload['email'] ?? '',
            'phone_number' => $payload['phone_number'] ?? null,
            'location' => $payload['location'] ?? '',
            'problem' => $payload['problem'] ?? null,
            'outcome' => $payload['outcome'] ?? null,
            'additional_message' => $payload['additional_message'] ?? null,
            'intake_status_id' => $defaultIntakeStatus->id,
            'owner_id' => $this->findOwnerId($payload['owner_uuid'] ?? null),
        ]);
    }

    protected function findOwnerId(?string $ownerUuid): ?int
    {
        if ($ownerUuid === null) {
            return null;
        }
        $owner = User::where('uuid', $ownerUuid)->first();
        return $owner?->id;
    }
}
