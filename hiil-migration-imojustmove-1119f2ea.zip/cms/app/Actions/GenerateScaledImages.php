<?php

namespace App\Actions;

use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Spatie\Image\Image;
use App\Jobs\GenerateScaledImagesJob;

final class GenerateScaledImages
{
    private const IMAGE_WIDTHS = [
        200,
        330,
        400,
        450,
        500,
        610,
        700,
        800,
        900,
        1100,
        1500,
    ];

    /**
     * Dispatch a job to generate scaled versions of an image media item
     *
     * @param Media $media
     * @return void
     */
    public static function dispatch(Media $media): void
    {
        // Check if the media is an image and not an SVG
        if (
            strpos(strval($media->mime_type), 'image') !== 0 ||
            strpos(strval($media->mime_type), 'image/svg') === 0
        ) {
            return;
        }

        // Dispatch the job to process this media item
        GenerateScaledImagesJob::dispatch($media);
    }

    /**
     * Generate scaled versions of an image media item
     *
     * @param Media $media
     * @return void
     */
    public function execute(Media $media): void
    {
        // Check if the media is an image and not an SVG
        if (
            strpos(strval($media->mime_type), 'image') !== 0 ||
            strpos(strval($media->mime_type), 'image/svg') === 0
        ) {
            return;
        }

        // Get the original file path and disk
        $originalPath = $media->getPath();

        // Process each width
        foreach (self::IMAGE_WIDTHS as $width) {
            try {
                $this->generateScaledImage($media, $width);
            } catch (Exception $e) {
                Log::error(
                    "Failed to generate scaled image at width {$width}: " .
                        $e->getMessage(),
                    [
                        'media_id' => $media->id,
                        'width' => $width,
                        'path' => $originalPath,
                    ]
                );
            }
        }
    }

    /**
     * Generate a single scaled image at the specified width
     *
     * @param Media $media The media object
     * @param int $width Target width for the scaled image
     * @return void
     */
    private function generateScaledImage(Media $media, int $width): void
    {
        // Create a temporary directory for processing
        $tempDir = storage_path('app/temp/' . uniqid('scaled_', true));
        if (!is_dir($tempDir)) {
            mkdir($tempDir, 0755, true);
        }

        try {
            // Get the original file path
            $originalPath = $media->getPath();
            $fileName = basename($originalPath);
            $tempPath = $tempDir . '/' . $fileName;

            // Download the original file if it's on a remote disk
            if ($media->disk !== 'local') {
                $fileContents = Storage::disk($media->disk)->get(
                    $media->getPathRelativeToRoot()
                );
                file_put_contents($tempPath, $fileContents);
                $sourceForResize = $tempPath;
            } else {
                $sourceForResize = $originalPath;
            }

            // Resize and save the image to temp directory
            Image::load($sourceForResize)->width($width)->save($tempPath);

            // Determine the target path in the storage
            $directory = dirname($media->getPathRelativeToRoot());
            $relativePath = "{$directory}/scaled/width:{$width}/{$fileName}";

            // Upload the file using Laravel's Storage facade
            $disk = Storage::disk($media->disk);

            // Use the file directly instead of reading its contents
            // This avoids potential false return from file_get_contents
            $disk->putFileAs(
                dirname($relativePath),
                $tempPath,
                basename($relativePath)
            );

            // Clean up the temporary file
            @unlink($tempPath);
        } finally {
            // Clean up the temporary directory
            @rmdir($tempDir);
        }
    }
}
