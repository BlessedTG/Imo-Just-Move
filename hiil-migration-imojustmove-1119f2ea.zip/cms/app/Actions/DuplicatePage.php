<?php

namespace App\Actions;

use App\Models\Page;
use Illuminate\Filesystem\AwsS3V3Adapter;
use Illuminate\Support\Facades\Storage;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class DuplicatePage
{
    public function handle(
        Page $page,
        array $skipAttributes = [],
        array $attributes = [],
        bool $copyChildren = false
    ): Page {
        $newModel = $page->replicate($skipAttributes)->fill($attributes);
        $newModel->push();

        // Duplicate all attached media.
        /**
         * @var \Illuminate\Support\Collection<int, Media> $media
         */
        $media = $page->media;
        /**
         * @var string $mediaLibraryDiskName
         */
        $mediaLibraryDiskName = config('media-library.disk_name');
        /**
         * @var AwsS3V3Adapter $disk
         */
        $disk = Storage::disk($mediaLibraryDiskName);
        $media->each(function (Media $media) use ($newModel, $disk) {
            $newModel
                ->addMediaFromUrl($disk->url($media->getPath()))
                ->preservingOriginal()
                ->withCustomProperties($media->custom_properties)
                ->toMediaCollection($media->collection_name);
        });

        // Create copies of every child page, pointing the parent_id to the new model.
        if ($copyChildren) {
            /**
             * @var \Illuminate\Support\Collection<int, Page> $children
             */
            $children = $page->children;
            $children->each(
                fn(Page $child) => $this->handle(
                    $child,
                    [],
                    [
                        'parent_id' => $newModel->id,
                        'status' => $attributes['status'] ?? $child->status,
                    ],
                    true
                )
            );
        }
        return $newModel;
    }
}
