<?php

namespace App\Listeners;

use App\Events\SavingReferralStatus;
use App\Models\ReferralStatus;

class EnsureSingleDefaultForReferralStatus
{
    public function handle(SavingReferralStatus $event): void
    {
        if (!$event->referralStatus->is_default) {
            return;
        }
        ReferralStatus::where('id', '!=', $event->referralStatus->id)->update([
            'is_default' => false,
        ]);
    }
}
