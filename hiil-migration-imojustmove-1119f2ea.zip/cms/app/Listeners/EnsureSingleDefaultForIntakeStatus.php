<?php

namespace App\Listeners;

use App\Events\SavingIntakeStatus;
use App\Models\IntakeStatus;

class EnsureSingleDefaultForIntakeStatus
{
    public function handle(SavingIntakeStatus $event): void
    {
        if (!$event->intakeStatus->is_default) {
            return;
        }
        IntakeStatus::where('id', '!=', $event->intakeStatus->id)->update([
            'is_default' => false,
        ]);
    }
}
