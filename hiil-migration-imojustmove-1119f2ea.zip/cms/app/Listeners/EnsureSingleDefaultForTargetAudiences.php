<?php

namespace App\Listeners;

use App\Events\SavingTargetAudience;
use App\Models\TargetAudience;

class EnsureSingleDefaultForTargetAudiences
{
    public function handle(SavingTargetAudience $event): void
    {
        if (!$event->targetAudience->is_default) {
            return;
        }
        TargetAudience::where('id', '!=', $event->targetAudience->id)->update([
            'is_default' => false,
        ]);
    }
}
