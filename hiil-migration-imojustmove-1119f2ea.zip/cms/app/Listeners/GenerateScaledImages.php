<?php

namespace App\Listeners;

use Spatie\MediaLibrary\MediaCollections\Events\MediaHasBeenAddedEvent;

class GenerateScaledImages
{
    private \App\Actions\GenerateScaledImages $generateScaledImages;

    public function __construct(
        \App\Actions\GenerateScaledImages $generateScaledImages
    ) {
        $this->generateScaledImages = $generateScaledImages;
    }

    public function handle(MediaHasBeenAddedEvent $event): void
    {
        $this->generateScaledImages->execute($event->media);
    }
}
