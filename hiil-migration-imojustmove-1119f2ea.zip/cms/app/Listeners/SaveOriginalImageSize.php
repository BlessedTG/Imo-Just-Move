<?php

namespace App\Listeners;

use Spatie\MediaLibrary\MediaCollections\Events\MediaHasBeenAddedEvent;

class SaveOriginalImageSize
{
    private \App\Actions\SaveOriginalImageSize $saveOriginalImageSize;

    public function __construct(
        \App\Actions\SaveOriginalImageSize $saveOriginalImageSize
    ) {
        $this->saveOriginalImageSize = $saveOriginalImageSize;
    }

    public function handle(MediaHasBeenAddedEvent $event): void
    {
        $this->saveOriginalImageSize->execute($event->media);
    }
}
