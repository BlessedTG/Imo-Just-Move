<?php

namespace App\Listeners;

use App\Events\ReferralWasCreated;
use App\Languages;
use App\Mail\ReferralConfirmation;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendEmailToReferral
{
    public function __construct(private Languages $languages) {}

    /**
     * Handle the event.
     */
    public function handle(ReferralWasCreated $event): void
    {
        logger('Sending email to referral', [
            'referral_id' => $event->model->id,
            'email' => $event->model->email,
        ]);
        if (!$event->model->email) {
            Log::warning(
                'Unable to send email to referral. No email address provided.'
            );
            return;
        }

        $defaultLanguage = $this->languages->default();

        Mail::to($event->model->email)->send(
            new ReferralConfirmation($event->model, $defaultLanguage)
        );
    }
}
