<?php

namespace App\Listeners;

use App\Events\IntakeWasCreated;
use App\Languages;
use App\Mail\IntakeConfirmation;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendEmailToIntakeCreator
{
    public function __construct(private Languages $languages) {}

    /**
     * Handle the event.
     */
    public function handle(IntakeWasCreated $event): void
    {
        logger('Sending email to intake creator', [
            'intake_id' => $event->model->id,
            'email' => $event->model->email,
        ]);
        if (!$event->model->email) {
            Log::warning(
                'Unable to send email to intake creator. No email address provided.'
            );
            return;
        }

        $defaultLanguage = $this->languages->default();

        Mail::to($event->model->email)->send(
            new IntakeConfirmation($event->model, $defaultLanguage)
        );
    }
}
