<?php

namespace App\Listeners;

use App\Events\IntakeIsBeingCreated;
use Illuminate\Support\Str;

class CreateIntakeReferenceId
{
    public function handle(IntakeIsBeingCreated $event): void
    {
        if ($event->model->reference_id) {
            return;
        }

        $event->model->reference_id = Str::uuid();
    }
}
