<?php

namespace App\Listeners;

use App\Events\UserIsBeingCreated;
use Illuminate\Support\Str;

class AddModelUuid
{
    public function handle(UserIsBeingCreated $event): void
    {
        $event->user->uuid = Str::uuid();
    }
}
