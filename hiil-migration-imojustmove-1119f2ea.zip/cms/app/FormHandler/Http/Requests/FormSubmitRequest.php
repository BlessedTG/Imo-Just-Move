<?php

namespace App\FormHandler\Http\Requests;

use App\FormHandler\FormConfig;
use App\FormHandler\FormConfigCollection;
use App\FormHandler\GoogleReCaptcha;
use App\FormHandler\Honeypot;
use App\FormHandler\Ruleset;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;

class FormSubmitRequest extends FormRequest
{
    public function __construct(
        private FormConfigCollection $formConfigCollection,
        private GoogleReCaptcha $googleReCaptcha,
        private Honeypot $honeypot
    ) {}

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, mixed>
     */
    public function rules()
    {
        $basicRules = [
            'form_name' =>
                'required|string|in:' .
                $this->formConfigCollection->allNames()->implode(','),
        ];
        $formSpecificRules = [];
        $formConfig = $this->getFormConfig();
        if ($formConfig) {
            $formSpecificRules = Ruleset::fromFormConfig($formConfig);
        }

        return $basicRules + $formSpecificRules;
    }

    public function formName(): string
    {
        $formName = $this->input('form_name');
        if (!is_string($formName)) {
            throw new \InvalidArgumentException('Form name must be a string');
        }
        return $formName;
    }

    /**
     * @return array<string, string>
     */
    public function payload(): array
    {
        $reservedFieldNames = [
            'form_name',
            $this->honeypot->honeypotFieldName,
            $this->googleReCaptcha->fieldName,
        ];

        $formConfig = $this->getFormConfig();

        /**
         * Flatten the array by converting nested arrays to dot notation
         * @var array<string, string> $validatedData
         */
        $validatedData = Arr::dot($this->validated());
        /**
         * @var array<string, string> $processed
         */
        $processed = collect($validatedData)
            ->except($reservedFieldNames)
            ->when($formConfig, function (
                Collection $collection,
                FormConfig $formConfig
            ) {
                return $collection->map(function ($value, $key) use (
                    $formConfig
                ) {
                    $element = $formConfig->getElementById($key);
                    if (!$element) {
                        return "Missing key: '$key'";
                    }
                    return $value;
                });
            })
            ->toArray();
        return $processed;
    }

    private function getFormConfig(): ?FormConfig
    {
        $formName = $this->formName();
        return $this->formConfigCollection->fetchByName($formName);
    }
}
