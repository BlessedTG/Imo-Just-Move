<?php

namespace App\FormHandler\Http\Controllers;

use App\FormHandler\Events\FormDataStored;
use App\FormHandler\FormConfigCollection;
use App\FormHandler\FormData;
use App\FormHandler\Http\Requests\FormSubmitRequest;
use App\FormHandler\IsFormSubmissionRepository;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;

final class SubmitForm
{
    public function __invoke(
        FormSubmitRequest $request,
        IsFormSubmissionRepository $repository,
        FormConfigCollection $formConfigCollection
    ): JsonResponse|RedirectResponse {
        $formData = FormData::createFromRequest(
            $formConfigCollection,
            $request
        );

        $repository->store($formData);

        logger('Form data stored');
        FormDataStored::dispatch($formData);

        return $request->expectsJson()
            ? response()->json(
                [
                    'status' => 'success',
                    'message' => 'Formdata stored',
                ],
                200
            )
            : redirect()->back();
    }
}
