<?php

namespace App\FormHandler\Http\Middleware;

use App\FormHandler\Events\RequestVerifiedByReCaptcha;
use App\FormHandler\GoogleReCaptcha;
use Closure;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;

class VerifyGoogleReCaptcha
{
    public function __construct(private GoogleReCaptcha $googleReCaptcha) {}

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (!$this->googleReCaptcha->isConfigured()) {
            return $next($request);
        }

        /** @var string|null $reCaptchaToken */
        $reCaptchaToken = $request->input('g-recaptcha-response');

        if (!$reCaptchaToken) {
            throw new HttpResponseException(
                response()->json(
                    [
                        'status' => 'error',
                        'message' => 'Google reCAPTCHA token missing',
                    ],
                    400
                )
            );
        }
        $result = $this->googleReCaptcha->verify($reCaptchaToken);
        event(new RequestVerifiedByReCaptcha($result, $request));

        if ($result->passed === false) {
            throw new HttpResponseException(
                response()->json(
                    [
                        'status' => 'error',
                        'message' => 'Google reCAPTCHA failed',
                    ],
                    400
                )
            );
        }
        return $next($request);
    }
}
