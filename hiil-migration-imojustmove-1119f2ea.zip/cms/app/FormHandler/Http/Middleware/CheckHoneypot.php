<?php

namespace App\FormHandler\Http\Middleware;

use App\FormHandler\Events\HoneypotTouched;
use App\FormHandler\Honeypot;
use Closure;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;

class CheckHoneypot
{
    public function __construct(private Honeypot $honeypot) {}
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if (
            $this->honeypot->isConfigured() &&
            $this->honeypot->honeyIsTouched($request)
        ) {
            event(new HoneypotTouched($request));

            abort(404);
        }
        return $next($request);
    }
}
