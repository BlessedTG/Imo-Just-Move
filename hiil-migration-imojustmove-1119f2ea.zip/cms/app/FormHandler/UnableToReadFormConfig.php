<?php

namespace App\FormHandler;

use Exception;

final class UnableToReadFormConfig extends Exception
{
    public static function becauseFileIsUnreadble(string $path): self
    {
        return new self("Unable to read form config from path: {$path}");
    }

    public static function becauseItsNotValidJson(string $string): self
    {
        return new self("String: \"{$string}\" does not contain valid JSON.");
    }
}
