<?php

namespace App\FormHandler;

final class FormElementCondition
{
    public static function fromConfig(array $config): self
    {
        return new self(
            $config['element'],
            $config['operator'],
            $config['value']
        );
    }

    public function __construct(
        public readonly string $element,
        public readonly ?string $operator,
        public readonly ?string $value
    ) {}
}
