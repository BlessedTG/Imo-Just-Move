<?php

namespace App\FormHandler;

class FormSubmissionResource
{
    protected string $id;
    protected string $formName;
    protected array $payload;
    protected string $createdAt;

    public function __construct(array $data)
    {
        $this->id =
            $data['id'] ??
            throw new \InvalidArgumentException('id is required');
        $this->formName =
            $data['attributes']['formName'] ??
            throw new \InvalidArgumentException('formName is required');
        $this->payload =
            $data['attributes']['payload'] ??
            throw new \InvalidArgumentException('payload is required');
        $this->createdAt =
            $data['attributes']['createdAt'] ??
            throw new \InvalidArgumentException('createdAt is required');
    }

    public function id(): string
    {
        return $this->id;
    }

    public function formName(): string
    {
        return $this->formName;
    }

    public function payload(): array
    {
        return $this->payload;
    }

    public function createdAt(): string
    {
        return $this->createdAt;
    }
}
