<?php

namespace App\FormHandler;

use App\FormHandler\FormConfig;
use Illuminate\Support\Collection;

/**
 * @extends Collection<int,\App\FormHandler\FormConfig>
 */
final class FormConfigCollection extends Collection
{
    public static function makeFromDirectory(string $directory): self
    {
        $formConfigFiles = glob($directory . '/*.json');
        if (!$formConfigFiles) {
            return new self();
        }
        $formConfigs = array_map(
            fn(string $formConfigFile) => FormConfig::fromConfigFile(
                $formConfigFile
            ),
            $formConfigFiles
        );

        return new self($formConfigs);
    }

    public function fetchByName(string $name): ?FormConfig
    {
        return $this->firstWhere('name', $name);
    }

    /**
     * @return Collection<int,string>
     */
    public function allNames(): Collection
    {
        /** @var Collection<int, string> */
        $collection = new Collection($this->pluck('name')->values());
        return $collection;
    }
}
