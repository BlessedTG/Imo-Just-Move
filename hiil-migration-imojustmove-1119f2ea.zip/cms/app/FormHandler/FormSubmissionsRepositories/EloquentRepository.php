<?php

namespace App\FormHandler\FormSubmissionsRepositories;

use App\FormHandler\FormConfigCollection;
use App\FormHandler\FormData;
use App\FormHandler\IsFormSubmissionRepository;
use App\Models\FormSubmission;
use Exception;
use Generator;

final class EloquentRepository implements IsFormSubmissionRepository
{
    public function __construct(
        private FormConfigCollection $formConfigCollection
    ) {}

    public function all(): Generator
    {
        $lazyCollection = FormSubmission::query()->cursor();

        foreach ($lazyCollection as $formSubmission) {
            $payload = $formSubmission->payload;

            $formConfig = $this->formConfigCollection->fetchByName(
                $formSubmission->form_name
            );
            if (!$formConfig) {
                throw new Exception(
                    "Form config not found for form: {$formSubmission->form_name}"
                );
            }

            yield new FormData(
                formName: $formSubmission->form_name,
                id: $formSubmission->id,
                payload: $payload,
                createdAt: $formSubmission->created_at,
                formConfig: $formConfig
            );
        }
    }

    public function store(FormData $formData): void
    {
        FormSubmission::create([
            'form_name' => $formData->formName(),
            'id' => $formData->id(),
            'payload' => $formData->payload(),
            'created_at' => $formData->createdAt()->format('Y-m-d H:i:s'),
        ]);
    }

    public function find(string $formName, string $formId): ?FormData
    {
        $formSubmission = FormSubmission::query()
            ->where([
                'form_name' => $formName,
                'id' => $formId,
            ])
            ->first();

        if (!$formSubmission) {
            return null;
        }

        $formConfig = $this->formConfigCollection->fetchByName(
            $formSubmission->form_name
        );
        if (!$formConfig) {
            throw new Exception(
                "Form config not found for form: {$formSubmission->form_name}"
            );
        }

        return new FormData(
            formName: $formSubmission->form_name,
            id: $formSubmission->id,
            payload: $formSubmission->payload,
            createdAt: $formSubmission->created_at,
            formConfig: $formConfig
        );
    }
}
