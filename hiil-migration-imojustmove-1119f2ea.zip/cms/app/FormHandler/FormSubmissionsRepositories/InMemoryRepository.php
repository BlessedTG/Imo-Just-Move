<?php

namespace App\FormHandler\FormSubmissionsRepositories;

use App\FormHandler\FormData;
use App\FormHandler\IsFormSubmissionRepository;
use Generator;

final class InMemoryRepository implements IsFormSubmissionRepository
{
    /**
     * @var array<int, FormData>
     */
    private $data = [];

    public function all(): Generator
    {
        foreach ($this->data as $formData) {
            yield $formData;
        }
    }

    public function store(FormData $formData): void
    {
        $this->data[] = $formData;
    }

    public function find(string $formName, string $formId): ?FormData
    {
        return collect($this->data)->first(
            fn(FormData $formData) => $formData->id() === $formId
        );
    }
}
