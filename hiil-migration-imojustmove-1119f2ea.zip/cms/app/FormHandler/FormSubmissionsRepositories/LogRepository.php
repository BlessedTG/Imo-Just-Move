<?php

namespace App\FormHandler\FormSubmissionsRepositories;

use App\FormHandler\FormData;
use App\FormHandler\IsFormSubmissionRepository;
use Generator;
use Illuminate\Support\Facades\Log;

final class LogRepository implements IsFormSubmissionRepository
{
    public function store(FormData $formData): void
    {
        Log::debug('Storing form submission', [
            'form_id' => $formData->id(),
            'form_name' => $formData->formName(),
            'payload' => $formData->payloadForStorage(),
            'form_config' => $formData->formConfig(),
        ]);
    }

    public function all(): Generator
    {
        yield from [];
    }

    public function find(string $formName, string $formId): ?FormData
    {
        return null;
    }
}
