<?php

namespace App\FormHandler;

use App\FormHandler\Exceptions\FormException;
use DateTime;

final class FormElementConfig
{
    public static function fromConfig(array $formConfig): self
    {
        if (!isset($formConfig['id'])) {
            throw FormException::elementIdMissing();
        }

        if (!isset($formConfig['type'])) {
            throw FormException::missingConfigKey($formConfig['id'], 'type');
        }

        if (FormElementType::tryFrom($formConfig['type']) === null) {
            throw FormException::invalidElementType(
                $formConfig['id'],
                $formConfig['type'] ?: ''
            );
        }

        if (!isset($formConfig['label'])) {
            throw FormException::missingConfigKey($formConfig['id'], 'label');
        }

        return new FormElementConfig(
            $formConfig['id'],
            FormElementType::from($formConfig['type']),
            $formConfig['label'],
            $formConfig['required'] ?? false,
            $formConfig['conditionallyRequired']['enabled'] ?? false
                ? FormElementCondition::fromConfig(
                    $formConfig['conditionallyRequired']
                )
                : null,
            $formConfig['conditionallyVisible']['enabled'] ?? false
                ? FormElementCondition::fromConfig(
                    $formConfig['conditionallyVisible']
                )
                : null,
            $formConfig['placeholder'] ?? '',
            $formConfig['byline'] ?? '',
            $formConfig['tooltip'] ?? '',
            $formConfig['_notes'] ?? '',
            isset($formConfig['choices']) ? $formConfig['choices'] : [],
            isset($formConfig['date'])
                ? new DateTime($formConfig['date']['min'])
                : null,
            $formConfig['number'] ?? null,
            isset($formConfig['maxCharacters']) &&
            $formConfig['maxCharacters']['enabled']
                ? $formConfig['maxCharacters']['value']
                : null
        );
    }

    public function __construct(
        public readonly string $id,
        public readonly FormElementType $type,
        public readonly string $label,
        public readonly bool $required,
        public readonly ?FormElementCondition $conditionallyRequired,
        public readonly ?FormElementCondition $conditionallyVisible,
        public readonly string $placeholder,
        public readonly string $byline,
        public readonly string $tooltip,
        public readonly string $notes,
        public readonly array $choices,
        public readonly ?DateTime $minDate,
        public readonly ?array $number,
        public readonly ?int $maxChars
    ) {}
}
