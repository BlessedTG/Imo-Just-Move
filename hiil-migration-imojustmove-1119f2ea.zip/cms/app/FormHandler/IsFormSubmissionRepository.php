<?php

namespace App\FormHandler;

use Generator;

interface IsFormSubmissionRepository
{
    /**
     * @return Generator<FormData>
     */
    public function all(): Generator;

    public function store(FormData $formData): void;

    public function find(string $formName, string $formId): ?FormData;
}
