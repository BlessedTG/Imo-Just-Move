<?php

namespace App\FormHandler\Exceptions;

use Exception;

final class FormException extends Exception
{
    public static function elementIdMissing(): self
    {
        return new self('An element is missing the id key in the form config');
    }

    public static function missingConfigKey(string $id, string $configKey): self
    {
        return new self(
            "Element $id is missing the key $configKey in the form config"
        );
    }

    public static function invalidElementType(string $id, string $type): self
    {
        return new self(
            "Element $id has an invalid type '$type' in the form config"
        );
    }
}
