<?php

namespace App\FormHandler\Exceptions;

use Exception;

final class FollowUpActionException extends Exception
{
    public static function actionIdMissing(): self
    {
        return new self(
            'An action is missing the actionId key in the form config'
        );
    }

    public static function missingConfigKey(string $id, string $configKey): self
    {
        return new self(
            "Action $id is missing the key $configKey in the form config"
        );
    }
}
