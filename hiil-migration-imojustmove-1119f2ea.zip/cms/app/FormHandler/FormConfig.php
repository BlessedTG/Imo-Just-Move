<?php

namespace App\FormHandler;

use Illuminate\Support\Collection;
use Illuminate\Support\Facades\File;
use App\FormHandler\FormElementConfig;

/**
 * Note: we assume the config used to create this object is valid
 * and coming from our Formbuilder tool.
 */
final class FormConfig
{
    public static function fromJson(string $jsonString): self
    {
        /**
         * @var array{
         *  "version": int,
         *  "name": string,
         *  "description": string,
         *  "elements": array{
         *   "type": string,
         *   "label": string,
         *   "id": string,
         *   "required": bool,
         *   "byline": string,
         *   "tooltip": string,
         *   "placeholder": string,
         *   "_notes": string,
         *   "conditionallyRequired": array{
         *     "enabled": bool,
         *     "element": string|null,
         *     "operator": string|null,
         *     "value": string|null
         *   },
         *   "conditionallyVisible": array{
         *     "enabled": bool,
         *     "element": string|null,
         *     "operator": string|null,
         *     "value": string|null
         *   },
         *   "date"?: array{
         *     "min": string
         *   },
         *   "maxCharacters"?: array{
         *     "enabled": bool,
         *     "value": int
         *   },
         *   "choices"?: string[],
         *   "number"?: array{
         *     "min": int,
         *     "max": int
         *   }
         *  }[]
         * } $parsedConfig
         */
        $parsedConfig = json_decode($jsonString, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw UnableToReadFormConfig::becauseItsNotValidJson($jsonString);
        }

        return new self(
            $parsedConfig['version'],
            $parsedConfig['name'],
            $parsedConfig['description'],
            Collection::make($parsedConfig['elements'])->map(
                fn(array $field) => FormElementConfig::fromConfig($field)
            )
        );
    }

    public static function fromConfigFile(string $path): self
    {
        if (!File::isReadable($path)) {
            throw UnableToReadFormConfig::becauseFileIsUnreadble($path);
        }
        $config = File::get($path);
        return self::fromJson($config);
    }

    public static function fake(): self
    {
        return new FormConfig(
            1,
            'My form',
            'This is my form',
            collect([
                FormElementConfig::fromConfig([
                    'type' => 'text',
                    'id' => 'name',
                    'label' => 'Name',
                    'required' => true,
                    'placeholder' => '',
                    'byline' => '',
                    'tooltip' => '',
                    '_notes' => '',
                    'conditionallyRequired' => [
                        'enabled' => false,
                    ],
                    'conditionallyVisible' => [
                        'enabled' => false,
                    ],
                ]),
                FormElementConfig::fromConfig([
                    'type' => 'text',
                    'id' => 'email',
                    'label' => 'Email',
                    'required' => true,
                    'placeholder' => '',
                    'byline' => '',
                    'tooltip' => '',
                    '_notes' => '',
                    'conditionallyRequired' => [
                        'enabled' => false,
                    ],
                    'conditionallyVisible' => [
                        'enabled' => false,
                    ],
                ]),
            ])
        );
    }

    /**
     * @param Collection<int, FormElementConfig> $elements
     */
    public function __construct(
        public readonly int $version,
        public readonly string $name,
        public readonly string $description,
        public readonly Collection $elements
    ) {}

    /**
     * @param FormElementType $type
     * @return Collection<int, FormElementConfig>
     */
    public function getElementsByType(FormElementType $type): Collection
    {
        return $this->elements->filter(
            fn(FormElementConfig $element) => $element->type === $type
        );
    }

    public function getElementById(string $id): ?FormElementConfig
    {
        return $this->elements->first(
            fn(FormElementConfig $element) => $element->id === $id
        );
    }
}
