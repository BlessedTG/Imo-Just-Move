<?php

namespace App\FormHandler;

use Illuminate\Support\Facades\Http;

class GoogleReCaptcha
{
    public function __construct(
        private string $secretKey,
        private float $minimumScore = 0.5,
        readonly string $fieldName = 'g-recaptcha-response'
    ) {}

    public function isConfigured(): bool
    {
        return (bool) $this->secretKey;
    }

    public function verify(string $responseToken): GoogleReCaptchaVerifyResult
    {
        if (!$this->secretKey) {
            return GoogleReCaptchaVerifyResult::passed(
                'GoogleReCaptcha missing secret key',
                0,
                $this->minimumScore
            );
        }
        $response = Http::asForm()->post(
            'https://www.google.com/recaptcha/api/siteverify',
            [
                'secret' => $this->secretKey,
                'response' => $responseToken,
            ]
        );

        /** @var string $action  */
        $action = $response->json('action', '');
        /** @var float $score  */
        $score = $response->json('score', 0);

        if (
            $response->json('success') === false ||
            $response->json('score') < $this->minimumScore
        ) {
            return GoogleReCaptchaVerifyResult::failed(
                $action,
                $score,
                $this->minimumScore
            );
        }

        return GoogleReCaptchaVerifyResult::passed(
            $action,
            $score,
            $this->minimumScore
        );
    }
}
