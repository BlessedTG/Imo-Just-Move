<?php

namespace App\FormHandler;

use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

class FormHandlerClient
{
    public function __construct(
        protected string $baseUrl,
        protected string $apiKey
    ) {}

    public function get(string $path): Response
    {
        return $this->request()->get($path);
    }

    public function request(): PendingRequest
    {
        return Http::withHeaders([
            'Authorization' => 'Bearer ' . $this->apiKey,
        ])->baseUrl($this->baseUrl);
    }
}
