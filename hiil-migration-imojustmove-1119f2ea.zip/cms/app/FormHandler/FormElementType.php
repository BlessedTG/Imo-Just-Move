<?php

namespace App\FormHandler;

enum FormElementType: string
{
    case Attachment = 'attachment';
    case Checkbox = 'checkbox';
    case Currency = 'currency';
    case Datepicker = 'datepicker';
    case Email = 'email';
    case Heading = 'heading';
    case Hidden = 'hidden';
    case Markup = 'markup';
    case MultiCheckbox = 'multi-checkbox';
    case Number = 'number';
    case Radio = 'radio';
    case Select = 'select';
    case Text = 'text';
    case Textarea = 'textarea';
}
