<?php namespace App\FormHandler;

enum FormName: string
{
    case Intake = 'intake_form';
    case Referral = 'referral_form';
    case Feedback = 'feedback_form';
}
