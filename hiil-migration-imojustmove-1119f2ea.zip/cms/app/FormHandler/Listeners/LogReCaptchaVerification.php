<?php

namespace App\FormHandler\Listeners;

use App\FormHandler\Events\RequestVerifiedByReCaptcha;
use App\FormHandler\FormData;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Illuminate\Support\Stringable;

class LogReCaptchaVerification
{
    /**
     * Handle the event.
     *
     * @param  RequestVerifiedByReCaptcha $event
     * @return void
     */
    public function handle(RequestVerifiedByReCaptcha $event): void
    {
        $result = $event->googleReCaptchaVerifyResult;

        /** @var string|null $email */
        $email = $event->request->get(FormData::FIELD_EMAIL);
        /** @var string|null $ip */
        $ip = $event->request->ip();
        $message = Str::of(
            "Google ReCaptcha verified '{$result->action}' with score {$result->score} (minimum score: {$result->minimumScore})"
        )
            ->when(
                $result->passed,
                fn(Stringable $message) => $message->append(' and passed'),
                fn(Stringable $message) => $message->append(' and failed')
            )
            ->when(
                $email,
                fn(Stringable $message, ?string $email) => $message->append(
                    " with email {$email}"
                )
            )
            ->when(
                $ip,
                fn(Stringable $message, ?string $ip) => $message->append(
                    " from IP {$ip}"
                )
            )
            ->append('.');

        Log::info($message);
    }
}
