<?php

namespace App\FormHandler\Listeners;

use App\FormHandler\Honeypot;
use App\FormHandler\Events\HoneypotTouched;
use App\FormHandler\FormData;
use Illuminate\Support\Facades\Log;

class LogTouchedHoneypot
{
    /**
     * Handle the event.
     *
     * @return void
     */
    public function handle(HoneypotTouched $event)
    {
        /** @var string|null $email */
        $email = $event->request->get(FormData::FIELD_EMAIL);
        /** @var string|null $ip */
        $ip = $event->request->ip();

        /** @var Honeypot */
        $honeypot = resolve(Honeypot::class);

        $message = "Honeypot ({$honeypot->honeypotFieldName}) is touched with email {$email} from IP {$ip}.";

        Log::info($message);
    }
}
