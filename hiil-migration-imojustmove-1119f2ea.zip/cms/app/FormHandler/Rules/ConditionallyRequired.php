<?php

namespace App\FormHandler\Rules;

use App\FormHandler\FormElementCondition;
use Illuminate\Contracts\Validation\DataAwareRule;
use Illuminate\Contracts\Validation\ImplicitRule;

// TODO: Check out deprecated ImplicitRule
class ConditionallyRequired implements DataAwareRule, ImplicitRule
{
    /**
     * @var array<string,mixed>
     */
    private array $data;

    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct(private FormElementCondition $condition) {}

    public function setData($data)
    {
        $this->data = $data;
        return $this;
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value)
    {
        $requiredElement = $this->condition->element;
        $requiredValue = $this->condition->value;
        $operator = $this->condition->operator;
        /** @var string|null $givenValue */
        $givenValue = $this->data[$requiredElement] ?? null;

        $isRequired = match ($operator) {
            '' => !!$givenValue,
            '==' => $givenValue == $requiredValue,
            '!=' => $givenValue != $requiredValue,
            '>' => $givenValue > $requiredValue,
            '<' => $givenValue < $requiredValue,
            '>=' => $givenValue >= $requiredValue,
            '<=' => $givenValue <= $requiredValue,
            'contains' => str_contains(
                strval($givenValue),
                strval($requiredValue)
            ),
            default => false,
        };
        return !$isRequired || $value;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message()
    {
        return 'This field is required.';
    }
}
