<?php

namespace App\FormHandler\Events;

use App\FormHandler\GoogleReCaptchaVerifyResult;
use Illuminate\Http\Request;

class RequestVerifiedByReCaptcha
{
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(
        public GoogleReCaptchaVerifyResult $googleReCaptchaVerifyResult,
        public Request $request
    ) {}
}
