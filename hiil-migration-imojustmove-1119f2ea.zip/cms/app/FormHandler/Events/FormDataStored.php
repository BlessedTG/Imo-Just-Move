<?php

namespace App\FormHandler\Events;

use App\FormHandler\FormData;
use Illuminate\Foundation\Events\Dispatchable;

class FormDataStored
{
    use Dispatchable;

    public function __construct(public FormData $formData) {}
}
