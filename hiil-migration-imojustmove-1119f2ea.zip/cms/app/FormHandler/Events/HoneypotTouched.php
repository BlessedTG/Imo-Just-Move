<?php

namespace App\FormHandler\Events;

use Illuminate\Http\Request;

class HoneypotTouched
{
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(public Request $request) {}
}
