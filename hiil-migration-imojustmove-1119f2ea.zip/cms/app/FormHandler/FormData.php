<?php namespace App\FormHandler;

use App\FormHandler\Http\Requests\FormSubmitRequest;
use DateTime;
use Illuminate\Support\Facades\Crypt;

final class FormData
{
    const FIELD_EMAIL = 'email';

    /**
     * @param string $id
     * @param array<string, string> $payload
     * @param FormConfig $formConfig
     * @param string $formName
     * @param DateTime $createdAt
     */
    public function __construct(
        private string $id,
        private readonly array $payload,
        private FormConfig $formConfig,
        private string $formName,
        private DateTime $createdAt
    ) {}

    public static function createFromRequest(
        FormConfigCollection $formConfigCollection,
        FormSubmitRequest $request
    ): self {
        $formConfig = $formConfigCollection->fetchByName($request->formName());
        if (!$formConfig) {
            throw new \InvalidArgumentException('Form config not found');
        }
        return new self(
            // TODO Read unique ID from request
            uniqid(),
            $request->payload(),
            $formConfig,
            $request->formName(),
            now()
        );
    }

    public function id(): string
    {
        return $this->id;
    }

    public function payload(): array
    {
        return $this->payload;
    }

    public function payloadForStorage(): string
    {
        return Crypt::encrypt($this->payload);
    }

    public function formConfigForStorage(): string
    {
        return Crypt::encrypt($this->formConfig);
    }

    public function formConfig(): FormConfig
    {
        return $this->formConfig;
    }

    public function payloadWithBracketNotation(): array
    {
        $convertToBrackets = function ($value, string $key) {
            return [dot_notation_to_bracket_notation($key) => $value];
        };
        return collect($this->payload)
            ->mapWithKeys($convertToBrackets)
            ->toArray();
    }

    public function formName(): string
    {
        return $this->formName;
    }

    public function description(): string
    {
        return $this->formConfig->description;
    }

    public function createdAt(): DateTime
    {
        return $this->createdAt;
    }
}
