<?php

namespace App\FormHandler;

use Illuminate\Http\Request;

final class Honeypot
{
    public function __construct(public string $honeypotFieldName) {}

    public function isConfigured(): bool
    {
        return !empty($this->honeypotFieldName);
    }

    public function honeyIsTouched(Request $request): bool
    {
        // Honeypot field should exist, otherwise it's 'touched'
        if (!$request->exists($this->honeypotFieldName)) {
            return true;
        }
        // When it exists and is filled, it's 'touched'
        return $request->filled($this->honeypotFieldName);
    }
}
