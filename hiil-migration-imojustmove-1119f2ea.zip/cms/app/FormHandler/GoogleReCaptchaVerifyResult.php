<?php

namespace App\FormHandler;

final class GoogleReCaptchaVerifyResult
{
    private function __construct(
        public string $action,
        public bool $passed,
        public float $score,
        public float $minimumScore
    ) {}

    public static function passed(
        string $action,
        float $score,
        float $minimumScore
    ): self {
        return new self($action, true, $score, $minimumScore);
    }

    public static function failed(
        string $action,
        float $score,
        float $minimumScore
    ): self {
        return new self($action, false, $score, $minimumScore);
    }
}
