<?php

namespace App\FormHandler;

use App\FormHandler\Rules\ConditionallyRequired;

final class Ruleset
{
    /**
     * @return array<string, mixed>
     */
    public static function fromFormConfig(FormConfig $config): array
    {
        $allRules = [];
        foreach ($config->elements as $element) {
            $rules = [];
            // Requiredness
            $rules[] = $element->required ? 'required' : 'nullable';

            if ($element->type === FormElementType::MultiCheckbox) {
                $rules[] = 'array';
            }

            // Attachment
            if ($element->type === FormElementType::Attachment) {
                $rules[] = 'json';
            }

            // Number
            if (
                $element->type === FormElementType::Currency ||
                $element->type === FormElementType::Number
            ) {
                $rules[] = 'numeric';
                if (isset($element->number['min'])) {
                    $rules[] = 'min:' . $element->number['min'];
                }
                if (isset($element->number['max'])) {
                    $rules[] = 'max:' . $element->number['max'];
                }
            }

            // Email
            if ($element->type === FormElementType::Email) {
                $rules[] = 'email:strict';
            }

            // Max characters
            if ($element->maxChars) {
                $rules[] = 'max:' . $element->maxChars;
            }

            // Dates
            if ($element->type === FormElementType::Datepicker) {
                $rules[] = 'date';

                if ($element->minDate) {
                    $rules[] = 'after:' . $element->minDate->format('Y-m-d');
                }
            }

            // Choices
            if (count($element->choices)) {
                $rules[] = 'in:' . implode(',', $element->choices);
            }

            // Conditional requiredness
            if ($element->conditionallyRequired) {
                $rules[] = new ConditionallyRequired(
                    $element->conditionallyRequired
                );
            }

            $allRules[$element->id] = $rules;
        }
        return $allRules;
    }
}
