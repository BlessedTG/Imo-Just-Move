<?php namespace App;

final class Duration
{
    public function __construct(public readonly int $seconds) {}

    public static function fromSeconds(int $seconds): self
    {
        return new self($seconds);
    }

    public function toHumanReadable(): string
    {
        $hours = floor($this->seconds / 3600);
        $minutes = floor(($this->seconds % 3600) / 60);
        $seconds = $this->seconds % 60;

        return sprintf('%02d:%02d:%02d', $hours, $minutes, $seconds);
    }
}
