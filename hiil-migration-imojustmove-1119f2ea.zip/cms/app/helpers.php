<?php

use App\Nova\TargetAudience;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images;
use Ebess\AdvancedNovaMediaLibrary\Fields\Media;
use Illuminate\Contracts\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Http\Requests\NovaRequest;

/**
 * Recursively remove all null values from an iterable resource.
 *
 * @param iterable<string, mixed> $resource
 * @return array<mixed>
 */
function reject_null_values(iterable $resource): array
{
    return collect($resource)
        ->reduce(
            fn(Collection $carry, mixed $item, string $key) => is_null($item)
                ? $carry
                : (is_iterable($item)
                    ? $carry->merge([
                        $key => reject_null_values($item),
                    ])
                    : $carry->merge([$key => $item])),
            new Collection()
        )
        ->toArray();
}

function targetAudienceField(string $label, string $name): BelongsTo
{
    return BelongsTo::make($label, $name, TargetAudience::class)
        ->relatableQueryUsing(function (NovaRequest $request, Builder $query) {
            // Make sure the default target audience is always on top
            return $query->orderBy('is_default', 'desc');
        })
        ->dontReorderAssociatables()
        ->sortable();
}

/**
 * Interpolate a string with the given values.
 *
 * @param array<array-key, string> $variables
 */
function interpolateString(string $template, array $variables): string
{
    return preg_replace_callback(
        '/\{(\w+)\}/',
        function ($matches) use ($variables) {
            return isset($variables[$matches[1]])
                ? $variables[$matches[1]]
                : $matches[0];
        },
        $template
    ) ?? '';
}

/**
 * Format a Media model for inclusion in the API.
 *
 * @return array<string, mixed>
 */
function formatMedia(
    \Spatie\MediaLibrary\MediaCollections\Models\Media $media
): array {
    /**
     * Note: whether we use $media->getUrl() or just $media->filename here
     * depends on its usage in the front-end.
     * However, we do need the directory structure,
     * so filename alone is insufficient.
     */
    return array_merge(
        [
            'filename' => $media->getUrl(),
        ],
        $media->custom_properties ?: []
    );
}

function dot_notation_to_bracket_notation(string $key): string
{
    $segments = explode('.', $key);
    // leave the first segment as is
    $head = array_shift($segments);
    // wrap the rest of the segments in brackets
    $tail = collect($segments)->map(fn($key) => "[$key]");
    return $head . $tail->implode('');
}

/**
 * Returns an array of the string representation of the given enums.
 *
 * @return ($enums is array<\BackedEnum> ? array<string> : array<non-empty-string>)
 */
function enum_string_values(array $enums): array
{
    return array_map(
        fn($enum) => $enum instanceof \BackedEnum ? $enum->value : $enum->name,
        $enums
    );
}
