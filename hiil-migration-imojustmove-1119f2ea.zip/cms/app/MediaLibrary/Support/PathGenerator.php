<?php

namespace App\MediaLibrary\Support;

use Illuminate\Support\Str;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

/**
 * This PathGenerator uses uuid instead of id when generating the path.
 * This decouples the directory structure from the auto-increment
 * value of the database, making it easier to migrate data and
 * files between environments. It also places media in a
 * folder per model, aiding file organisation further.
 */
class PathGenerator implements
    \Spatie\MediaLibrary\Support\PathGenerator\PathGenerator
{
    public function getPath(Media $media): string
    {
        return Str::of(class_basename($media->model_type))
            ->lower()
            ->plural()
            ->append(DIRECTORY_SEPARATOR)
            ->append($media->uuid)
            ->append(DIRECTORY_SEPARATOR);
    }

    public function getPathForConversions(Media $media): string
    {
        return $this->getPath($media) . '/conversions/';
    }

    public function getPathForResponsiveImages(Media $media): string
    {
        return $this->getPath($media) . '/responsive-images/';
    }
}
