<?php

namespace App;

// TODO: Class name should be singular.
/**
 * Initial roles for the application. Custom roles can be made in the cms
 */
class Roles
{
    const SUPERADMIN_ROLE = 'Superadmin';
    const ADMIN_ROLE = 'Admin';
    const SITE_GENERATOR_ROLE = 'Site generator';

    const ALL = [
        self::SUPERADMIN_ROLE,
        self::ADMIN_ROLE,
        self::SITE_GENERATOR_ROLE,
    ];
}
