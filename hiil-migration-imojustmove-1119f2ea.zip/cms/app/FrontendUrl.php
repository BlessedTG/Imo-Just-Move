<?php

namespace App;

use App\Models\Outcome;
use App\Models\Problem;
use App\Models\ProblemCategory;
use App\Models\Questionnaire;
use App\Models\TargetAudience;
use JsonSerializable;
use Stringable;
use Illuminate\Support\Str;

/**
 * Represents a URL on the front-end of this website.
 * @see folder 'website' in this monorepo.
 *
 * #TODO Update unique constraint on the tables to reflect the structures made here
 */
final class FrontendUrl implements JsonSerializable, Stringable
{
    /**
     * URL for an outcome.
     * The format is /{language}/{target_audience_slug}/{problems_slug}/{problem_slug}/{outcomes_slug}/{outcome_slug}
     */
    public static function fromOutcome(Outcome $outcome): self
    {
        $urlPath = Str::of('/');
        $languages = resolve(Languages::class);
        $problemsSlug = trans(
            'resource-slugs.problems',
            [],
            $outcome->language
        );
        $outcomesSlug = trans(
            'resource-slugs.outcomes',
            [],
            $outcome->language
        );

        $problemSlug = $outcome->problem->slug ?? ''; // In some nova contexts the problem is not loaded, in that case we just return an empty string

        if ($outcome->language !== $languages->default()) {
            $urlPath = $urlPath->append($outcome->language)->append('/');
        }

        if (
            $outcome->target_audience &&
            !$outcome->target_audience->is_default
        ) {
            $urlPath = $urlPath
                ->append(
                    self::getTargetAudienceSlug(
                        $outcome->target_audience,
                        $outcome->language
                    )
                )
                ->append('/');
        }
        $urlPath = $urlPath
            ->append($problemsSlug)
            ->append('/')
            ->append($problemSlug)
            ->append('/')
            ->append($outcomesSlug)
            ->append('/')
            ->append($outcome->slug);
        return new self($urlPath);
    }

    /**
     * URL for a problem.
     * The format is /{language}/{target_audience_slug}/{problem_category_slug}/{problems_slug}/{problem_slug}
     */
    public static function fromProblem(Problem $problem): self
    {
        $urlPath = Str::of('/');
        $languages = resolve(Languages::class);
        $problemsSlug = trans(
            'resource-slugs.problems',
            [],
            $problem->language
        );
        $problemCategorySlug = $problem->category?->slug;
        if ($problem->language !== $languages->default()) {
            $urlPath = $urlPath->append($problem->language)->append('/');
        }
        if (
            $problem->target_audience &&
            !$problem->target_audience->is_default
        ) {
            $urlPath = $urlPath
                ->append(
                    self::getTargetAudienceSlug(
                        $problem->target_audience,
                        $problem->language
                    )
                )
                ->append('/');
        }
        if ($problemCategorySlug) {
            $urlPath = $urlPath->append($problemCategorySlug)->append('/');
        }
        $urlPath = $urlPath
            ->append($problemsSlug)
            ->append('/')
            ->append($problem->slug);
        return new self($urlPath);
    }

    /**
     * URL for a problem category.
     * The format is /{language}/{target_audience_slug}/{problem_categories_slug}/{problem_category_slug}
     */
    public static function fromProblemCategory(ProblemCategory $category): self
    {
        $urlPath = Str::of('/');
        $languages = resolve(Languages::class);
        $problemCategoriesSlug = trans(
            'resource-slugs.problem-categories',
            [],
            $category->language
        );
        if ($category->language !== $languages->default()) {
            $urlPath = $urlPath->append($category->language)->append('/');
        }
        if (
            $category->target_audience &&
            !$category->target_audience->is_default
        ) {
            $urlPath = $urlPath
                ->append(
                    self::getTargetAudienceSlug(
                        $category->target_audience,
                        $category->language
                    )
                )
                ->append('/');
        }
        $urlPath = $urlPath
            ->append($problemCategoriesSlug)
            ->append('/')
            ->append($category->slug);

        return new self($urlPath);
    }

    /**
     * URL for a questionnaire.
     * The format is /{language}/{target_audience_slug}/{questionnaires_slug}/{questionnaire_slug}
     */
    public static function fromQuestionnaire(Questionnaire $questionnaire): self
    {
        $urlPath = Str::of('/');
        $languages = resolve(Languages::class);
        $questionnairesSlug = trans(
            'resource-slugs.questionnaires',
            [],
            $questionnaire->language
        );
        if ($questionnaire->language !== $languages->default()) {
            $urlPath = $urlPath->append($questionnaire->language)->append('/');
        }
        if (
            $questionnaire->target_audience &&
            !$questionnaire->target_audience->is_default
        ) {
            $urlPath = $urlPath
                ->append(
                    self::getTargetAudienceSlug(
                        $questionnaire->target_audience,
                        $questionnaire->language
                    )
                )
                ->append('/');
        }
        $urlPath = $urlPath
            ->append($questionnairesSlug)
            ->append('/')
            ->append($questionnaire->slug);

        return new self($urlPath);
    }

    protected static function getTargetAudienceSlug(
        TargetAudience $targetAudience,
        string $language
    ): string {
        $slug = $targetAudience->getTranslation('slug', $language);
        if (!is_string($slug)) {
            throw new \RuntimeException(
                'Target audience slug not found for language ' . $language
            );
        }
        return $slug;
    }

    private function __construct(private string $url) {}

    public function jsonSerialize(): mixed
    {
        return $this->url;
    }

    public function __toString()
    {
        return $this->url;
    }
}
