<?php

namespace App\Casts;

use App\Duration;
use Illuminate\Contracts\Database\Eloquent\CastsAttributes;
use Illuminate\Database\Eloquent\Model;

/**
 * Casts a model attribute to a Duration instance when retrieving,
 * and converts it to seconds (integer) when setting.
 *
 * @implements CastsAttributes<int|null, Duration|int>
 */
class AsDuration implements CastsAttributes
{
    /**
     * Cast the given value.
     *
     * @param  array<string, mixed>  $attributes
     */
    public function get(
        Model $model,
        string $key,
        mixed $value,
        array $attributes
    ): Duration|null {
        if ($value === null) {
            return null;
        }
        if (is_int($value)) {
            return Duration::fromSeconds($value); // Convert seconds to Duration.
        }
        throw new \InvalidArgumentException(
            'Expected Duration instance, got ' . gettype($value)
        );
    }

    /**
     * Prepare the given value for storage.
     *
     * @param  array<string, mixed>  $attributes
     */
    public function set(
        Model $model,
        string $key,
        mixed $value,
        array $attributes
    ): int {
        if (is_int($value)) {
            return $value; // Already an integer, no conversion needed.
        }
        if ($value instanceof Duration) {
            return $value->seconds; // Convert Duration to seconds.
        }
        throw new \InvalidArgumentException(
            'Value must be an instance of Duration or an integer.'
        );
    }
}
