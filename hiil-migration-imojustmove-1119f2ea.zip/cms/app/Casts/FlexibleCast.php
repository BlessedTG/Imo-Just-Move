<?php

namespace App\Casts;

use App\Nova\Flexible\Layouts\CallToAction;
use App\Nova\Flexible\Layouts\Faq;
use App\Nova\Flexible\Layouts\FeedbackForm;
use App\Nova\Flexible\Layouts\Images;
use App\Nova\Flexible\Layouts\LargeText;
use App\Nova\Flexible\Layouts\LinkThrough;
use App\Nova\Flexible\Layouts\ProblemIdentification;
use App\Nova\Flexible\Layouts\Resources;
use App\Nova\Flexible\Layouts\ReferralSignup;
use App\Nova\Flexible\Layouts\ShareThisPage;
use App\Nova\Flexible\Layouts\Step;
use App\Nova\Flexible\Layouts\Text;
use App\Nova\Flexible\Layouts\TextMedia;
use App\Nova\Flexible\Layouts\WhatToExpect;
use Illuminate\Database\Eloquent\Casts\Json;
use Whitecube\NovaFlexibleContent\Value\FlexibleCast as BaseFlexibleCast;

class FlexibleCast extends BaseFlexibleCast
{
    /**
     * @var array<string,string>
     */
    protected $layouts = [
        // Add your layouts here:
        'call_to_action' => CallToAction::class,
        'faq' => Faq::class,
        'feedback_form' => FeedbackForm::class,
        'images' => Images::class,
        'large_text' => LargeText::class,
        'link_through' => LinkThrough::class,
        'problem_identification' => ProblemIdentification::class,
        'resources' => Resources::class,
        'referral_signup' => ReferralSignup::class,
        'share_this_page' => ShareThisPage::class,
        'step' => Step::class,
        'text' => Text::class,
        'text_media' => TextMedia::class,
        'what_to_expect' => WhatToExpect::class,
    ];

    /**
     * Why is this necessary?
     * See this issue: https://github.com/whitecube/nova-flexible-content/issues/515#issuecomment-2062909835
     */
    public function set($model, string $key, $value, array $attributes)
    {
        return [$key => Json::encode($value)];
    }
}
