<?php

namespace App\Models;

use App\Casts\FlexibleCast;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

/**
 * @property integer $parent_id
 */
class Page extends \Grrr\Pages\Models\Page implements HasMedia
{
    use InteractsWithMedia;

    const TEMPLATE_HOME = 'home';
    const TEMPLATE_PRODUCT_CATEGORY_LIST = 'product_category_index';
    const TEMPLATE_DEFAULT = 'default';
    const TEMPLATE_WHAT_TO_EXPECT = 'what to expect';
    const TEMPLATE_PROBLEM_IDENTIFICATION = 'problem identification';

    protected $casts = [
        'content' => FlexibleCast::class,
        'metadata' => 'array',
    ];
}
