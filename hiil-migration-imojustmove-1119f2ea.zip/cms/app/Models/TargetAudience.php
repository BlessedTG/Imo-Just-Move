<?php

namespace App\Models;

use App\Events\SavingTargetAudience;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Sluggable\HasTranslatableSlug;
use Spatie\Sluggable\SlugOptions;
use Spatie\Translatable\HasTranslations;

/**
 * @property int $id
 * @property string $name
 * @property string $slug
 * @property bool $is_default
 * @property DateTime|null $created_at
 * @property DateTime|null $updated_at
 * @property string|null $home_url
 */
class TargetAudience extends Model
{
    use HasFactory;
    use HasTranslatableSlug;
    use HasTranslations;

    protected $fillable = ['name', 'slug', 'is_default'];

    protected $dispatchesEvents = [
        'saving' => SavingTargetAudience::class,
    ];

    public array $translatable = ['name', 'slug', 'home_url'];

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->doNotGenerateSlugsOnUpdate()
            ->generateSlugsFrom('name')
            ->saveSlugsTo('slug');
    }
}
