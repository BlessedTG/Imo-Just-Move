<?php

namespace App\Models;

use App\Events\SavingIntakeStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class IntakeStatus extends Model
{
    use HasFactory;
    use HasTranslations;

    public array $translatable = ['label'];

    protected function casts()
    {
        return [
            'is_default' => 'boolean',
        ];
    }

    protected $dispatchesEvents = [
        'saving' => SavingIntakeStatus::class,
    ];
}
