<?php

namespace App\Models;

use App\Events\SavingReferralStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class ReferralStatus extends Model
{
    use HasFactory;
    use HasTranslations;

    public array $translatable = ['label'];

    protected function casts()
    {
        return [
            'is_default' => 'boolean',
        ];
    }

    protected $dispatchesEvents = [
        'saving' => SavingReferralStatus::class,
    ];
}
