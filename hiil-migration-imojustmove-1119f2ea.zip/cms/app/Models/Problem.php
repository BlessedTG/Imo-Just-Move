<?php

namespace App\Models;

use App\FrontendUrl;
use App\Models\Outcome;
use App\Models\ProblemCategory;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

/**
 * @property int $id
 * @property string $title
 * @property string $description
 * @property string $slug
 */
class Problem extends Model implements HasMedia
{
    use HasFactory;
    use HasSlug;
    use InteractsWithMedia;

    protected $appends = ['url'];

    protected $with = ['category', 'target_audience'];

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->doNotGenerateSlugsOnUpdate()
            ->generateSlugsFrom('title')
            ->allowDuplicateSlugs() // Because we handle uniqueness in more complex way
            ->saveSlugsTo('slug');
    }

    /**
     * Get the category that owns the problem.
     *
     * @return BelongsTo<ProblemCategory,Problem>
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(ProblemCategory::class, 'problem_category_id');
    }

    /**
     * Get the outcomes for the problem.
     *
     * @return HasMany<Outcome>
     */
    public function outcomes(): HasMany
    {
        return $this->hasMany(Outcome::class);
    }

    /**
     * @return BelongsTo<TargetAudience, self>
     */
    public function target_audience(): BelongsTo
    {
        return $this->belongsTo(TargetAudience::class);
    }

    /**
     * Get the relative url for the model
     *
     * @return Attribute<FrontendUrl, never>
     */
    protected function url(): Attribute
    {
        return Attribute::make(get: fn() => FrontendUrl::fromProblem($this));
    }
}
