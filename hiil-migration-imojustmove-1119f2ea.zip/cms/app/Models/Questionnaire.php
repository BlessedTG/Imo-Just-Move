<?php

namespace App\Models;

use App\Casts\FlexibleCast;
use App\FrontendUrl;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

/**
 * @property int $id
 * @property string $title
 * @property string $slug
 */
class Questionnaire extends Model implements HasMedia
{
    use HasFactory;
    use HasSlug;
    use InteractsWithMedia;

    protected $appends = ['url'];

    protected $with = ['target_audience'];

    protected $casts = [
        'content' => FlexibleCast::class,
    ];

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->doNotGenerateSlugsOnUpdate()
            ->generateSlugsFrom('title')
            ->allowDuplicateSlugs()
            ->saveSlugsTo('slug');
    }

    /**
     * @return BelongsTo<TargetAudience, self>
     */
    public function target_audience(): BelongsTo
    {
        return $this->belongsTo(TargetAudience::class);
    }

    /**
     * Get the relative url for the model
     *
     * @return Attribute<FrontendUrl, null>
     */
    protected function url(): Attribute
    {
        return Attribute::make(
            get: fn() => FrontendUrl::fromQuestionnaire($this)
        );
    }
}
