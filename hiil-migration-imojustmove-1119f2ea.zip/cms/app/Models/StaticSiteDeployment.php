<?php

namespace App\Models;

use App\Casts\AsDuration;
use App\DeploymentStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * @property DeploymentStatus $status
 * @property int|null $duration
 * @property string|null $message
 * @property \Illuminate\Support\Carbon|null $created_at
 */
class StaticSiteDeployment extends Model
{
    /** @use HasFactory<\Database\Factories\StaticSiteDeploymentFactory> */
    use HasFactory;

    protected $fillable = ['status', 'duration', 'message'];

    /**
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'status' => DeploymentStatus::class,
            'duration' => AsDuration::class,
        ];
    }
}
