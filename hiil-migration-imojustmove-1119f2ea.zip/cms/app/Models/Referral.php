<?php

namespace App\Models;

use App\Events\ReferralIsBeingCreated;
use App\Events\ReferralWasCreated;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * @property string $name
 * @property string $surname
 * @property string $phone_number
 * @property ?string $email
 * @property string $location
 * @property string $field_of_expertise
 * @property string $role
 * @property string $enrolment_number
 * @property-read Collection<Outcome> $outcomes
 *
 */
class Referral extends Model
{
    use HasFactory;

    const STATUS_PUBLISHED = 'PUBLISHED';
    const STATUS_DRAFT = 'DRAFT';

    const STATUSES = [self::STATUS_PUBLISHED, self::STATUS_DRAFT];

    protected $fillable = [
        'name',
        'surname',
        'phone_number',
        'email',
        'location',
        'expertise',
        'role',
        'enrolment_number',
        'additional_message',
        'language',
        'status',
        'referral_status_id',
        'form_submission_id',
        'language',
    ];

    protected $dispatchesEvents = [
        'creating' => ReferralIsBeingCreated::class,
        'created' => ReferralWasCreated::class,
    ];

    /**
     * @return BelongsToMany<Outcome>
     */
    public function outcomes(): BelongsToMany
    {
        return $this->belongsToMany(Outcome::class);
    }

    /**
     * @return BelongsTo<Region, self>
     */
    public function region(): BelongsTo
    {
        return $this->belongsTo(Region::class);
    }

    /**
     * @return BelongsTo<FormSubmission, self>
     */
    public function formSubmission(): BelongsTo
    {
        return $this->belongsTo(FormSubmission::class);
    }

    /**
     * @return BelongsTo<ReferralStatus, self>
     */
    public function referralStatus(): BelongsTo
    {
        return $this->belongsTo(ReferralStatus::class);
    }
}
