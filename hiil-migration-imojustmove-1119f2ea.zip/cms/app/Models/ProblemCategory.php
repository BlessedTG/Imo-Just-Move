<?php

namespace App\Models;

use App\FrontendUrl;
use App\Models\Problem;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

/**
 * @property string $title
 * @property string $slug
 * @property string $description
 * @property string $url
 */
class ProblemCategory extends Model
{
    use HasFactory;
    use HasSlug;

    protected $appends = ['url'];

    protected $with = ['target_audience'];

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->doNotGenerateSlugsOnUpdate()
            ->generateSlugsFrom('title')
            ->allowDuplicateSlugs() // Because we handle uniqueness in more complex way
            ->saveSlugsTo('slug');
    }

    /**
     * Get the problems for the category.
     *
     * @return HasMany<Problem>
     */
    public function problems(): HasMany
    {
        return $this->hasMany(Problem::class);
    }

    /**
     * @return BelongsTo<Questionnaire, self>
     */
    public function questionnaire(): BelongsTo
    {
        return $this->belongsTo(Questionnaire::class);
    }

    /**
     * @return BelongsTo<TargetAudience, self>
     */
    public function target_audience(): BelongsTo
    {
        return $this->belongsTo(TargetAudience::class);
    }

    /**
     * Get the relative url for the model
     *
     * @return Attribute<FrontendUrl, never>
     */
    protected function url(): Attribute
    {
        return Attribute::make(
            get: fn() => FrontendUrl::fromProblemCategory($this)
        );
    }
}
