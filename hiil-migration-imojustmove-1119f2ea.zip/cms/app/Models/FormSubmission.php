<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 * @property string $id
 * @property string $form_name
 * @property array<string, string> $payload
 * @property \DateTime $created_at
 * @property bool $incrementing
 * @property bool $timestamps
 * @property-read Intake|null $intake
 * @property-read Feedback|null $feedback
 * @property-read Referral|null $referral
 */
class FormSubmission extends Model
{
    public $incrementing = false;
    public $timestamps = false;

    protected $fillable = ['id', 'form_name', 'payload', 'created_at'];

    protected function casts(): array
    {
        return [
            'payload' => 'array',
            'created_at' => 'datetime',
        ];
    }

    /**
     * @return HasOne<Intake>
     */
    public function intake(): HasOne
    {
        return $this->hasOne(Intake::class);
    }

    /**
     * @return HasOne<Feedback>
     */
    public function feedback(): HasOne
    {
        return $this->hasOne(Feedback::class);
    }

    /**
     * @return HasOne<Referral>
     */
    public function referral(): HasOne
    {
        return $this->hasOne(Referral::class);
    }
}
