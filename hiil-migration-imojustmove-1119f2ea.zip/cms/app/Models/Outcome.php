<?php

namespace App\Models;

use App\Casts\FlexibleCast;
use App\FrontendUrl;
use App\Models\Problem;
use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

/**
 * @property-read Problem $problem
 * @property-read TargetAudience|null $target_audience
 */
class Outcome extends Model implements HasMedia
{
    use HasFactory;
    use InteractsWithMedia;
    use HasSlug;

    protected $appends = ['url'];

    protected $casts = [
        'content' => FlexibleCast::class,
    ];

    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->doNotGenerateSlugsOnUpdate()
            ->generateSlugsFrom('title')
            ->allowDuplicateSlugs()
            ->saveSlugsTo('slug');
    }

    /**
     * @return BelongsTo<Problem,Outcome>
     */
    public function problem(): BelongsTo
    {
        return $this->belongsTo(Problem::class);
    }

    /**
     * @return BelongsToMany<Referral>
     */
    public function referrals(): BelongsToMany
    {
        return $this->belongsToMany(Referral::class);
    }

    /**
     * @return BelongsTo<TargetAudience, self>
     */
    public function target_audience(): BelongsTo
    {
        return $this->belongsTo(TargetAudience::class);
    }

    /**
     * Get the relative url for the model
     *
     * @return Attribute<FrontendUrl, null>
     */
    protected function url(): Attribute
    {
        return Attribute::make(get: fn() => FrontendUrl::fromOutcome($this));
    }
}
