<?php

namespace App\Models;

use App\Events\IntakeIsBeingCreated;
use App\Events\IntakeWasCreated;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Outl1ne\NovaNotesField\Traits\HasNotes;
use Spatie\MediaLibrary\HasMedia;
use Spatie\MediaLibrary\InteractsWithMedia;

class Intake extends Model implements HasMedia
{
    use HasFactory;
    use HasNotes;
    use InteractsWithMedia;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'surname',
        'email',
        'phone_number',
        'location',
        'problem',
        'outcome',
        'additional_message',
        'form_submission_id',
        'intake_status_id',
        'owner_id',
    ];

    protected $dispatchesEvents = [
        'creating' => IntakeIsBeingCreated::class,
        'created' => IntakeWasCreated::class,
    ];

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('attachments')->useDisk(
            'private_attachments'
        );
    }

    /**
     * @return BelongsTo<User, self>
     */
    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    /**
     * @return BelongsTo<FormSubmission, self>
     */
    public function formSubmission(): BelongsTo
    {
        return $this->belongsTo(FormSubmission::class);
    }

    /**
     * @return BelongsTo<IntakeStatus, self>
     */
    public function intakeStatus(): BelongsTo
    {
        return $this->belongsTo(IntakeStatus::class);
    }
}
