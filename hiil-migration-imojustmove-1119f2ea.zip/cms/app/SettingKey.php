<?php namespace App;

use Spatie\TypeScriptTransformer\Attributes\TypeScript;

/**
 * Please define your unique setting keys here.
 * It will make your life a lot easier.
 */
#[TypeScript]
enum SettingKey: string
{
    # General
    case BackButtonLabel = 'back_button_label';
    case EmailShareSubject = 'email_share_subject';

    # Problems
    case ProblemDesiredOutcomesTitle = 'problem_desired_outcomes_title';
    case ProblemDesiredOutcomesDescription = 'problem_desired_outcomes_description';
    case ProblemKnowYourRightsTitle = 'problem_know_your_rights_title';
    case ToOutcomePageLabel = 'to_outcome_page_button_label';
    case ProblemCategoryDescription = 'problem_category_description';
    case ProblemCategoryHelpButtonLabel = 'problem_category_help_button_label';

    # Step titles
    case FirstStepLabel = 'first_step_label';
    case SecondStepLabel = 'second_step_label';
    case ThirdStepLabel = 'third_step_label';
    case FourthStepLabel = 'fourth_step_label';

    # Outcomes
    case OutcomeTitle = 'outcome_title';
    case OutcomeHelpTitle = 'outcome_help_title';

    # Referral filter
    case ReferralFilterLabel = 'referral_filter_label';
    case ReferralFilterAllOption = 'referral_filter_all_option';

    # Notification overlay content
    case NotificationOverlayTitle = 'notification_overlay_title';
    case NotificationOverlayDescription = 'notification_overlay_description';
    case NotificationOverlayChangeButtonLabel = 'notification_overlay_change_button_label';
    case NotificationOverlayResumeButtonLabel = 'notification_overlay_resume_button_label';

    # Emergency overlay content
    case EmergencyOverlayTitle = 'emergency_overlay_title';
    case EmergencyOverlayDescription = 'emergency_overlay_description';
    case EmergencyOverlayLinkLabel = 'emergency_overlay_link_label';
    case EmergencyOverlayPhoneNumber = 'emergency_overlay_phone_number';

    # Close questionnaire overlay content
    case CloseQuestionnaireOverlayTitle = 'close_questionnaire_overlay_title';
    case CloseQuestionnaireOverlayDescription = 'close_questionnaire_overlay_description';
    case CloseQuestionnaireOverlayLinkLabel = 'close_questionnaire_overlay_link_label';

    # Questionnaire
    case QuestionnaireRestartButtonLabel = 'questionnaire_restart_button_label';
    case QuestionnaireResultsTitle = 'questionnaire_results_title';
    case QuestionnaireOutcomeButtonLabel = 'questionnaire_outcome_button_label';
    case QuestionnaireAnalysisTitle = 'questionnaire_analysis_title';
    case QuestionnaireResultSubtitle = 'questionnaire_result_subtitle';
    case QuestionnaireNoResultTitle = 'questionnaire_no_result_title';
    case QuestionnaireRequestAssistanceButtonLabel = 'questionnaire_request_assistance_button_label';
    case QuestionnaireFAQPageLink = 'questionnaire_faq_page_link';
    case QuestionnaireFAQPageLinkLabel = 'questionnaire_faq_page_link_label';

    # Referral form
    case ReferralFormTitle = 'referral_form_title';
    case ReferralFormDescription = 'referral_form_description';

    case ReferralFormSuccessTitle = 'referral_form_success_title';
    case ReferralFormSuccessMessage = 'referral_form_success_message';
    case ReferralFormErrorTitle = 'referral_form_error_title';
    case ReferralFormErrorMessage = 'referral_form_error_message';

    case ReferralFormNameLabel = 'referral_form_name_label';
    case ReferralFormNameInstruction = 'referral_form_name_instruction';
    case ReferralFormSurnameLabel = 'referral_form_surname_label';
    case ReferralFormSurnameInstruction = 'referral_form_surname_instruction';
    case ReferralFormPhoneNumberLabel = 'referral_form_phone_number_label';
    case ReferralFormPhoneNumberInstruction = 'referral_form_phone_number_instruction';
    case ReferralFormEmailLabel = 'referral_form_email_label';
    case ReferralFormEmailInstruction = 'referral_form_email_instruction';
    case ReferralFormLocationLabel = 'referral_form_location_label';
    case ReferralFormLocationInstruction = 'referral_form_location_instruction';
    case ReferralFormExpertiseLabel = 'referral_form_expertise_label';
    case ReferralFormExpertiseInstruction = 'referral_form_expertise_instruction';
    case ReferralFormRoleLabel = 'referral_form_role_label';
    case ReferralFormRoleInstruction = 'referral_form_role_instruction';
    case ReferralFormEnrolmentNumberLabel = 'referral_form_enrolment_number_label';
    case ReferralFormEnrolmentNumberInstruction = 'referral_form_enrolment_number_instruction';
    case ReferralFormAdditionalMessageLabel = 'referral_form_additional_message_label';
    case ReferralFormAdditionalMessageInstruction = 'referral_form_additional_message_instruction';

    case ReferralFormConfirmationEmailSubject = 'referral_form_confirmation_email_subject';
    case ReferralFormConfirmationEmailBody = 'referral_form_confirmation_email_body';

    case ReferralFormSubmitButtonLabel = 'referral_form_submit_button_label';

    # Intake form
    case IntakeFormTitle = 'intake_form_title';
    case IntakeFormDescription = 'intake_form_description';

    case IntakeFormSuccessTitle = 'intake_form_success_title';
    case IntakeFormSuccessMessage = 'intake_form_success_message';
    case IntakeFormErrorTitle = 'intake_form_error_title';
    case IntakeFormErrorMessage = 'intake_form_error_message';

    case IntakeFormNameLabel = 'intake_form_name_label';
    case IntakeFormNameInstruction = 'intake_form_name_instruction';
    case IntakeFormSurnameLabel = 'intake_form_surname_label';
    case IntakeFormSurnameInstruction = 'intake_form_surname_instruction';
    case IntakeFormPhoneNumberLabel = 'intake_form_phone_number_label';
    case IntakeFormPhoneNumberInstruction = 'intake_form_phone_number_instruction';
    case IntakeFormEmailLabel = 'intake_form_email_label';
    case IntakeFormEmailInstruction = 'intake_form_email_instruction';
    case IntakeFormLocationLabel = 'intake_form_location_label';
    case IntakeFormLocationInstruction = 'intake_form_location_instruction';
    case IntakeFormAdditionalMessageLabel = 'intake_form_additional_message_label';
    case IntakeFormAdditionalMessageInstruction = 'intake_form_additional_message_instruction';

    case IntakeFormSubmitButtonLabel = 'intake_form_submit_button_label';
    case IntakeFormConfirmationEmailSubject = 'intake_form_confirmation_email_subject';
    case IntakeFormConfirmationEmailBody = 'intake_form_confirmation_email_body';

    # Request support form (form inputs are the same as in the intake form)
    case RequestSupportFormTitle = 'request_support_form_title';
    case RequestSupportFormDescription = 'request_support_form_description';

    # Feedback form
    case FeedbackFormTitle = 'feedback_form_title';
    case FeedbackFormDescription = 'feedback_form_description';

    case FeedbackFormSuccessTitle = 'feedback_form_success_title';
    case FeedbackFormSuccessMessage = 'feedback_form_success_message';
    case FeedbackFormErrorTitle = 'feedback_form_error_title';
    case FeedbackFormErrorMessage = 'feedback_form_error_message';

    case FeedbackFormNegativeLabel = 'feedback_form_negative_label';
    case FeedbackFormPositiveLabel = 'feedback_form_positive_label';
    case FeedbackFormMessageLabel = 'feedback_form_message_label';
    case FeedbackFormMessageInstruction = 'feedback_form_instruction';

    case FeedbackFormSubmitButtonLabel = 'feedback_form_submit_button_label';

    # Footer
    case FooterHiilLink = 'footer_hiil_link';
    case FooterCreditText = 'footer_credit_text';
    case ShowHiilLogo = 'show_hiil_logo';

    # User login
    case LoginButtonLabel = 'login_button_label';
    case LoggedInAs = 'logged_in_as';
    case LoginSuspenseMessage = 'login_suspense_message';
    case LogoutButtonLabel = 'logout_button_label';
    case LoggingOutMessage = 'logging_out_message';
    case LoginOverlayTitle = 'login_overlay_title';
    case NotLoggedIn = 'not_logged_in';

    # Protected pages
    case ProtectedPageNotAuthorizedMessage = 'protected_page_not_authorized_message';
    case ProtectedPageHomeButtonText = 'protected_page_home_button_text';

    # Cookies
    case CookieBannerTitle = 'cookiebanner_title';
    case CookieBannerIntroduction = 'cookiebanner_introduction';
    case CookieBannerFunctionalCookiesName = 'cookiebanner_functional_cookies_name';
    case CookieBannerFunctionalCookiesDescription = 'cookiebanner_functional_cookies_description';
    case CookieBannerMarketingCookiesName = 'cookiebanner_marketing_cookies_name';
    case CookieBannerMarketingCookiesDescription = 'cookiebanner_marketing_cookies_description';
    case CookieBannerAcceptAllLabel = 'cookiebanner_accept_all_label';
    case CookieBannerSavePreferencesLabel = 'cookiebanner_save_preferences_label';

    case CookieBannerChangeConsentLinkLabel = 'cookiebanner_change_consent_link_label';
    case CookieBannerMarketingCookiesRequiredMessage = 'cookiebanner_marketing_cookies_required_message';
}
