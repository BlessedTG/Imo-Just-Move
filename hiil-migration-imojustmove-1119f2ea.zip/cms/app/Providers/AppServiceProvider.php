<?php

namespace App\Providers;

use App\FormHandler\FormConfigCollection;
use App\FormHandler\FormHandlerClient;
use App\FormHandler\FormSubmissionRepository;
use App\FormHandler\FormSubmissionsRepositories;
use App\FormHandler\GoogleReCaptcha;
use App\FormHandler\Honeypot;
use App\FormHandler\IsFormSubmissionRepository;
use App\Languages;
use App\NovaSelectOptionsRepository;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->singleton(NovaSelectOptionsRepository::class);
        $this->app->singleton(Languages::class, function () {
            /** @var string */
            $defaultLanguage = config('app.default_language');
            /** @var string */
            $languages = config('app.languages');
            return new Languages(
                languages: explode(',', $languages),
                defaultLanguage: $defaultLanguage
            );
        });

        //TODO: Remove after moving form handler to CMS
        $this->app->singleton(FormHandlerClient::class, function () {
            /** @var string */
            $baseUrl = config('custom.form_handler.data_api_endpoint');
            /** @var string */
            $apiKey = config('custom.form_handler.data_api_key');
            return new FormHandlerClient(baseUrl: $baseUrl, apiKey: $apiKey);
        });

        $this->app->singleton(
            FormSubmissionsRepositories\InMemoryRepository::class
        );
        $this->app->singleton(FormSubmissionsRepositories\LogRepository::class);

        $this->app->singleton(IsFormSubmissionRepository::class, function () {
            /** @var string $formSubmissionsDatabase */
            $formSubmissionsDatabase = config(
                'custom.form_submissions_database'
            );
            return match ($formSubmissionsDatabase) {
                'eloquent' => $this->app->make(
                    FormSubmissionsRepositories\EloquentRepository::class
                ),
                'in-memory' => $this->app->make(
                    FormSubmissionsRepositories\InMemoryRepository::class
                ),
                'log' => $this->app->make(
                    FormSubmissionsRepositories\LogRepository::class
                ),
                default => throw new \Exception(
                    "Unknown form submissions database: $formSubmissionsDatabase"
                ),
            };
        });

        $this->app->singleton(
            GoogleReCaptcha::class,
            function (): GoogleReCaptcha {
                /** @var string $reCaptchaSecretKey */
                $reCaptchaSecretKey = config(
                    'services.google.recaptcha.secret_key'
                );
                /** @var float $reCaptchaMinimumScore */
                $reCaptchaMinimumScore = config(
                    'services.google.recaptcha.minimum_score'
                );
                return new GoogleReCaptcha(
                    $reCaptchaSecretKey,
                    $reCaptchaMinimumScore
                );
            }
        );

        $this->app->singleton(Honeypot::class, function (): Honeypot {
            /** @var string $honeypotFieldName */
            $honeypotFieldName = config('custom.honeypot.field_name', '');
            return new Honeypot($honeypotFieldName);
        });

        $this->app->singleton(
            FormConfigCollection::class,
            function (): FormConfigCollection {
                $formConfigDirectory = config_path('forms');
                return FormConfigCollection::makeFromDirectory(
                    $formConfigDirectory
                );
            }
        );
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
