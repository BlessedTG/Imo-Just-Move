<?php

namespace App\Providers;

use App\Events\SavingIntakeStatus;
use App\Events\SavingReferralStatus;
use App\Events\SavingTargetAudience;
use App\Events\UserIsBeingCreated;
use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Spatie\MediaLibrary\MediaCollections\Events\MediaHasBeenAddedEvent;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<string, array<int, string>>
     */
    protected $listen = [
        Registered::class => [SendEmailVerificationNotification::class],
        MediaHasBeenAddedEvent::class => [
            \App\Listeners\SaveOriginalImageSize::class,
            \App\Listeners\GenerateScaledImages::class,
        ],
        SavingIntakeStatus::class => [
            \App\Listeners\EnsureSingleDefaultForIntakeStatus::class,
        ],
        SavingReferralStatus::class => [
            \App\Listeners\EnsureSingleDefaultForReferralStatus::class,
        ],
        SavingTargetAudience::class => [
            \App\Listeners\EnsureSingleDefaultForTargetAudiences::class,
        ],
        UserIsBeingCreated::class => [\App\Listeners\AddModelUuid::class],
    ];

    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot(): void
    {
        //
    }
}
