<?php

namespace App\Providers;

use App\Exceptions\NovaCustomMessageHandler;
use App\Permissions;
use App\Nova\Dashboards\Main;
use App\Nova\Settings\CookiebannerFields;
use App\Nova\Settings\FeedbackFormFields;
use App\Nova\Settings\GeneralFields;
use App\Nova\Settings\IntakeFormFields;
use App\Nova\Settings\ProtectedPageFields;
use App\Nova\Settings\ReferralFormFields;
use App\Nova\Settings\UserLoginFields;
use App\Policies\PermissionPolicy;
use App\Policies\RolePolicy;
use Badinansoft\LanguageSwitch\LanguageSwitch;
use Grrr\Pages\PagesTool;
use Illuminate\Support\Facades\Gate;
use Laravel\Nova\Cards\Help;
use Laravel\Nova\Events\ServingNova;
use Laravel\Nova\Exceptions\NovaExceptionHandler;
use Laravel\Nova\Nova;
use Laravel\Nova\NovaApplicationServiceProvider;
use Outl1ne\MenuBuilder\MenuBuilder;
use Outl1ne\NovaSettings\NovaSettings;
use Publish\Publish;
use Sereny\NovaPermissions\NovaPermissions;

class NovaServiceProvider extends NovaApplicationServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        parent::boot();

        $this->app->bind(
            NovaExceptionHandler::class,
            NovaCustomMessageHandler::class
        );

        Nova::style('admin', base_path('public/css/nova/admin.css'));

        Nova::enableRTL(function () {
            return app()->getLocale() === 'ar';
        });
        Nova::withBreadcrumbs();
        Nova::withoutNotificationCenter();

        $this->addFieldMacros();

        Nova::serving(function (ServingNova $event) {
            NovaSettings::addSettingsFields(
                GeneralFields::all(),
                [],
                'General'
            );
            NovaSettings::addSettingsFields(
                IntakeFormFields::all(),
                [],
                'Intake form'
            );
            NovaSettings::addSettingsFields(
                ReferralFormFields::all(),
                [],
                'Referral form'
            );
            NovaSettings::addSettingsFields(
                FeedbackFormFields::all(),
                [],
                'Feedback form'
            );
            NovaSettings::addSettingsFields(
                UserLoginFields::all(),
                [],
                'User login'
            );
            NovaSettings::addSettingsFields(
                ProtectedPageFields::all(),
                [],
                'Protected pages'
            );
            NovaSettings::addSettingsFields(
                CookiebannerFields::all(),
                [],
                'Cookiebanner'
            );
        });
    }

    /**
     * Register the Nova routes.
     *
     * @return void
     */
    protected function routes()
    {
        Nova::routes()
            ->withAuthenticationRoutes(default: true)
            ->withPasswordResetRoutes()
            ->register();
    }

    /**
     * Register the Nova gate.
     *
     * This gate determines who can access Nova in non-local environments.
     *
     * @return void
     */
    protected function gate()
    {
        Gate::define('viewNova', function ($user) {
            // Every user is allowed to access Nova.
            return true;
        });
    }

    /**
     * Get the cards that should be displayed on the default Nova dashboard.
     *
     * @return array
     */
    protected function cards()
    {
        return [new Help()];
    }

    /**
     * Get the extra dashboards that should be displayed on the Nova dashboard.
     *
     * @return array
     */
    protected function dashboards()
    {
        return [new Main()];
    }

    /**
     * Get the tools that should be listed in the Nova sidebar.
     *
     * @return array
     */
    public function tools()
    {
        /** @var string $publishStrategy */
        $publishStrategy = config('custom.static_site_publish_strategy');
        return [
            new LanguageSwitch(),
            (new PagesTool())->canSee(function ($request) {
                $user = $request->user();
                return $user && $user->can(Permissions::MANAGE_SITE_CONTENT);
            }),
            (new MenuBuilder())->canSee(function ($request) {
                $user = $request->user();
                return $user && $user->can(Permissions::MANAGE_SITE_CONTENT);
            }),
            (new NovaSettings())->canSee(function ($request) {
                $user = $request->user();
                return $user && $user->can(Permissions::MANAGE_SITE_CONTENT);
            }),
            ...$publishStrategy === 'github'
                ? [
                    (new Publish())->canSee(function ($request) {
                        $user = $request->user();
                        return $user && $user->can(Permissions::PUBLISH_SITE);
                    }),
                ]
                : [],
            (new NovaPermissions())
                ->rolePolicy(RolePolicy::class)
                ->permissionPolicy(PermissionPolicy::class)
                ->permissionResource(\App\Nova\Permission::class)
                ->roleResource(\App\Nova\Role::class)
                ->canSee(function ($request) {
                    $user = $request->user();
                    return $user && $user->can(Permissions::MANAGE_ROLES);
                }),
        ];
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    protected function addFieldMacros(): void
    {
        // Macro for displaying a text field as a frontend link
        \Laravel\Nova\Fields\Text::macro('displayAsFrontendLink', function () {
            assert($this instanceof \Laravel\Nova\Fields\Text);
            return $this->displayUsing(function (mixed $value) {
                $relativeUrl =
                    is_string($value) || $value instanceof \Stringable
                        ? (string) $value
                        : null;
                if (!$relativeUrl) {
                    return '';
                }
                /** @var string $frontendUrl */
                $frontendUrl = config('custom.frontend_url', '');

                return sprintf(
                    '<a href="%s">%s</a>',
                    rtrim($frontendUrl, '/') . $relativeUrl,
                    $relativeUrl
                );
            })->asHtml();
        });
    }
}
