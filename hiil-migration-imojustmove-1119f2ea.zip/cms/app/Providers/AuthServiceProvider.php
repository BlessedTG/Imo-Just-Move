<?php

namespace App\Providers;

use App\Policies\FeedbackPolicy;
use App\Policies\IntakePolicy;
use App\Policies\PagePolicy;
use App\Policies\PermissionPolicy;
use App\Policies\ProblemCategoryPolicy;
use App\Policies\ProblemPolicy;
use App\Policies\QuestionnairePolicy;
use App\Policies\ReferralPolicy;
use App\Policies\RolePolicy;
use App\Policies\TokenPolicy;
use App\Policies\UserPolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array<class-string,class-string>
     */
    protected $policies = [
        \App\Models\Feedback::class => FeedbackPolicy::class,
        \App\Models\Intake::class => IntakePolicy::class,
        \App\Models\Page::class => PagePolicy::class,
        \App\Models\ProblemCategory::class => ProblemCategoryPolicy::class,
        \App\Models\Problem::class => ProblemPolicy::class,
        \App\Models\Questionnaire::class => QuestionnairePolicy::class,
        \App\Models\Referral::class => ReferralPolicy::class,
        \App\Models\User::class => UserPolicy::class,
        \Laravel\Sanctum\PersonalAccessToken::class => TokenPolicy::class,
        \Spatie\Permission\Models\Permission::class => PermissionPolicy::class,
        \Spatie\Permission\Models\Role::class => RolePolicy::class,
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot(): void
    {
        //
    }
}
