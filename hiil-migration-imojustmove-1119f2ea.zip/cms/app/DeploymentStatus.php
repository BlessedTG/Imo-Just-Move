<?php namespace App;

enum DeploymentStatus: string
{
    case PENDING = 'pending';
    case RUNNING = 'running';
    case SUCCESS = 'success';
    case FAILED = 'failed';

    /**
     * Returns the in-progress statuses.
     *
     * @return array<DeploymentStatus>
     */
    public static function inProgress(): array
    {
        return [self::PENDING, self::RUNNING];
    }
}
