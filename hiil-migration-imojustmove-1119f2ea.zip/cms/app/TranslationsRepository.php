<?php namespace App;

use Illuminate\Support\Str;

class TranslationsRepository
{
    public function get(string $locale): Translations
    {
        // Get the translation file for the given locale
        $translationFilePath = lang_path() . "/{$locale}.json";

        // create file if not exists
        if (!file_exists($translationFilePath)) {
            file_put_contents($translationFilePath, '{}');
        }

        $json = file_get_contents($translationFilePath);
        if (!$json) {
            logger()->error("Translation file for locale {$locale} not found");
            return new Translations([]);
        }

        $translations = Translations::fromJson($json);

        return $translations;
    }

    public function save(string $locale, array $translations): void
    {
        $translations = new Translations($translations);
        $translationFilePath = lang_path() . "/{$locale}.json";
        file_put_contents($translationFilePath, $translations->toJson());
    }
}
