<?php namespace App;

class Translations
{
    /** @param array<string, string> $translations */
    public function __construct(protected array $translations) {}

    public static function fromJson(string $data): self
    {
        if (!json_validate($data)) {
            throw new \Exception('Invalid JSON data');
        }
        // Decode the JSON data into an associative array
        /** @var array<string, string> */
        $data = json_decode($data, true);
        return new self($data);
    }

    public function toJson(): string
    {
        return json_encode(
            $this->translations,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE
        ) ?:
            '{}';
    }

    public function toArray(): array
    {
        return $this->translations;
    }
}
