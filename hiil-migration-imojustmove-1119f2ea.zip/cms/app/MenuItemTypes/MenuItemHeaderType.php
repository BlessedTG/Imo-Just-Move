<?php

namespace App\MenuItemTypes;

use Outl1ne\MenuBuilder\MenuItemTypes\BaseMenuItemType;

class MenuItemHeaderType extends BaseMenuItemType
{
    public static function getIdentifier(): string
    {
        return 'header';
    }

    public static function getName(): string
    {
        return 'Header';
    }

    public static function getType(): string
    {
        return 'text';
    }

    /**
     * Get the subtitle value shown in CMS menu items list.
     *
     * @param null|string $value
     * @param null|array $data
     * @param string $locale
     * @return string
     */
    public static function getDisplayValue(
        $value,
        ?array $data,
        $locale
    ): string {
        return self::getName();
    }
}
