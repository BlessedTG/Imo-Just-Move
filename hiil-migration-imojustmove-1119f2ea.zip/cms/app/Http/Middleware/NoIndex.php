<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class NoIndex
{
    /**
     * Add noindex header to response when not in production.
     *
     * @param Request $request
     * @param Closure $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $response = $next($request);
        // This is a CMS server: it never needs to be indexed.
        $response->headers->set('X-Robots-Tag', 'noindex');

        return $response;
    }
}
