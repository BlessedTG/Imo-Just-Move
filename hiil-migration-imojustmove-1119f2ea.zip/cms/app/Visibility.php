<?php namespace App;

use Spatie\TypeScriptTransformer\Attributes\TypeScript;

/**
 * Please define your unique setting keys here.
 * It will make your life a lot easier.
 */
#[TypeScript]
enum Visibility: string
{
    case Public = 'public';
    case Protected = 'protected';
}
