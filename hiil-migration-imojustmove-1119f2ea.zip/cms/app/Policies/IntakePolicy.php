<?php

namespace App\Policies;

use App\Models\Intake;
use App\Permissions;
use App\Models\User;

/**
 * Policy for the Intake model.
 */
class IntakePolicy
{
    public function viewAny(User $user): bool
    {
        // Note: access to individual intakes is filtered in the indexQuery of the Nova resource.
        return $user->can(Permissions::MANAGE_INTAKES) ||
            $user->can(Permissions::MANAGE_OWN_INTAKES);
    }

    public function view(User $user, Intake $intake): bool
    {
        if ($user->can(Permissions::MANAGE_INTAKES)) {
            return true;
        }
        if ($user->can(Permissions::MANAGE_OWN_INTAKES)) {
            return $intake->owner_id === $user->id;
        }
        return false;
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_INTAKES);
    }

    public function update(User $user, Intake $intake): bool
    {
        if ($user->can(Permissions::MANAGE_INTAKES)) {
            return true;
        }
        if ($user->can(Permissions::MANAGE_OWN_INTAKES)) {
            return $intake->owner_id === $user->id;
        }
        return false;
    }

    public function delete(User $user, Intake $intake): bool
    {
        if ($user->can(Permissions::MANAGE_INTAKES)) {
            return true;
        }
        if ($user->can(Permissions::MANAGE_OWN_INTAKES)) {
            return $intake->owner_id === $user->id;
        }
        return false;
    }
}
