<?php namespace App\Policies;

use App\Models\User;
use App\Permissions;

class PermissionPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_ROLES);
    }

    public function view(): bool
    {
        return false;
    }

    public function create(): bool
    {
        return false;
    }

    public function update(): bool
    {
        return false;
    }

    public function delete(): bool
    {
        return false;
    }
}
