<?php

namespace App\Policies;

use App\Permissions;
use App\Models\User;

class ProblemCategoryPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT) ||
            $user->can(Permissions::VIEW_SITE_CONTENT);
    }

    public function view(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT) ||
            $user->can(Permissions::VIEW_SITE_CONTENT);
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT);
    }

    public function update(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT);
    }

    public function delete(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT);
    }
}
