<?php

namespace App\Policies;

use App\Permissions;
use App\Models\User;

class ReferralPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRALS);
    }

    public function view(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRALS);
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRALS);
    }

    public function update(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRALS);
    }

    public function delete(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRALS);
    }
}
