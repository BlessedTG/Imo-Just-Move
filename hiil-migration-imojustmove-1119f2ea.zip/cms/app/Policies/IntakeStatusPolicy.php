<?php

namespace App\Policies;

use App\Models\User;
use App\Permissions;

class IntakeStatusPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_INTAKE_STATUSES);
    }

    public function view(User $user): bool
    {
        return $user->can(Permissions::MANAGE_INTAKE_STATUSES);
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_INTAKE_STATUSES);
    }

    public function update(User $user): bool
    {
        return $user->can(Permissions::MANAGE_INTAKE_STATUSES);
    }

    public function delete(User $user): bool
    {
        return $user->can(Permissions::MANAGE_INTAKE_STATUSES);
    }
}
