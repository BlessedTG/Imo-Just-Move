<?php

namespace App\Policies;

use App\Models\Region;
use App\Models\User;
use App\Permissions;

class RegionPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT) ||
            $user->can(Permissions::VIEW_SITE_CONTENT);
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, Region $region): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT) ||
            $user->can(Permissions::VIEW_SITE_CONTENT);
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT);
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, Region $region): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT);
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, Region $region): bool
    {
        return $user->can(Permissions::MANAGE_SITE_CONTENT);
    }
}
