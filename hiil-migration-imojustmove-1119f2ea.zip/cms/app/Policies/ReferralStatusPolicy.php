<?php

namespace App\Policies;

use App\Models\ReferralStatus;
use App\Models\User;
use App\Permissions;

class ReferralStatusPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, ReferralStatus $referralStatus): bool
    {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, ReferralStatus $referralStatus): bool
    {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, ReferralStatus $referralStatus): bool
    {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, ReferralStatus $referralStatus): bool
    {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(
        User $user,
        ReferralStatus $referralStatus
    ): bool {
        return $user->can(Permissions::MANAGE_REFERRAL_STATUSES);
    }
}
