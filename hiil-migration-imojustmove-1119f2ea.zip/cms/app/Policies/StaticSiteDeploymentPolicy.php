<?php

namespace App\Policies;

use App\Models\StaticSiteDeployment;
use App\Models\User;
use App\Permissions;

class StaticSiteDeploymentPolicy
{
    /**
     * Determine whether the user can view any models.
     */
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::PUBLISH_SITE);
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(
        User $user,
        StaticSiteDeployment $staticSiteDeployment
    ): bool {
        return $user->can(Permissions::PUBLISH_SITE);
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return false;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(
        User $user,
        StaticSiteDeployment $staticSiteDeployment
    ): bool {
        return false;
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(
        User $user,
        StaticSiteDeployment $staticSiteDeployment
    ): bool {
        return false;
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(
        User $user,
        StaticSiteDeployment $staticSiteDeployment
    ): bool {
        return false;
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(
        User $user,
        StaticSiteDeployment $staticSiteDeployment
    ): bool {
        return false;
    }
}
