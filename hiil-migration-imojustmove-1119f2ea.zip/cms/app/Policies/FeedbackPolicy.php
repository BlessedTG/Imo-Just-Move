<?php

namespace App\Policies;

use App\Permissions;
use App\Models\User;

class FeedbackPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_FEEDBACK);
    }

    public function view(User $user): bool
    {
        return $user->can(Permissions::MANAGE_FEEDBACK);
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_FEEDBACK);
    }

    public function update(User $user): bool
    {
        return $user->can(Permissions::MANAGE_FEEDBACK);
    }

    public function delete(User $user): bool
    {
        return $user->can(Permissions::MANAGE_FEEDBACK);
    }
}
