<?php namespace App\Policies;

use App\Permissions;
use App\Roles;
use App\Models\User;
use Reflection;
use ReflectionClass;
use Spatie\Permission\Models\Role;

class RolePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_ROLES);
    }

    public function view(User $user): bool
    {
        return $user->can(Permissions::MANAGE_ROLES);
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_ROLES);
    }

    public function update(User $user): bool
    {
        return $user->can(Permissions::MANAGE_ROLES);
    }

    public function delete(User $user, Role $role): bool
    {
        // Don't delete system required roles
        $systemRoles = (new ReflectionClass(Roles::class))->getConstants();
        if (in_array($role->name, $systemRoles)) {
            return false;
        }

        return $user->can(Permissions::MANAGE_ROLES);
    }
}
