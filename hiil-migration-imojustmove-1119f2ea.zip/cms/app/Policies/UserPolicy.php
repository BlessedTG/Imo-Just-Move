<?php

namespace App\Policies;

use App\Permissions;
use App\Models\User;

class UserPolicy
{
    public function viewAny(User $user): bool
    {
        return $user->can(Permissions::MANAGE_USERS);
    }

    public function view(User $user, User $subject): bool
    {
        return $user->can(Permissions::MANAGE_USERS) ||
            $user->id === $subject->id;
    }

    public function create(User $user): bool
    {
        return $user->can(Permissions::MANAGE_USERS);
    }

    public function update(User $user): bool
    {
        return $user->can(Permissions::MANAGE_USERS);
    }

    public function delete(User $user): bool
    {
        return $user->can(Permissions::MANAGE_USERS);
    }
}
