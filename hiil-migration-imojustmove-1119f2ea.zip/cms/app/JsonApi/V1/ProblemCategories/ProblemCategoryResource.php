<?php

namespace App\JsonApi\V1\ProblemCategories;

use App\FrontendUrl;
use Illuminate\Http\Request;
use LaravelJsonApi\Core\Resources\JsonApiResource;

/**
 * @property \App\Models\ProblemCategory $resource
 */
class ProblemCategoryResource extends JsonApiResource
{
    /**
     * Get the resource's attributes.
     *
     * @param Request|null $request
     * @return iterable
     */
    public function attributes($request): iterable
    {
        return [
            'title' => $this->resource->title,
            'slug' => $this->resource->slug,
            'description' => $this->resource->description,
            'url' => FrontendUrl::fromProblemCategory($this->resource),
            'language' => $this->resource->language,
            'targetAudience' => $this->resource->target_audience,
            'createdAt' => $this->resource->created_at,
            'updatedAt' => $this->resource->updated_at,
            'visibility' => $this->resource->visibility,
            'allowedRole' => $this->resource->allowed_role,
        ];
    }

    /**
     * Get the resource's relationships.
     *
     * @param Request|null $request
     * @return iterable
     */
    public function relationships($request): iterable
    {
        return [$this->relation('problems'), $this->relation('questionnaire')];
    }
}
