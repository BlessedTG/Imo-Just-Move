<?php

namespace App\JsonApi\V1\Problems;

use App\JsonApi\V1\Concerns;
use Illuminate\Http\Request;
use LaravelJsonApi\Core\Resources\JsonApiResource;

class ProblemResource extends JsonApiResource
{
    use Concerns\HasMedia;

    /**
     * The model that the resource represents.
     *
     * @var \App\Models\Problem
     */
    public object $resource;

    /**
     * Get the resource's attributes.
     *
     * @param Request|null $request
     * @return iterable<string,mixed>
     */
    public function attributes($request): iterable
    {
        return reject_null_values([
            'title' => $this->resource->title,
            'description' => $this->resource->description,
            'slug' => $this->resource->slug,
            'url' => $this->resource->url,
            'status' => $this->resource->status,
            'language' => $this->resource->language,
            'targetAudience' => $this->resource->target_audience,
            'createdAt' => $this->resource->created_at,
            'updatedAt' => $this->resource->updated_at,
            'know_your_rights' => $this->resource->know_your_rights,
            'media' => $this->makeMediaCollection(),
            'visibility' => $this->resource->visibility,
            'allowedRole' => $this->resource->allowed_role,
        ]);
    }

    /**
     * Get the resource's relationships.
     *
     * @param Request|null $request
     * @return iterable<\LaravelJsonApi\Core\Resources\Relation>
     */
    public function relationships($request): iterable
    {
        return [$this->relation('outcomes')];
    }
}
