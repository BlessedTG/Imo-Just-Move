<?php

namespace App\JsonApi\V1\MenuItems;

use App\MenuItemTypes\MenuItemHeaderType;
use Grrr\Pages\MenuItemTypes\PageMenuItem;
use Illuminate\Http\Request;
use LaravelJsonApi\Core\Resources\JsonApiResource;
use Outl1ne\MenuBuilder\MenuItemTypes\MenuItemStaticURLType;
use Outl1ne\MenuBuilder\MenuItemTypes\MenuItemTextType;

/**
 * @property string $name
 * @property string $customValue
 * @property string $target
 * @property string $locale
 * @property string $order
 * @property bool $enabled
 * @property string $class
 * @property DateTime $created_at
 * @property DateTime $updated_at
 */
class MenuItemResource extends JsonApiResource
{
    /**
     * Get the resource's attributes.
     *
     * @param Request|null $request
     * @return iterable
     */
    public function attributes($request): iterable
    {
        return [
            'name' => $this->name,
            'value' => $this->customValue,
            'target' => $this->target,
            'locale' => $this->locale,
            'order' => $this->order,
            'enabled' => $this->enabled,
            'type' => $this->getType(),
            'createdAt' => $this->created_at,
            'updatedAt' => $this->updated_at,
        ];
    }

    public function getType(): string
    {
        $typeMap = [
            MenuItemHeaderType::class => 'header',
            MenuItemStaticURLType::class => 'link',
            MenuItemTextType::class => 'text',
            PageMenuItem::class => 'page',
        ];

        return $typeMap[$this->class] ?? $this->class;
    }

    /**
     * Get the resource's relationships.
     *
     * @param Request|null $request
     * @return iterable
     */
    public function relationships($request): iterable
    {
        return [];
    }
}
