<?php

namespace App\JsonApi\V1;

use App\Models\TargetAudience;
use LaravelJsonApi\Core\Server\Server as BaseServer;

class Server extends BaseServer
{
    /**
     * The base URI namespace for this server.
     *
     * @var string
     */
    protected string $baseUri = '/api/v1';

    /**
     * Bootstrap the server when it is handling an HTTP request.
     *
     * @return void
     */
    public function serving(): void
    {
        // no-op
    }

    /**
     * Get the server's list of schemas.
     *
     * @return array
     */
    protected function allSchemas(): array
    {
        return [
            MenuItems\MenuItemSchema::class,
            Menus\MenuSchema::class,
            Pages\PageSchema::class,
            Settings\SettingsSchema::class,
            Problems\ProblemSchema::class,
            ProblemCategories\ProblemCategorySchema::class,
            Outcomes\OutcomeSchema::class,
            Referrals\ReferralSchema::class,
            Feedback\FeedbackSchema::class,
            Questionnaires\QuestionnaireSchema::class,
            Regions\RegionSchema::class,
            TargetAudiences\TargetAudienceSchema::class,
        ];
    }
}
