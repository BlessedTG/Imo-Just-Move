<?php

namespace App\JsonApi\V1\Pages;

use App\JsonApi\V1\Concerns;
use Illuminate\Http\Request;
use LaravelJsonApi\Core\Resources\JsonApiResource;
use Spatie\MediaLibrary\HasMedia;
use Whitecube\NovaFlexibleContent\Layouts\Collection;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class PageResource extends JsonApiResource
{
    use Concerns\HasMedia;
    use Concerns\HasSeoData;

    /**
     * The model that the resource represents.
     *
     * @var \App\Models\Page
     */
    public object $resource;

    /**
     * Get the resource's attributes.
     *
     * @param Request|null $request
     * @return iterable<string,mixed>
     */
    public function attributes($request): iterable
    {
        /** @var Collection<int,Layout<array-key,mixed>> */
        $content = $this->resource->content;

        return reject_null_values([
            'title' => $this->resource->title,
            'slug' => $this->resource->slug,
            'url' => $this->resource->url,
            'status' => $this->resource->status,
            'language' => $this->resource->language,
            'template' => $this->resource->template,
            'content' => $content
                ->map(
                    fn(Layout $item) => [
                        'key' => $item->key(),
                        'layout' => $item->name(),
                        'attributes' => $item->toArray(),
                        'media' =>
                            $item instanceof HasMedia
                                ? $this->collectFlexMedia($item)
                                : [],
                    ]
                )
                ->all(),
            'metadata' => $this->resource->metadata,
            'seo' => $this->makeSeoData(),
            'createdAt' => $this->resource->created_at,
            'updatedAt' => $this->resource->updated_at,
            'media' => $this->makeMediaCollection(),
            'parentId' => $this->resource->parent_id,
        ]);
    }

    /**
     * Get the resource's relationships.
     *
     * @param Request|null $request
     * @return iterable<\LaravelJsonApi\Core\Resources\Relation>
     */
    public function relationships($request): iterable
    {
        return [$this->relation('translations')];
    }
}
