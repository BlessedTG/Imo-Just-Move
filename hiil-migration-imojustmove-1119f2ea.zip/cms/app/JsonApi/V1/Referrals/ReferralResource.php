<?php

namespace App\JsonApi\V1\Referrals;

use Illuminate\Http\Request;
use LaravelJsonApi\Core\Resources\JsonApiResource;

class ReferralResource extends JsonApiResource
{
    /**
     * The model that the resource represents.
     *
     * @var \App\Models\Referral
     */
    public object $resource;

    /**
     * Get the resource's attributes.
     *
     * @param Request|null $request
     * @return iterable<string,mixed>
     */
    public function attributes($request): iterable
    {
        return reject_null_values([
            'name' => $this->resource->name,
            'surname' => $this->resource->surname,
            'email' => $this->resource->email,
            'phone_number' => $this->resource->phone_number,
            'location' => $this->resource->location,
            'expertise' => $this->resource->expertise,
            'role' => $this->resource->role,
            'enrolment_number' => $this->resource->enrolment_number,
            'region' => $this->resource->region,
        ]);
    }

    /**
     * Get the resource's relationships.
     *
     * @param Request|null $request
     * @return iterable<\LaravelJsonApi\Core\Resources\Relation>
     */
    public function relationships($request): iterable
    {
        return [$this->relation('region')];
    }
}
