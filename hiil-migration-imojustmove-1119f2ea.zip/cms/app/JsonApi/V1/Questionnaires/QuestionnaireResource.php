<?php

namespace App\JsonApi\V1\Questionnaires;

use App\JsonApi\V1\Concerns;
use Illuminate\Http\Request;
use LaravelJsonApi\Core\Resources\JsonApiResource;
use Spatie\MediaLibrary\HasMedia;
use Whitecube\NovaFlexibleContent\Layouts\Collection;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class QuestionnaireResource extends JsonApiResource
{
    use Concerns\HasMedia;

    /**
     * The model that the resource represents.
     *
     * @var \App\Models\Questionnaire
     */
    public object $resource;

    /**
     * Get the resource's attributes.
     *
     * @param Request|null $request
     * @return iterable<string,mixed>
     */
    public function attributes($request): iterable
    {
        /** @var Collection<int,Layout<array-key,mixed>> */
        $content = $this->resource->content;

        return reject_null_values([
            'title' => $this->resource->title,
            'slug' => $this->resource->slug,
            'url' => $this->resource->url,
            'language' => $this->resource->language,
            'targetAudience' => $this->resource->target_audience,
            'content' => $content
                ->map(
                    fn(Layout $item) => [
                        'key' => $item->key(),
                        'layout' => $item->name(),
                        'attributes' => $item->toArray(),
                        'media' =>
                            $item instanceof HasMedia
                                ? $this->collectFlexMedia($item)
                                : [],
                    ]
                )
                ->all(),
            'createdAt' => $this->resource->created_at,
            'updatedAt' => $this->resource->updated_at,
            'media' => $this->makeMediaCollection(),
            'visibility' => $this->resource->visibility,
            'allowedRole' => $this->resource->allowed_role,
        ]);
    }

    /**
     * Get the resource's relationships.
     *
     * @param Request|null $request
     * @return iterable<\LaravelJsonApi\Core\Resources\Relation>
     */
    public function relationships($request): iterable
    {
        return [$this->relation('translations')];
    }
}
