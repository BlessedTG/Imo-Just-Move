<?php

namespace App\JsonApi\V1\Concerns;

use Gwd\SeoMeta\Models\SeoMetaItem;
use Illuminate\Support\Facades\Storage;

trait HasSeoData
{
    private function makeSeoData(): array
    {
        $seo = $this->resource->seo_meta ?? new SeoMetaItem();
        if (isset($seo->image)) {
            $seo->image = Storage::url($seo->image);
        }
        return $seo->only(['title', 'description', 'follow_type', 'image']);
    }
}
