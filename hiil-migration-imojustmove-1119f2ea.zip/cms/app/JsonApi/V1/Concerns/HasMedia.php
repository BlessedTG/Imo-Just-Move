<?php

namespace App\JsonApi\V1\Concerns;

use App\Nova\Flexible\Concerns\HasMediaLibrary;
use App\Nova\Flexible\Exceptions\HasMediaException;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

trait HasMedia
{
    /**
     * @return Collection<string, array<string, mixed>>
     */
    private function makeMediaCollection(): Collection
    {
        $flexBlockPattern =
            '/' .
            config('custom.flexible_content.media_suffix_prefix') .
            '([0-9a-zA-Z]{16})$/';
        /**
         * @var Collection<int, Media>
         */
        $media = $this->resource->media;
        return $media
            // Reject anything that looks like it belongs to a flex block.
            ->reject(
                fn(Media $media) => !!preg_match(
                    $flexBlockPattern,
                    $media->collection_name
                )
            )
            ->groupBy('collection_name')
            ->map(fn($collection) => $collection->map('formatMedia'));
    }

    /**
     * @return Collection<string, array<string, mixed>>
     */
    private function collectFlexMedia(
        \Spatie\MediaLibrary\HasMedia $item
    ): Collection {
        if (!in_array(HasMediaLibrary::class, class_uses_recursive($item))) {
            /**
             * @var Layout<array-key,mixed> $item
             */
            throw HasMediaException::missingTrait($item);
        }
        $flexBlockPattern = '/(' . preg_quote($item->getSuffix()) . ')$/';
        /**
         * @var Collection<int, Media>
         */
        $media = $this->resource->media;
        // Collect media from the resource.
        return $media
            // Filter out media using $item->getSuffix().
            ->filter(
                fn(Media $media) => Str::of($media->collection_name)->endsWith(
                    $item->getSuffix()
                )
            )
            ->groupBy('collection_name')
            // Note, we remove the suffix from the resulting collection to have a
            // predictable key in the array.
            ->mapWithKeys(
                fn($collection, $key) => [
                    preg_replace(
                        $flexBlockPattern,
                        '',
                        $key
                    ) => $collection->map('formatMedia'),
                ]
            );
    }
}
