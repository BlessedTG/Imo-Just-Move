<?php

namespace App\Mail;

use App\Models\Intake;
use App\SettingKey;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class IntakeConfirmation extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(
        private Intake $intake,
        private string $language
    ) {}

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        $setting = nova_get_setting(
            SettingKey::IntakeFormConfirmationEmailSubject->value
        );
        $subject = json_decode($setting)?->{$this->language};
        return new Envelope(subject: $subject);
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        $setting = nova_get_setting(
            SettingKey::IntakeFormConfirmationEmailBody->value
        );
        $bodyText = json_decode($setting)?->{$this->language};
        $bodyText = interpolateString($bodyText, $this->intake->toArray());

        return new Content(
            html: 'emails.intake-confirmation-html',
            text: 'emails.intake-confirmation-text',
            with: [
                'bodyText' => $bodyText,
                'bodyTextPlain' => strip_tags($bodyText),
            ]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
