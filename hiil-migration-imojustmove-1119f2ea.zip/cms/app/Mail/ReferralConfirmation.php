<?php

namespace App\Mail;

use App\Models\Referral;
use App\SettingKey;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class ReferralConfirmation extends Mailable implements ShouldQueue
{
    use Queueable, SerializesModels;

    public function __construct(
        private Referral $referral,
        private string $language
    ) {}

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        $setting = nova_get_setting(
            SettingKey::ReferralFormConfirmationEmailSubject->value
        );
        $subject = json_decode($setting)?->{$this->language};
        return new Envelope(subject: $subject);
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        $setting = nova_get_setting(
            SettingKey::ReferralFormConfirmationEmailBody->value
        );
        $bodyText = json_decode($setting)?->{$this->language};
        $bodyText = interpolateString($bodyText, $this->referral->toArray());

        return new Content(
            html: 'emails.referral-confirmation-html',
            text: 'emails.referral-confirmation-text',
            with: [
                'bodyText' => $bodyText,
                'bodyTextPlain' => strip_tags($bodyText),
            ]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
