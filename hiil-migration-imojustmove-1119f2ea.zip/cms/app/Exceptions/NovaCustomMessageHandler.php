<?php

namespace App\Exceptions;

use Illuminate\Database\QueryException;
use Illuminate\Database\UniqueConstraintViolationException;
use Illuminate\Foundation\Exceptions\Handler as ExceptionHandler;
use Illuminate\Validation\ValidationException;
use Symfony\Component\HttpFoundation\Response;

class NovaCustomMessageHandler extends ExceptionHandler
{
    public function render($request, \Throwable $exception)
    {
        if ($exception instanceof QueryException) {
            $errorCode = $exception->errorInfo[1] ?? null;

            // Handle foreign key constraint violation || SQLSTATE[23000]: Integrity constraint violation: 1451 Cannot delete or update a parent row: a foreign key constraint fails
            if ($errorCode === 1451) {
                return response()->json(
                    [
                        'message' => __(
                            'This resource cannot be deleted because it is referenced by other resources in the system.'
                        ),
                    ],
                    Response::HTTP_INTERNAL_SERVER_ERROR
                );
            }
        }

        if ($exception instanceof UniqueConstraintViolationException) {
            return response()->json(
                [
                    'message' => __(
                        'This resource cannot be created because it already exists in the system. Change the slug to make it unique.'
                    ),
                ],
                Response::HTTP_INTERNAL_SERVER_ERROR
            );
        }

        // Send a custom message for missing translations
        if ($exception instanceof ValidationException) {
            // Example message: "The name.ar field is required"
            $message = $exception->getMessage();
            if (
                preg_match(
                    '/The\s(?<field>\w+)\.(?<language>ar|en)\sfield\sis\srequired/',
                    $message,
                    $matches
                )
            ) {
                $field = $matches['field'];
                /** @var string */
                $languageCode = $matches['language'];
                /** @var string */
                $languageName = config(
                    "nova-translatable.locales.$languageCode",
                    $languageCode
                );
                /** @var string */
                $defaultLocale = config('app.default_language');

                return response()->json(
                    [
                        'errors' => [
                            "$field.$languageCode" => [
                                __(
                                    'The :field field is missing the :language translation.',
                                    [
                                        'field' => $field,
                                        'language' => $languageName,
                                    ]
                                ),
                            ],
                            // Note: also showing this error next to the default locale field,
                            // because otherwise it is easily missed.
                            "$field.$defaultLocale" => [
                                __(
                                    'The :field field is missing the :language translation.',
                                    [
                                        'field' => $field,
                                        'language' => $languageName,
                                    ]
                                ),
                            ],
                        ],
                    ],
                    Response::HTTP_UNPROCESSABLE_ENTITY
                );
            }
        }

        // Use parent::render for all other exceptions
        return parent::render($request, $exception);
    }
}
