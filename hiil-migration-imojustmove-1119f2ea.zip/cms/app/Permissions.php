<?php

namespace App;

// TODO: Class name should be singular.
/**
 * Permissions for abilities in the application.
 */
class Permissions
{
    const MANAGE_INTAKES = 'Manage intakes';
    const MANAGE_OWN_INTAKES = 'Manage own intakes';
    const MANAGE_REFERRALS = 'Manage referrals';
    const MANAGE_USERS = 'Manage users';
    const MANAGE_SITE_CONTENT = 'Manage site content';
    const MANAGE_FEEDBACK = 'Manage feedback';
    const MANAGE_ROLES = 'Manage roles';
    const PUBLISH_SITE = 'Publish site';
    const ISSUE_API_TOKENS = 'Issue API tokens';
    const VIEW_SITE_CONTENT = 'View site content';
    const MANAGE_INTAKE_STATUSES = 'Manage intake statuses';
    const MANAGE_REFERRAL_STATUSES = 'Manage referral statuses';

    const ALL = [
        self::MANAGE_INTAKES,
        self::MANAGE_OWN_INTAKES,
        self::MANAGE_REFERRALS,
        self::MANAGE_USERS,
        self::MANAGE_SITE_CONTENT,
        self::MANAGE_FEEDBACK,
        self::MANAGE_ROLES,
        self::PUBLISH_SITE,
        self::ISSUE_API_TOKENS,
        self::VIEW_SITE_CONTENT,
        self::MANAGE_INTAKE_STATUSES,
        self::MANAGE_REFERRAL_STATUSES,
    ];
}
