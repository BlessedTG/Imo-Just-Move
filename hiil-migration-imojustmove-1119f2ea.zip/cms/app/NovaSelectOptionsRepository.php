<?php

namespace App;

use App\Models\Page;
use App\Models\Problem;
use App\Models\ProblemCategory;
use App\Models\Questionnaire;
use App\Models\TargetAudience;
use Illuminate\Support\Str;
use Sereny\NovaPermissions\Models\Role;

final class NovaSelectOptionsRepository
{
    public function __construct(protected Languages $languages) {}

    public function forPages(): array
    {
        return once(function () {
            return Page::query()->pluck('title', 'url')->toArray();
        });
    }

    public function forProblemCategories(string $referenceType = 'url'): array
    {
        return once(function () use ($referenceType) {
            $items = ProblemCategory::query()->with('target_audience')->get();

            $items = $items->mapWithKeys(function (ProblemCategory $item) use (
                $referenceType
            ) {
                return [
                    (string) $item->{$referenceType} => $this->appendTargetAudience(
                        $item->title,
                        $item->target_audience
                    ),
                ];
            });
            return $items->toArray();
        });
    }

    public function forProblems(string $referenceType = 'url'): array
    {
        return once(function () use ($referenceType) {
            $items = Problem::query()->with('target_audience')->get();
            $items = $items->mapWithKeys(function (Problem $item) use (
                $referenceType
            ) {
                return [
                    (string) $item->{$referenceType} => $this->appendTargetAudience(
                        $item->title,
                        $item->target_audience
                    ),
                ];
            });
            return $items->toArray();
        });
    }

    public function forQuestionnaires(string $referenceType = 'url'): array
    {
        return once(function () use ($referenceType) {
            $items = Questionnaire::query()->get();
            $items = $items->mapWithKeys(function (Questionnaire $item) use (
                $referenceType
            ) {
                return [
                    (string) $item->{$referenceType} => $this->appendTargetAudience(
                        $item->title,
                        $item->target_audience
                    ),
                ];
            });
            return $items->toArray();
        });
    }

    public function forPagePreviews(): array
    {
        return once(function () {
            return Page::query()->pluck('title', 'id')->toArray();
        });
    }

    public function forRoles(): array
    {
        return once(function () {
            return collect(Role::all())
                ->mapWithKeys(function ($role) {
                    return [$role->name => $role->name];
                })
                ->toArray();
        });
    }

    protected function appendTargetAudience(
        string $string,
        ?TargetAudience $targetAudience
    ): string {
        if (!$targetAudience) {
            return $string;
        }
        return Str::of($string)
            ->append(' (')
            ->append($targetAudience->name)
            ->append(')')
            ->__toString();
    }
}
