<?php

namespace App\Nova;

use App\NovaSelectOptionsRepository;
use App\Visibility;
use Eminiarts\Tabs\Tab;
use Eminiarts\Tabs\Tabs;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\HasMany;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Slug;
use Laravel\Nova\Http\Requests\NovaRequest;
use Mostafaznv\NovaCkEditor\CkEditor;
use Illuminate\Support\Str;

/**
 * @extends Resource<\App\Models\Problem>
 */
class Problem extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var class-string<\App\Models\Problem>
     */
    public static $model = \App\Models\Problem::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'title';

    public static function label(): string
    {
        return __('Problems');
    }

    public static function singularLabel(): string
    {
        return __('Problem');
    }

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = ['title', 'slug'];

    public function title()
    {
        if (!$this->title) {
            return '';
        }
        /**
         * @var \App\Models\TargetAudience|null $targetAudience
         */
        $targetAudience = $this->target_audience;
        if (!$targetAudience) {
            return $this->title;
        }
        return Str::of($this->title)
            ->append(' (')
            ->append($targetAudience->name)
            ->append(')')
            ->__toString();
    }
    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        $fields = [
            Tabs::make($this->title(), [
                Tab::make(
                    __('pages::pages.panels.basic'),
                    $this->basicFields()
                ),
                Tab::make(
                    __('pages::pages.panels.content'),
                    $this->contentFields()
                ),
            ])->withToolbar(),
        ];
        return $fields;
    }

    protected function basicFields(): array
    {
        $selectOptionsRepository = resolve(NovaSelectOptionsRepository::class);
        return [
            ID::make()->sortable(),
            Text::make(__('Title'), 'title')
                ->rules('required', 'max:255')
                ->sortable(),
            Text::make(__('URL'), 'url')
                ->displayAsFrontendLink()
                ->readonly()
                ->hideFromIndex(),
            Slug::make(__('Slug'), 'slug')
                ->from('title')
                ->rules('required', 'max:255')
                ->sortable(),
            targetAudienceField(__('Target audience'), 'target_audience'),
            Select::make(__('Language'), 'language')
                ->options([
                    'en' => __('English'),
                    'ar' => __('Arabic'),
                ])
                ->rules('required'),
            BelongsTo::make(
                __('Problem category'),
                'category',
                ProblemCategory::class
            )->rules('required'),
            HasMany::make(__('Outcomes'), 'outcomes', Outcome::class),
            DateTime::make(__('Created at'), 'created_at')->onlyOnIndex(),
            Select::make(__('Visibility'), 'visibility')
                ->options([
                    Visibility::Public->value => __('Public'),
                    Visibility::Protected->value => __('Protected'),
                ])
                ->default('public')
                ->help(
                    __(
                        'Select the visibility of the page. Public pages are visible to everyone, protected pages are only visible to cms users'
                    )
                )
                ->displayUsingLabels(),
            Select::make(__('Allowed role'), 'allowed_role')
                ->options($selectOptionsRepository->forRoles())
                ->help(
                    __(
                        'Select the role that is allowed to see the protected page. If no role is selected, any role is allowed to see the content'
                    )
                )
                ->nullable(),
        ];
    }

    protected function contentFields(): array
    {
        return [
            Text::make(__('Description'), 'description')->rules(
                'required',
                'max:255'
            ),
            CkEditor::make(__('Know your rights'), 'know_your_rights')
                ->rules('required')
                ->contentLanguage($this->language ?? app()->getLocale()),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }
}
