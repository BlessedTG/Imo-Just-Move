<?php

namespace App\Nova;

use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Slug;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Http\Requests\NovaRequest;

/**
 * @extends Resource<\App\Models\TargetAudience>
 */
class TargetAudience extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var class-string<\App\Models\TargetAudience>
     */
    public static $model = \App\Models\TargetAudience::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'name';

    public static function label(): string
    {
        return __('Target audiences');
    }

    public static function singularLabel(): string
    {
        return __('Target audience');
    }

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = ['id'];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        /** @var NovaSelectOptionsRepository $optionsRepository */
        $optionsRepository = resolve(NovaSelectOptionsRepository::class);

        return [
            ID::make()->sortable(),
            Text::make(__('Name'), 'name')
                ->required()
                ->rules('required')
                ->translatable(),
            Slug::make(__('Slug'), 'slug')
                ->from('name')
                ->required()
                ->hideWhenCreating()
                ->translatable()
                ->sortable(),
            Boolean::make(__('Is default'), 'is_default')->help(
                __(
                    'Resources that are linked to the default target audience will not have the slug of the target audience in their URL.'
                )
            ),
            Select::make('Home URL', 'home_url')
                ->translatable()
                ->options($optionsRepository->forPages())
                ->nullable(),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }
}
