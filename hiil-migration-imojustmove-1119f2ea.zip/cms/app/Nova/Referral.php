<?php

namespace App\Nova;

use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\BelongsToMany;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Http\Requests\NovaRequest;

/**
 * @extends Resource<\App\Models\Referral>
 */
class Referral extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var class-string<\App\Models\Referral>
     */
    public static $model = \App\Models\Referral::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'name';

    public static function label(): string
    {
        return __('Referrals');
    }

    public static function singularLabel(): string
    {
        return __('Referral');
    }

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = ['name', 'surname', 'enrolment_number'];

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make()->sortable(),
            BelongsTo::make(
                __('Status'),
                'referralStatus',
                ReferralStatus::class
            )
                ->required()
                ->rules('required')
                ->filterable()
                ->withMeta([
                    'belongsToId' => $this->referral_status_id ?? 1, // Set default status if not set already
                ]),
            Select::make(__('Publication status'), 'status')
                ->options([
                    \App\Models\Referral::STATUS_DRAFT => __('Draft'),
                    \App\Models\Referral::STATUS_PUBLISHED => __('Published'),
                ])
                ->required()
                ->filterable()
                ->rules('required')
                ->default(\App\Models\Referral::STATUS_DRAFT),
            Text::make(__('Name'), 'name')
                ->sortable()
                ->required()
                ->rules('required', 'max:255'),

            Text::make(__('Surname'), 'surname')
                ->sortable()
                ->required()
                ->rules('required', 'max:255'),

            Text::make(__('Email'), 'email')
                ->rules('nullable', 'email', 'max:255')
                ->hideFromIndex(),

            Text::make(__('Phone number'), 'phone_number')
                ->hideFromIndex()
                ->required()
                ->rules('required'),

            Text::make(__('Location'), 'location')
                ->hideFromIndex()
                ->rules('required', 'max:255'),

            Text::make(__('Expertise'), 'expertise')
                ->hideFromIndex()
                ->required()
                ->rules('required', 'max:255'),

            Text::make(__('Role'), 'role')->rules('required', 'max:255'),

            Text::make(__('Enrolment number'), 'enrolment_number'),

            Textarea::make(__('Additional message'), 'additional_message')
                ->alwaysShow()
                ->rules('nullable'),

            BelongsToMany::make(__('Outcomes'), 'outcomes', Outcome::class),
            BelongsTo::make(__('Region'), 'region', Region::class)->nullable(),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }
}
