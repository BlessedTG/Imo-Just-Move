<?php

namespace App\Nova\Settings;

use App\NovaSelectOptionsRepository;
use App\SettingKey;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Heading;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Panel;
use Laravel\Nova\Fields\Text;
use Mostafaznv\NovaCkEditor\CkEditor;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

final class GeneralFields
{
    public static function all(): array
    {
        $selectOptionsRepository = resolve(NovaSelectOptionsRepository::class);
        return [
            LocaleSelect::make(null),
            Heading::make(
                __('Here you edit text for the general UI of the application')
            ),
            Panel::make(__('General'), [
                Text::make(
                    __('Back button label'),
                    SettingKey::BackButtonLabel->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Share this page'), [
                Text::make(
                    __('Email share subject'),
                    SettingKey::EmailShareSubject->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Problems'), [
                Text::make(
                    __('Desired outcomes title'),
                    SettingKey::ProblemDesiredOutcomesTitle->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Desired outcomes description'),
                    SettingKey::ProblemDesiredOutcomesDescription->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Know your rights title'),
                    SettingKey::ProblemKnowYourRightsTitle->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('To outcome page button label'),
                    SettingKey::ToOutcomePageLabel->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Problem category description'),
                    SettingKey::ProblemCategoryDescription->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Problem category help button label'),
                    SettingKey::ProblemCategoryHelpButtonLabel->value
                )
                    ->required()
                    ->translatable(),
            ]),
            Panel::make(__('Step titles'), [
                Text::make(
                    __('First step title'),
                    SettingKey::FirstStepLabel->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    'Second step title',
                    SettingKey::SecondStepLabel->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Third step title'),
                    SettingKey::ThirdStepLabel->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Fourth step title'),
                    SettingKey::FourthStepLabel->value
                )
                    ->required()
                    ->translatable(),
            ]),

            Panel::make(__('Outcomes'), [
                Text::make(__('Outcome title'), SettingKey::OutcomeTitle->value)
                    ->required()
                    ->translatable(),
            ]),
            Panel::make(__('Outcomes'), [
                Text::make(
                    __('Outcome help title'),
                    SettingKey::OutcomeHelpTitle->value
                )
                    ->required()
                    ->translatable(),
            ]),

            Panel::make(__('Referral filter'), [
                Text::make(
                    __('Referral filter label'),
                    SettingKey::ReferralFilterLabel->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Referral filter "all" option'),
                    SettingKey::ReferralFilterAllOption->value
                )
                    ->required()
                    ->translatable(),
            ]),

            Panel::make(__('Notification overlay content'), [
                Text::make(
                    __('Title'),
                    SettingKey::NotificationOverlayTitle->value
                )
                    ->required()
                    ->translatable(),
                CkEditor::make(
                    __('Description'),
                    SettingKey::NotificationOverlayDescription->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Change profile button label'),
                    SettingKey::NotificationOverlayChangeButtonLabel->value
                )
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Resume viewing the page label'),
                    SettingKey::NotificationOverlayResumeButtonLabel->value
                )
                    ->required()
                    ->translatable(),
            ]),

            Panel::make(__('Emergency overlay content'), [
                Text::make(
                    __('Title'),
                    SettingKey::EmergencyOverlayTitle->value
                )
                    ->nullable()
                    ->translatable(),
                CkEditor::make(
                    __('Description'),
                    SettingKey::EmergencyOverlayDescription->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Link label'),
                    SettingKey::EmergencyOverlayLinkLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Phone number'),
                    SettingKey::EmergencyOverlayPhoneNumber->value
                )
                    ->help(__('Enter the emergency contact phone number.'))
                    ->nullable()
                    ->translatable(),
            ]),

            Panel::make(__('Request support form overlay content'), [
                Text::make(
                    __('Form title'),
                    SettingKey::RequestSupportFormTitle->value
                )
                    ->nullable()
                    ->translatable(),
                CkEditor::make(
                    __('Form description'),
                    SettingKey::RequestSupportFormDescription->value
                )
                    ->nullable()
                    ->translatable(),
            ]),

            Panel::make(__('Close questionnaire overlay content'), [
                Text::make(
                    __('Title'),
                    SettingKey::CloseQuestionnaireOverlayTitle->value
                )
                    ->nullable()
                    ->translatable(),
                CkEditor::make(
                    __('Description'),
                    SettingKey::CloseQuestionnaireOverlayDescription->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Link label'),
                    SettingKey::CloseQuestionnaireOverlayLinkLabel->value
                )
                    ->nullable()
                    ->translatable(),
            ]),

            Panel::make(__('Referral form overlay content'), [
                Text::make(
                    __('Form title'),
                    SettingKey::ReferralFormTitle->value
                )
                    ->nullable()
                    ->translatable(),
                CkEditor::make(
                    __('Form description'),
                    SettingKey::ReferralFormDescription->value
                )
                    ->nullable()
                    ->translatable(),
            ]),

            Panel::make(__('Questionnaire'), [
                Text::make(
                    __('Restart button label'),
                    SettingKey::QuestionnaireRestartButtonLabel->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Results title'),
                    SettingKey::QuestionnaireResultsTitle->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Outcome button label'),
                    SettingKey::QuestionnaireOutcomeButtonLabel->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Analysis title'),
                    SettingKey::QuestionnaireAnalysisTitle->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Analysis result subtitle'),
                    SettingKey::QuestionnaireResultSubtitle->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('No result title'),
                    SettingKey::QuestionnaireNoResultTitle->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Request assistance button label'),
                    SettingKey::QuestionnaireRequestAssistanceButtonLabel->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Select::make(
                    __('FAQ page link'),
                    SettingKey::QuestionnaireFAQPageLink->value
                )
                    ->options($selectOptionsRepository->forPages())
                    ->translatable()
                    ->nullable(),
                Text::make(
                    __('FAQ page link label'),
                    SettingKey::QuestionnaireFAQPageLinkLabel->value
                )
                    ->translatable()
                    ->nullable(),
            ]),

            Panel::make(__('Footer'), [
                Boolean::make(
                    __('Show Hiil logo'),
                    SettingKey::ShowHiilLogo->value
                )
                    ->trueValue('true')
                    ->falseValue('false'),
                Text::make(
                    __('Hiil footer link'),
                    SettingKey::FooterHiilLink->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Footer credit text'),
                    SettingKey::FooterCreditText->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
        ];
    }
}
