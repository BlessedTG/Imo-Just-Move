<?php namespace App\Nova\Settings;

use App\SettingKey;
use Laravel\Nova\Panel;
use Laravel\Nova\Fields\Text;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

class CookiebannerFields
{
    public static function all(): array
    {
        return [
            LocaleSelect::make(null),

            Panel::make(__('Cookiebanner'), [
                Text::make(
                    __('Cookiebanner title'),
                    SettingKey::CookieBannerTitle->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Cookiebanner introduction'),
                    SettingKey::CookieBannerIntroduction->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Functional cookies name'),
                    SettingKey::CookieBannerFunctionalCookiesName->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Functional cookies description'),
                    SettingKey::CookieBannerFunctionalCookiesDescription->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Marketing cookies name'),
                    SettingKey::CookieBannerMarketingCookiesName->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Marketing cookies description'),
                    SettingKey::CookieBannerMarketingCookiesDescription->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Save preferences button label'),
                    SettingKey::CookieBannerSavePreferencesLabel->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Accept all button label'),
                    SettingKey::CookieBannerAcceptAllLabel->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Change consent link label'),
                    SettingKey::CookieBannerChangeConsentLinkLabel->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
                Text::make(
                    __('Marketing cookies required message'),
                    SettingKey::CookieBannerMarketingCookiesRequiredMessage
                        ->value
                )
                    ->nullable()
                    ->required()
                    ->translatable(),
            ]),
        ];
    }
}
