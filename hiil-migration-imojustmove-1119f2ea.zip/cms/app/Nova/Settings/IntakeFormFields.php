<?php

namespace App\Nova\Settings;

use App\SettingKey;
use Laravel\Nova\Panel;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Mostafaznv\NovaCkEditor\CkEditor;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

final class IntakeFormFields
{
    public static function all(): array
    {
        return [
            LocaleSelect::make(null),
            Panel::make(__('Content'), [
                Text::make(__('Title'), SettingKey::IntakeFormTitle->value)
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Description'),
                    SettingKey::IntakeFormDescription->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Title (request support)'),
                    SettingKey::RequestSupportFormTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Description (request support)'),
                    SettingKey::RequestSupportFormDescription->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Form response'), [
                Text::make(
                    __('Title of success message'),
                    SettingKey::IntakeFormSuccessTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Content of success message'),
                    SettingKey::IntakeFormSuccessMessage->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Title of error message'),
                    SettingKey::IntakeFormErrorTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Content of error message'),
                    SettingKey::IntakeFormErrorMessage->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Inputs'), [
                Text::make(
                    __('Name label'),
                    SettingKey::IntakeFormNameLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Name instruction'),
                    SettingKey::IntakeFormNameInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Surname label'),
                    SettingKey::IntakeFormSurnameLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Surname instruction'),
                    SettingKey::IntakeFormSurnameInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    'Phone label',
                    SettingKey::IntakeFormPhoneNumberLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Phone instruction'),
                    SettingKey::IntakeFormPhoneNumberInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Email label'),
                    SettingKey::IntakeFormEmailLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Email instruction'),
                    SettingKey::IntakeFormEmailInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Location label'),
                    SettingKey::IntakeFormLocationLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Location instruction'),
                    SettingKey::IntakeFormLocationInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Additional message label'),
                    SettingKey::IntakeFormAdditionalMessageLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Additional message instruction'),
                    SettingKey::IntakeFormAdditionalMessageInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Submit button label'),
                    SettingKey::IntakeFormSubmitButtonLabel->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Confirmation email'), [
                Text::make(
                    __('Subject'),
                    SettingKey::IntakeFormConfirmationEmailSubject->value
                )
                    ->nullable()
                    ->translatable(),

                CkEditor::make(
                    __('Body'),
                    SettingKey::IntakeFormConfirmationEmailBody->value
                )
                    ->help(
                        __(
                            'Available variables: {reference_id} {name}, {surname}, {phone_number}, {email}, {location}, {problem}, {outcome}, {additional_message}'
                        )
                    )
                    ->nullable()
                    ->translatable(),
            ]),
        ];
    }
}
