<?php

namespace App\Nova\Settings;

use App\SettingKey;
use Laravel\Nova\Panel;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

final class FeedbackFormFields
{
    public static function all(): array
    {
        return [
            LocaleSelect::make(null),
            Panel::make(__('Content'), [
                Text::make(__('Title'), SettingKey::FeedbackFormTitle->value)
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Description'),
                    SettingKey::FeedbackFormDescription->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Form response'), [
                Text::make(
                    __('Title of success message'),
                    SettingKey::FeedbackFormSuccessTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Content of success message'),
                    SettingKey::FeedbackFormSuccessMessage->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Title of error message'),
                    SettingKey::FeedbackFormErrorTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Content of error message'),
                    SettingKey::FeedbackFormErrorMessage->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make('Inputs', [
                Text::make(
                    __('Negative label'),
                    SettingKey::FeedbackFormNegativeLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Positive label'),
                    SettingKey::FeedbackFormPositiveLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Message label'),
                    SettingKey::FeedbackFormMessageLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Message instruction'),
                    SettingKey::FeedbackFormMessageInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Submit button label'),
                    SettingKey::FeedbackFormSubmitButtonLabel->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
        ];
    }
}
