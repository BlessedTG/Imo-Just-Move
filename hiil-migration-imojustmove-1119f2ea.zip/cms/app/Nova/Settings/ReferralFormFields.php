<?php

namespace App\Nova\Settings;

use App\SettingKey;
use Laravel\Nova\Panel;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Mostafaznv\NovaCkEditor\CkEditor;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

final class ReferralFormFields
{
    public static function all(): array
    {
        return [
            LocaleSelect::make(null),
            Panel::make(__('Form response'), [
                Text::make(
                    __('Title of success message'),
                    SettingKey::ReferralFormSuccessTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Content of success message'),
                    SettingKey::ReferralFormSuccessMessage->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Title of error message'),
                    SettingKey::ReferralFormErrorTitle->value
                )
                    ->nullable()
                    ->translatable(),
                Textarea::make(
                    __('Content of error message'),
                    SettingKey::ReferralFormErrorMessage->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('General form overlay content'), [
                Text::make(
                    __('Name label'),
                    SettingKey::ReferralFormNameLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Name instruction'),
                    SettingKey::ReferralFormNameInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Surname label'),
                    SettingKey::ReferralFormSurnameLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Surname instruction'),
                    SettingKey::ReferralFormSurnameInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Phone label'),
                    SettingKey::ReferralFormPhoneNumberLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Phone instruction'),
                    SettingKey::ReferralFormPhoneNumberInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Email label'),
                    SettingKey::ReferralFormEmailLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Email instruction'),
                    SettingKey::ReferralFormEmailInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Location label'),
                    SettingKey::ReferralFormLocationLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Location instruction'),
                    SettingKey::ReferralFormLocationInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Expertise label'),
                    SettingKey::ReferralFormExpertiseLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Expertise instruction'),
                    SettingKey::ReferralFormExpertiseInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Role label'),
                    SettingKey::ReferralFormRoleLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Role instruction'),
                    SettingKey::ReferralFormRoleInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Enrolment label'),
                    SettingKey::ReferralFormEnrolmentNumberLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Enrolment instruction'),
                    SettingKey::ReferralFormEnrolmentNumberInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Additional message label'),
                    SettingKey::ReferralFormAdditionalMessageLabel->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Additional message instruction'),
                    SettingKey::ReferralFormAdditionalMessageInstruction->value
                )
                    ->nullable()
                    ->translatable(),
                Text::make(
                    __('Submit button label'),
                    SettingKey::ReferralFormSubmitButtonLabel->value
                )
                    ->nullable()
                    ->translatable(),
            ]),
            Panel::make(__('Confirmation email'), [
                Text::make(
                    __('Subject'),
                    SettingKey::ReferralFormConfirmationEmailSubject->value
                )
                    ->nullable()
                    ->translatable(),

                CkEditor::make(
                    __('Body'),
                    SettingKey::ReferralFormConfirmationEmailBody->value
                )
                    ->help(
                        __(
                            'Available variables: {reference_id} {name}, {surname}, {phone_number}, {email}, {location}, {problem}, {outcome}, {additional_message}'
                        )
                    )
                    ->nullable()
                    ->translatable(),
            ]),
        ];
    }
}
