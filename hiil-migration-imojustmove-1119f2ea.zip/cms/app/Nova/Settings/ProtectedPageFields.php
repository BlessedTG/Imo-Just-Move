<?php namespace App\Nova\Settings;

use App\SettingKey;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Panel;
use Mostafaznv\NovaCkEditor\CkEditor;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

class ProtectedPageFields
{
    public static function all(): array
    {
        return [
            LocaleSelect::make(null),
            Panel::make(__('Protected pages'), [
                CkEditor::make(
                    __('Not authorized message'),
                    SettingKey::ProtectedPageNotAuthorizedMessage->value
                )
                    ->translatable()
                    ->help(
                        __(
                            'Message shown when user is not authorized to view a page'
                        )
                    ),
                Text::make(
                    __('Home button text'),
                    SettingKey::ProtectedPageHomeButtonText->value
                )->translatable(),
            ]),
        ];
    }
}
