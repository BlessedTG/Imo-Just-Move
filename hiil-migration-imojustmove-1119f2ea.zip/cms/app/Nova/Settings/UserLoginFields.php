<?php namespace App\Nova\Settings;

use App\SettingKey;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Panel;
use Outl1ne\NovaTranslatable\Fields\LocaleSelect;

class UserLoginFields
{
    public static function all(): array
    {
        return [
            LocaleSelect::make(null),
            Panel::make(__('User login'), [
                Text::make(
                    __('Login overlay title'),
                    SettingKey::LoginOverlayTitle->value
                )->translatable(),
                Text::make(
                    __('Login button label'),
                    SettingKey::LoginButtonLabel->value
                )->translatable(),
                Text::make(
                    __('Logged in as'),
                    SettingKey::LoggedInAs->value
                )->translatable(),
                Text::make(
                    __('Not logged in label'),
                    SettingKey::NotLoggedIn->value
                )->translatable(),
                Text::make(
                    __('Login suspense message'),
                    SettingKey::LoginSuspenseMessage->value
                )
                    ->translatable()
                    ->help(__('Message shown while authenticating user')),
                Text::make(
                    __('Logout button label'),
                    SettingKey::LogoutButtonLabel->value
                )->translatable(),
                Text::make(
                    __('Logging out message'),
                    SettingKey::LoggingOutMessage->value
                )
                    ->translatable()
                    ->help(__('Message shown while logging out user')),
            ]),
        ];
    }
}
