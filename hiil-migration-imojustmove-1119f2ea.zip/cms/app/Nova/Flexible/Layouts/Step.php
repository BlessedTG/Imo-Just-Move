<?php

namespace App\Nova\Flexible\Layouts;

use App\Nova\Flexible\Concerns\HasMediaLibrary;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images as ImageField;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Spatie\MediaLibrary\HasMedia;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class Step extends Layout implements HasMedia
{
    use HasMediaLibrary;

    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'step';

    /**
     * The displayed title
     *
     * @var string
     */
    protected $title = 'Step';

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            Textarea::make(__('Text'), 'text')
                ->rules(['required'])
                ->fullWidth(),
            ImageField::make(__('Image'), 'image')
                ->customPropertiesFields([Text::make(__('Alt-text'), 'alt')])
                ->enableExistingMedia(),
        ];
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('image')->singleFile();
    }
}
