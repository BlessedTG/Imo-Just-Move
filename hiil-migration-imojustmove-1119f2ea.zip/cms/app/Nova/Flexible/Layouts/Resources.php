<?php

namespace App\Nova\Flexible\Layouts;

use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Text;
use Outl1ne\MultiselectField\Multiselect;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class Resources extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'resources';

    public function title(): string
    {
        return __('Resources');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        /** @var NovaSelectOptionsRepository $optionRepository */
        $optionRepository = resolve(NovaSelectOptionsRepository::class);

        return [
            Text::make(__('Title'), 'title')->rules(['required']),
            Multiselect::make(__('Page previews'), 'page_previews')
                ->options($optionRepository->forPagePreviews())
                ->saveAsJSON()
                ->reorderable()
                ->rules(['required']),
        ];
    }
}
