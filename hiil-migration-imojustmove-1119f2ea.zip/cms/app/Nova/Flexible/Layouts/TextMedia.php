<?php

namespace App\Nova\Flexible\Layouts;

use App\Nova\Flexible\Concerns\HasMediaLibrary;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images as ImageField;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Spatie\MediaLibrary\HasMedia;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class TextMedia extends Layout implements HasMedia
{
    use HasMediaLibrary;

    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'text_media';

    public function title(): string
    {
        return __('Text - Media');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            ImageField::make(__('Image'), 'image')
                ->customPropertiesFields([Text::make(__('Alt-text'), 'alt')])
                ->enableExistingMedia(),
            Text::make(__('Title'), 'title')
                ->required()
                ->rules(['required']),
            Textarea::make(__('Text'), 'text')
                ->required()
                ->rules(['required']),
            Text::make(__('VideoID'), 'videoID')->help(
                __(
                    'Add the VideoID from the YouTube URL. Example: https://www.youtube.com/watch?v=<strong>VideoID</strong>. Adding a video will overwrite the image.'
                )
            ),
            Flexible::make(__('Link'), 'link')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1),
        ];
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('image')->singleFile();
    }
}
