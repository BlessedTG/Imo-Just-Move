<?php

namespace App\Nova\Flexible\Layouts;

use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Whitecube\NovaFlexibleContent\Layouts\Collection as LayoutCollection;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class WhatToExpect extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'what_to_expect';

    public function title(): string
    {
        return __('What to expect');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            Flexible::make(__('Steps'), 'steps')
                ->addLayout(Step::class)
                ->button(__('Add step'))
                ->limit(4)
                ->rules(['required'])
                ->fullWidth(),
            Flexible::make(__('Return link'), 'return_link')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1)
                ->rules(['required'])
                ->fullWidth(),
            Flexible::make(__('Continue link'), 'continue_link')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1)
                ->rules(['required'])
                ->fullWidth(),
        ];
    }

    /**
     * Map nested Flexible layouts to array as well.
     * And add inject media data
     *
     * @return array<mixed>
     */
    public function toArray()
    {
        return array_merge($this->attributesToArray(), [
            'steps' => $this->getStepsAttribute()
                ->map(function (Step $item) {
                    /**
                     * @var Media|null $image
                     */
                    $image = $item->getMedia('image')->first();
                    if (!$image) {
                        return [
                            'layout' => $item->name(),
                            'attributes' => $item->toArray(),
                        ];
                    }
                    return [
                        'layout' => $item->name(),
                        'attributes' => array_merge($item->toArray(), [
                            'image' => formatMedia($image),
                        ]),
                    ];
                })
                ->toArray(),
        ]);
    }

    /**
     * Ensure the nested Flexible layouts are casted appropriately.
     *
     * @return LayoutCollection<int, Step>
     */
    public function getStepsAttribute()
    {
        /**
         * Make sure every layout will have the right model.
         * This must match whatever is stored in the media table, but will by
         * default return the parent layout.
         */
        $out = $this->flexible('steps', [
            'step' => Step::class,
        ]);
        if ($out instanceof LayoutCollection) {
            $out->each->setModel($this->model);
        }
        return $out;
    }
}
