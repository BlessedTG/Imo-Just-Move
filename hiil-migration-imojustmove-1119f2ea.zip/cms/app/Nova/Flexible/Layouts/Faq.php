<?php

namespace App\Nova\Flexible\Layouts;

use Mostafaznv\NovaCkEditor\CkEditor;
use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class Faq extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'faq';

    public function title(): string
    {
        return __('FAQ');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            Text::make(__('Title'), 'title')->rules(['required']),
            Flexible::make(__('FAQs'), 'faqs')
                ->button(__('New FAQ'))
                ->addLayout('Faq', 'faq', [
                    Text::make(__('Question'), 'question')->rules(['required']),
                    Text::make(__('Subtitle'), 'subtitle'),
                    CkEditor::make(__('Answer'), 'answer')
                        ->rules(['required'])
                        ->contentLanguage(app()->getLocale()),
                ])
                ->fullWidth(),
            Flexible::make(__('Link'), 'link')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1)
                ->fullWidth(),
        ];
    }
}
