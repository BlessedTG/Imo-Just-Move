<?php

namespace App\Nova\Flexible\Layouts;

use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class Answer extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'answer';

    public function title(): string
    {
        return __('Answer');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        /** @var NovaSelectOptionsRepository $optionRepository */
        $optionRepository = resolve(NovaSelectOptionsRepository::class);

        /** @var \App\Models\Page|\App\Models\Questionnaire $model */
        $model = $this->model;

        return [
            Text::make(__('Label'), 'label')->rules(['required']),
            Select::make(__('Problem'), 'problem')
                ->help(__('Select the problem that this answer solves'))
                ->options($optionRepository->forProblems('id'))
                ->searchable()
                ->nullable(),
        ];
    }
}
