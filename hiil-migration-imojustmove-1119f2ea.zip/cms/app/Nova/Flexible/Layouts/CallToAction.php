<?php

namespace App\Nova\Flexible\Layouts;

use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class CallToAction extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'call_to_action';

    public function title(): string
    {
        return __('Call to action');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            Text::make(__('Title'), 'title')->rules(['required']),
            Textarea::make(__('Text'), 'text')->help(
                __('Try to keep the text under :amount characters.', [
                    'amount' => 120,
                ])
            ),
            Flexible::make(__('Links'), 'links')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1)
                ->rules(['required']),
        ];
    }
}
