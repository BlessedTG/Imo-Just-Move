<?php

namespace App\Nova\Flexible\Layouts;

use Alexwenzel\DependencyContainer\HasDependencies;
use App\Nova\Fields\NovaDependencyContainer;
use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class Link extends Layout
{
    use HasDependencies;

    /*
     * Get a cloned instance with set values
     * Because there is a issue with the Nova Dependency Container in Flexible Content
     * https://github.com/epartment/nova-dependency-container/issues/102
     *
     * @param  string  $key
     * @param  array  $attributes
     * @return \Whitecube\NovaFlexibleContent\Layouts\Layout
     */
    public function duplicateAndHydrate($key, array $attributes = [])
    {
        return new static($this->title(), $this->name, null, $key, $attributes);
    }

    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'link';

    public function title(): string
    {
        return __('Link');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        /** @var NovaSelectOptionsRepository $optionRepository */
        $optionRepository = resolve(NovaSelectOptionsRepository::class);

        return [
            // Define the layout's fields.
            Text::make(__('Label'), 'label')->rules(['required']),

            Select::make(__('URL type'), 'urlType', function ($value) {
                return $value ?: 'pageUrl';
            })
                ->options([
                    'pageUrl' => __('Page URL'),
                    'problemUrl' => __('Problem URL'),
                    'questionnaireUrl' => __('Questionnaire URL'),
                    'external' => __('External'),
                ])
                ->hideFromDetail()
                ->rules(['required']),

            NovaDependencyContainer::make([
                Select::make(__('Page'), 'url')
                    ->options($optionRepository->forPages()) // this will save a relative url (relative to root, link '/nl/info')
                    ->rules(['required']),
            ])->dependsOn('urlType', 'pageUrl'),

            NovaDependencyContainer::make([
                Select::make(__('Problem'), 'problemUrl')
                    ->options($optionRepository->forProblems())
                    ->rules(['required']),
            ])->dependsOn('urlType', 'problemUrl'),

            NovaDependencyContainer::make([
                Select::make(__('Questionnaire'), 'questionnaireUrl')
                    ->options($optionRepository->forQuestionnaires())
                    ->rules(['required']),
            ])->dependsOn('urlType', 'questionnaireUrl'),

            NovaDependencyContainer::make([
                Text::make(__('URL'), 'externalUrl')
                    ->rules(['required', 'url'])
                    ->help(
                        __(
                            'Use the full URL, including the protocol (https://)'
                        )
                    ),
            ])->dependsOn('urlType', 'external'),

            Boolean::make(__('Open link in new tab'), 'targetBlank'),
        ];
    }
}
