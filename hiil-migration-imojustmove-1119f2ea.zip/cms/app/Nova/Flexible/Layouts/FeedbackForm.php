<?php

namespace App\Nova\Flexible\Layouts;

use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Text;
use Mostafaznv\NovaCkEditor\CkEditor;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class FeedbackForm extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'feedback_form';

    public function title(): string
    {
        return __('Feedback form');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        /** @var NovaSelectOptionsRepository $optionRepository */
        $optionRepository = resolve(NovaSelectOptionsRepository::class);

        return [
            Text::make(__('Title'), 'title')->rules(['required']),
            CkEditor::make(__('Description text'), 'text')
                ->rules(['required'])
                ->contentLanguage(app()->getLocale()),
        ];
    }
}
