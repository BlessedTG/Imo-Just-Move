<?php

namespace App\Nova\Flexible\Layouts;

use App\Nova\Flexible\Concerns\HasMediaLibrary;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images as ImageField;
use Laravel\Nova\Fields\Text;
use Spatie\MediaLibrary\HasMedia;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class Images extends Layout implements HasMedia
{
    use HasMediaLibrary;

    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'images';

    public function title(): string
    {
        return __('Images');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            ImageField::make(__('Image :number', ['number' => 1]), 'image1')
                ->enableExistingMedia()
                ->rules(['required'])
                ->required()
                ->customPropertiesFields([Text::make('Alt-text', 'alt')]),
            Text::make(__('Image description'), 'figcaption1'),
            ImageField::make(__('Image :number', ['number' => 2]), 'image2')
                ->enableExistingMedia()
                ->customPropertiesFields([Text::make(__('Alt-text'), 'alt')]),

            Text::make(__('Image description'), 'figcaption2'),
        ];
    }

    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('image1')->singleFile();
        $this->addMediaCollection('image2')->singleFile();
    }
}
