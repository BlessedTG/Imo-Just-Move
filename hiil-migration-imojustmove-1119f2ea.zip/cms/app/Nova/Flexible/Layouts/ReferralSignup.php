<?php

namespace App\Nova\Flexible\Layouts;

use Laravel\Nova\Fields\Text as NovaTextField;
use Mostafaznv\NovaCkEditor\CkEditor;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class ReferralSignup extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'referral_signup';

    public function title(): string
    {
        return __('Referral signup');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            NovaTextField::make(__('Title'), 'title')->rules(['required']),
            CkEditor::make(__('Text'), 'text')->rules(['required']),
            NovaTextField::make(
                __('Referral Signup Trigger label'),
                'referral_signup_trigger_label'
            )->help(__('...')),
        ];
    }
}
