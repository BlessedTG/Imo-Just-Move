<?php

namespace App\Nova\Flexible\Layouts;

use Laravel\Nova\Fields\Textarea;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class LargeText extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'large_text';

    public function title(): string
    {
        return __('Large text');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [Textarea::make(__('Text'), 'text')->rules(['required'])];
    }
}
