<?php

namespace App\Nova\Flexible\Layouts;

use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class Question extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'question';

    public function title(): string
    {
        return __('Question');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            // Define the layout's fields.
            Text::make(__('Question'), 'question')
                ->rules(['required'])
                ->fullWidth(),
            Flexible::make(__('Answers'), 'answers')
                ->button(__('Add Answer'))
                ->addLayout(Answer::class)
                ->limit(3)
                ->fullWidth(),
        ];
    }
}
