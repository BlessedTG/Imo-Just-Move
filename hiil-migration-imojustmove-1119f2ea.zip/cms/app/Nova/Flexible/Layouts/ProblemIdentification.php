<?php

namespace App\Nova\Flexible\Layouts;

use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Text as NovaTextField;
use Outl1ne\MultiselectField\Multiselect;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class ProblemIdentification extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'problem_identification';

    public function title(): string
    {
        return __('Problem identification');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        /** @var NovaSelectOptionsRepository $optionsRepository */
        $optionsRepository = resolve(NovaSelectOptionsRepository::class);

        return [
            NovaTextField::make(__('Title'), 'title'),
            NovaTextField::make(__('Description'), 'description')->rules([
                'required',
            ]),
            Multiselect::make(__('Problem Categories'), 'problem_categories')
                ->options($optionsRepository->forProblemCategories('id'))
                ->saveAsJSON()
                ->reorderable(),
            Flexible::make(__('Back'), 'back_link')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1),
            Flexible::make(__('Link'), 'link')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1),
        ];
    }
}
