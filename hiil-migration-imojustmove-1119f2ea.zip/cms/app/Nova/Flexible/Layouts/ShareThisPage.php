<?php

namespace App\Nova\Flexible\Layouts;

use App\NovaSelectOptionsRepository;
use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class ShareThisPage extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'share_this_page';

    public function title(): string
    {
        return __('Share this page');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        /** @var NovaSelectOptionsRepository $optionRepository */
        $optionRepository = resolve(NovaSelectOptionsRepository::class);

        return [
            Text::make(__('Title'), 'title')->rules(['required']),
            Text::make(__('Introduction text'), 'intro'),
            Text::make(__('Email label'), 'email_label')->rules(['required']),
            Text::make(__('Print label'), 'print_label')->rules(['required']),
            Text::make(__('Whatsapp label'), 'whatsapp_label')->rules([
                'required',
            ]),
        ];
    }
}
