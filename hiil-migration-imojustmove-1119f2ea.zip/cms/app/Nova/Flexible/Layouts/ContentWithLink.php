<?php

namespace App\Nova\Flexible\Layouts;

use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images;
use App\Nova\Flexible\Concerns\HasMediaLibrary;
use Spatie\MediaLibrary\HasMedia;
/**
 * @extends Layout<array-key, mixed>
 */
final class ContentWithLink extends Layout implements HasMedia
{
    use HasMediaLibrary;

    /*
     * Get a cloned instance with set values
     * Because there is a issue with the Nova Dependency Container in Flexible Content
     * https://github.com/epartment/nova-dependency-container/issues/102
     *
     * @param  string  $key
     * @param  array  $attributes
     * @return \Whitecube\NovaFlexibleContent\Layouts\Layout
     */
    public function duplicateAndHydrate($key, array $attributes = [])
    {
        return new static($this->title, $this->name, null, $key, $attributes);
    }

    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'content_with_link';

    public function title(): string
    {
        return __('Content with link');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            // Define the layout's fields.
            Text::make('Title', 'title')->rules(['required']),
            Textarea::make('Description', 'description')
                ->rows(3)
                ->rules(['required']),
            Images::make(__('Image'), 'image')
                ->help(__('This icon will be shown above the text.'))
                ->fullWidth(),
            Flexible::make('Link', 'link')
                ->addLayout(Link::class)
                ->button('Add link')
                ->limit(1)
                ->rules(['required'])
                ->fullWidth(),
        ];
    }
    public function registerMediaCollections(): void
    {
        $this->addMediaCollection('image')->singleFile();
    }
}
