<?php

namespace App\Nova\Flexible\Layouts;

use Laravel\Nova\Fields\Text as NovaTextField;
use Mostafaznv\NovaCkEditor\CkEditor;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class Text extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'text';

    public function title(): string
    {
        return __('Text');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            NovaTextField::make(__('Title'), 'title')->rules(['required']),
            CkEditor::make(__('Text'), 'text')
                ->rules(['required'])
                ->contentLanguage(app()->getLocale()),
            Flexible::make(__('Links'), 'links')
                ->addLayout(Link::class)
                ->button(__('Add link'))
                ->limit(1),
            NovaTextField::make(
                __('Save intake trigger label'),
                'save_intake_trigger_label'
            )->help(
                __(
                    'This button should only be added on outcome pages, the button will be shown on the button that triggers the save intake popup form. When left empty the button will not be shown.'
                )
            ),
        ];
    }
}
