<?php

namespace App\Nova\Flexible\Layouts;

use Whitecube\NovaFlexibleContent\Layouts\Collection as LayoutCollection;
use Spatie\MediaLibrary\MediaCollections\Models\Media;
use Laravel\Nova\Fields\Text;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

/**
 * @extends Layout<array-key, mixed>
 */
class LinkThrough extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'link_through';

    public function title(): string
    {
        return __('Link through');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            Text::make(__('Title'), 'title')->rules(['required']),
            Flexible::make(__('Content with links'), 'content_with_links')
                ->button(__('Add content link'))
                ->addLayout(ContentWithLink::class)
                ->limit(4)
                ->help(
                    __(
                        'On the Tunesian website you can add up to 4, all other websites can add up to 3.'
                    )
                )
                ->rules(['required'])
                ->fullWidth(),
        ];
    }

    /**
     * Map nested Flexible layouts to array as well.
     * And add inject media data
     *
     * @return array<mixed>
     */
    public function toArray()
    {
        return array_merge($this->attributesToArray(), [
            'content_with_links' => $this->getContentWithLinksAttribute()
                ->map(function (ContentWithLink $item) {
                    /**
                     * @var Media|null $image
                     */
                    $image = $item->getMedia('image')->first();
                    if (!$image) {
                        return [
                            'layout' => $item->name(),
                            'attributes' => $item->toArray(),
                        ];
                    }
                    return [
                        'layout' => $item->name(),
                        'attributes' => array_merge($item->toArray(), [
                            'image' => formatMedia($image),
                        ]),
                    ];
                })
                ->toArray(),
        ]);
    }

    /**
     * Ensure the nested Flexible layouts are casted appropriately.
     *
     * @return LayoutCollection<int, ContentWithLink>
     */
    public function getContentWithLinksAttribute()
    {
        /**
         * Make sure every layout will have the right model.
         * This must match whatever is stored in the media table, but will by
         * default return the parent layout.
         */
        $out = $this->flexible('content_with_links', [
            'content_with_link' => ContentWithLink::class,
        ]);
        if ($out instanceof LayoutCollection) {
            $out->each->setModel($this->model);
        }
        return $out;
    }
}
