<?php

namespace App\Nova\Flexible\Layouts;

use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class Questions extends Layout
{
    /**
     * The layout's unique identifier
     *
     * @var string
     */
    protected $name = 'questions';

    public function title(): string
    {
        return __('Questions');
    }

    /**
     * Get the fields displayed by the layout.
     *
     * @return array
     */
    public function fields()
    {
        return [
            // Define the layout's fields.
            Flexible::make(__('Questions'), 'questions')
                ->button(__('Add question'))
                ->addLayout(Question::class)
                ->fullWidth(),
        ];
    }
}
