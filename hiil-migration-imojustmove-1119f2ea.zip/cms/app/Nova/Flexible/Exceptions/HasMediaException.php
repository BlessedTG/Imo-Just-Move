<?php

namespace App\Nova\Flexible\Exceptions;

use App\Nova\Flexible\Concerns\HasMediaLibrary;
use Exception;
use Whitecube\NovaFlexibleContent\Layouts\Layout;

class HasMediaException extends Exception
{
    /**
     * @param Layout<array-key,mixed> $layout
     */
    public static function missingTrait(Layout $layout): self
    {
        return new self(
            sprintf(
                'Layout %s does not use trait %s',
                $layout->name(),
                HasMediaLibrary::class
            )
        );
    }
}
