<?php

namespace App\Nova\Flexible\Presets;

use App\Nova\Flexible\Layouts\Faq;
use App\Nova\Flexible\Layouts\FeedbackForm;
use App\Nova\Flexible\Layouts\Images;
use App\Nova\Flexible\Layouts\LinkThrough;
use App\Nova\Flexible\Layouts\Resources;
use App\Nova\Flexible\Layouts\Text;
use App\Nova\Flexible\Layouts\TextMedia;
use App\Nova\Flexible\Layouts\LargeText;
use App\Nova\Flexible\Layouts\CallToAction;
use App\Nova\Flexible\Layouts\ProblemIdentification;
use App\Nova\Flexible\Layouts\ShareThisPage;
use App\Nova\Flexible\Layouts\WhatToExpect;
use App\Nova\Flexible\Layouts\ReferralSignup;
use Whitecube\NovaFlexibleContent\Flexible;
use Whitecube\NovaFlexibleContent\Layouts\Preset;

class MyPreset extends Preset
{
    /**
     * Execute the preset configuration
     *
     * @return void
     */
    public function handle(Flexible $field)
    {
        // You can call all available methods on the Flexible field.
        $field
            ->collapsed()
            ->fullWidth()
            ->button(__('Add content block'))
            // Add your flexible blocks here:
            // Don't forget to `use` them!
            ->addLayout(Text::class)
            ->addLayout(TextMedia::class)
            ->addLayout(LargeText::class)
            ->addLayout(Faq::class)
            ->addLayout(FeedbackForm::class)
            ->addLayout(Images::class)
            ->addLayout(CallToAction::class)
            ->addLayout(LinkThrough::class)
            ->addLayout(ProblemIdentification::class)
            ->addLayout(Resources::class)
            ->addLayout(ShareThisPage::class)
            ->addLayout(WhatToExpect::class)
            ->addLayout(ReferralSignup::class)
            ->nullable();
    }
}
