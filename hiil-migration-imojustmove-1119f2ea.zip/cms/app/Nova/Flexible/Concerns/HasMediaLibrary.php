<?php

namespace App\Nova\Flexible\Concerns;

use Whitecube\NovaFlexibleContent\Concerns\HasMediaLibrary as BaseHasMediaLibrary;

trait HasMediaLibrary
{
    use BaseHasMediaLibrary;

    /**
     * Overwritten to ensure a predictable pattern is used for flex block media collections.
     * This is used in PageResource to differentiate media from the model itself,
     * versus media in flex blocks.
     *
     * @return string
     */
    public function getSuffix()
    {
        return config('custom.flexible_content.media_suffix_prefix') .
            $this->inUseKey();
    }
}
