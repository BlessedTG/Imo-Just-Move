<?php namespace App\Nova\Fields;

use Alexwenzel\DependencyContainer\DependencyContainer as NovaDependencyContainerBase;
use Illuminate\Support\Str;

/**
 * Extension of the NovaDependencyContainer package to allow dependency container field
 * inside flexible content.
 *
 */
class NovaDependencyContainer extends NovaDependencyContainerBase
{
    public function resolveForDisplay($resource, $attribute = null)
    {
        foreach ($this->meta['fields'] as $field) {
            $field->resolveForDisplay($resource);
        }
        foreach ($this->meta['dependencies'] as $index => $dependency) {
            $this->meta['dependencies'][$index]['satisfied'] = false;

            if (
                array_key_exists('empty', $dependency) &&
                empty($resource->{$dependency['property']})
            ) {
                $this->meta['dependencies'][$index]['satisfied'] = true;
                continue;
            }
            // inverted `empty()`
            if (
                array_key_exists('notEmpty', $dependency) &&
                !empty($resource->{$dependency['property']})
            ) {
                $this->meta['dependencies'][$index]['satisfied'] = true;
                continue;
            }
            // inverted
            if (
                array_key_exists('nullOrZero', $dependency) &&
                in_array(
                    $resource->{$dependency['property']},
                    [null, 0, '0'],
                    true
                )
            ) {
                $this->meta['dependencies'][$index]['satisfied'] = true;
                continue;
            }

            if (
                array_key_exists('not', $dependency) &&
                $resource->{$dependency['property']} != $dependency['not']
            ) {
                $this->meta['dependencies'][$index]['satisfied'] = true;
                continue;
            }

            if (array_key_exists('value', $dependency)) {
                if (is_array($resource)) {
                    if (
                        isset($resource[$dependency['property']]) &&
                        $dependency['value'] ==
                            $resource[$dependency['property']]
                    ) {
                        $this->meta['dependencies'][$index]['satisfied'] = true;
                    }
                    continue;
                } elseif (
                    $dependency['value'] == $resource->{$dependency['property']}
                ) {
                    $this->meta['dependencies'][$index]['satisfied'] = true;
                    continue;
                }
                // @todo: quickfix for MorphTo
                $morphable_attribute = $resource->getAttribute(
                    $dependency['property'] . '_type'
                );
                if (
                    $morphable_attribute !== null &&
                    Str::endsWith(
                        $morphable_attribute,
                        '\\' . $dependency['value']
                    )
                ) {
                    $this->meta['dependencies'][$index]['satisfied'] = true;
                    continue;
                }
            }
        }
    }
}
