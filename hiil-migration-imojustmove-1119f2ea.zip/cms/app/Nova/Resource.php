<?php

namespace App\Nova;

use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Resource as NovaResource;

/**
 * @template TModel of \Illuminate\Database\Eloquent\Model
 * @extends NovaResource<TModel>
 */
abstract class Resource extends NovaResource
{
    /**
     * Build an "index" query for the given resource.
     *
     * @template TModelClass of \Illuminate\Database\Eloquent\Model
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @param  \Illuminate\Database\Eloquent\Builder<TModelClass>  $query
     * @return \Illuminate\Database\Eloquent\Builder<TModelClass>
     */
    public static function indexQuery(NovaRequest $request, $query)
    {
        return $query;
    }

    /**
     * Build a "detail" query for the given resource.
     *
     * @template TModelClass of \Illuminate\Database\Eloquent\Model
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @param  \Illuminate\Database\Eloquent\Builder<TModelClass>  $query
     * @return \Illuminate\Database\Eloquent\Builder<TModelClass>
     */
    public static function detailQuery(NovaRequest $request, $query)
    {
        return parent::detailQuery($request, $query);
    }

    /**
     * Build a "relatable" query for the given resource.
     *
     * This query determines which instances of the model may be attached to other resources.
     *
     * @template TModelClass of \Illuminate\Database\Eloquent\Model
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @param  \Illuminate\Database\Eloquent\Builder<TModelClass>  $query
     * @return \Illuminate\Database\Eloquent\Builder<TModelClass>
     */
    public static function relatableQuery(NovaRequest $request, $query)
    {
        return parent::relatableQuery($request, $query);
    }
}
