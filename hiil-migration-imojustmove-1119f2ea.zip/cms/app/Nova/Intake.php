<?php

namespace App\Nova;

use App\Models\Intake as IntakeModel;
use App\Permissions;
use Ebess\AdvancedNovaMediaLibrary\Fields\Files;
use Illuminate\Http\Request;
use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Resource;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Http\Requests\NovaRequest;
use Outl1ne\NovaNotesField\NotesField;

/**
 * @extends Resource<\App\Models\Intake>
 */
class Intake extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var class-string<\App\Models\Intake>
     */
    public static $model = \App\Models\Intake::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'reference_id';

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = ['reference_id', 'name', 'surname'];

    public static function label(): string
    {
        return __('Intakes');
    }

    public static function singularLabel(): string
    {
        return __('Intake');
    }

    /**
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @param  \Illuminate\Database\Eloquent\Builder<IntakeModel>  $query
     * @return \Illuminate\Database\Eloquent\Builder<IntakeModel>
     */
    public static function indexQuery(NovaRequest $request, $query)
    {
        // If a user can view all intakes, return the query as is.
        if ($request->user()?->can(Permissions::MANAGE_INTAKES)) {
            return $query;
        }

        // Only show intakes that belong to the user.
        if ($request->user()?->can(Permissions::MANAGE_OWN_INTAKES)) {
            return $query->where('owner_id', $request->user()->id);
        }

        // Otherwise leave the query alone.
        return $query;
    }

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            Text::make(__('Reference ID'), 'reference_id')
                ->readonly()
                ->required(),
            BelongsTo::make(__('Status'), 'intakeStatus', IntakeStatus::class)
                ->required()
                ->filterable()
                ->withMeta([
                    'belongsToId' => $this->intake_status_id ?? 1, // Set default status if not set already
                ])
                ->rules(['required']),
            BelongsTo::make(__('Owner'), 'owner', User::class)
                ->nullable()
                ->canSee(function (Request $request) {
                    return $request->user() &&
                        $request->user()->can(Permissions::MANAGE_INTAKES);
                }),
            Text::make(__('Name'), 'name')
                ->rules(['required'])
                ->required(),
            Text::make('Surname', 'surname')
                ->rules(['required'])
                ->required(),
            Text::make(__('Phone number'), 'phone_number')
                ->nullable()
                ->hideFromIndex(),
            Text::make(__('Email'), 'email')
                ->rules(['required', 'email'])
                ->required()
                ->hideFromIndex(),
            Text::make(__('Location'), 'location')
                ->rules(['required'])
                ->required()
                ->hideFromIndex(),
            Text::make(__('Problem'), 'problem'),
            Text::make('Outcome', 'outcome'),
            Textarea::make('Additional message', 'additional_message')
                ->nullable()
                ->hideFromIndex(),
            DateTime::make(__('Created at'), 'created_at')
                ->onlyOnIndex()
                ->sortable(),

            Files::make(__('Attachments'), 'attachments'),
            NotesField::make(__('Notes'), 'notes')
                ->placeholder(__('Add note'))
                ->fullWidth(),
        ];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }
}
