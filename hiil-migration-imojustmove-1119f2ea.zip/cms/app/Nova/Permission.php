<?php

namespace App\Nova;

use Illuminate\Http\Request;
use Laravel\Nova\Fields\Text;
use Sereny\NovaPermissions\Nova\Permission as NovaPermission;

final class Permission extends NovaPermission
{
    public function fields(Request $request)
    {
        $fields = parent::fields($request);

        $nameField = $fields[1];
        if ($nameField instanceof Text && $nameField->attribute === 'name') {
            $nameField->displayUsing(function ($value) {
                return __($value);
            });
        }

        return $fields;
    }
}
