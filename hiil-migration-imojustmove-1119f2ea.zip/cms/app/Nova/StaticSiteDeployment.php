<?php

namespace App\Nova;

use App\DeploymentStatus;
use App\Duration;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Resource;
use App\Nova\Actions\TriggerStaticSiteDeployment;
use App\Permissions;
use Laravel\Nova\Fields\Status;
use Laravel\Nova\Http\Requests\NovaRequest;

/**
 * @extends Resource<\App\Models\StaticSiteDeployment>
 */
class StaticSiteDeployment extends Resource
{
    /**
     * The model the resource corresponds to.
     *
     * @var class-string<\App\Models\StaticSiteDeployment>
     */
    public static $model = \App\Models\StaticSiteDeployment::class;

    public static $title = 'id';

    public static $search = ['id', 'status', 'message'];

    public static $polling = true;

    public static $pollingInterval = 2; // seconds

    public static $showPollingToggle = false;

    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        return [
            ID::make()->sortable(),
            Status::make(__('Status'), 'status')
                ->loadingWhen(
                    enum_string_values(DeploymentStatus::inProgress())
                )
                ->failedWhen([DeploymentStatus::FAILED->value]),
            Text::make(__('Duration'), 'duration')
                ->sortable()
                ->exceptOnForms()
                ->resolveUsing(function ($value) {
                    if ($value === null) {
                        return '00:00:00';
                    }
                    if ($value instanceof Duration) {
                        return $value->toHumanReadable();
                    }
                    throw new \InvalidArgumentException(
                        'Expected Duration instance, got ' . gettype($value)
                    );
                }),
            Text::make(__('Message'), 'message')->hideFromIndex(),
            DateTime::make(__('Created At'), 'created_at')->sortable(),
        ];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [TriggerStaticSiteDeployment::make()->standalone()];
    }
}
