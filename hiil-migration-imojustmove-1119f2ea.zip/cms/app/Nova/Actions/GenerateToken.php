<?php

namespace App\Nova\Actions;

use App\Models\User;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Fields\ActionFields;
use Laravel\Nova\Fields\Hidden;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Http\Requests\NovaRequest;

class GenerateToken extends Action
{
    use InteractsWithQueue, Queueable;

    public function name(): string
    {
        return __('Generate API Token');
    }

    /**
     * Perform the action on the given models.
     *
     * @param  ActionFields $fields
     * @return mixed
     */
    public function handle(ActionFields $fields)
    {
        /** @var string|null */
        $userId = $fields->user_id ?? null;
        /** @var string|null */
        $tokenName = $fields->name ?? null;

        if (!$userId || !$tokenName) {
            return Action::danger(__('User and name are required.'));
        }
        /** @var \App\Models\User $user */
        $user = User::query()->findOrFail($userId);
        $token = $user->createToken($tokenName)->plainTextToken;

        return Action::modal('api-token-copier', [
            'token' => explode('|', $token)[1],
        ]);
    }

    /**
     * Get the fields available on the action.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array<\Laravel\Nova\Fields\Field>
     */
    public function fields(NovaRequest $request): array
    {
        if ($request->viaResourceId) {
            $userField = Hidden::make('user_id')->default(
                $request->viaResourceId
            );
        } else {
            $userField = Select::make(__('User'), 'user_id')
                ->options(
                    fn() => User::query()
                        ->orderBy('email')
                        ->orderBy('name')
                        ->cursor()
                        ->mapWithKeys(function (User $user) {
                            $resource = new \App\Nova\User($user);
                            return [
                                $user->id => $resource->title(),
                            ];
                        })
                )
                ->rules('required');
        }
        return [
            Text::make(__('Name'), 'name')
                ->help(
                    __(
                        'Description of what the token is used for, this makes it easier to remove a token later, if a person has multiple.'
                    )
                )
                ->rules('required'),
            $userField,
        ];
    }
}
