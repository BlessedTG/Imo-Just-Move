<?php

namespace App\Nova\Actions;

use App\Actions\DuplicatePage as ActionsDuplicatePage;
use Grrr\Pages\Resources\PageResource;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Collection;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Fields\ActionFields;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Heading;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Slug;
use Laravel\Nova\Fields\Text;
// TODO: Is this action used or is Nova's replacate sufficient?

class DuplicatePage extends Action
{
    use SerializesModels;

    public $name = 'Dupliceer pagina';
    public $showOnDetail = true;
    public $showOnIndex = true;
    public $showInline = false;
    public $confirmButtonText = 'Dupliceer pagina';
    public $cancelButtonText = 'Annuleer';
    public $confirmText = 'Weet je zeker dat je deze pagina wil dupliceren?';

    protected array $keepRelations = [];
    protected array $skipFields = ['slug', 'url'];

    protected PageResource $resource;

    public function __construct(PageResource $resource)
    {
        $this->resource = $resource;
    }

    /**
     * Perform the action on the given models.
     *
     * @param ActionFields $fields
     * @param Collection<int,\App\Models\Page> $models
     *
     * @return mixed
     */
    public function handle(ActionFields $fields, Collection $models)
    {
        if ($models->count() !== 1) {
            return Action::danger(
                'Je kunt niet meerdere pagina\'s tegelijk dupliceren.'
            );
        }

        /**
         * @var \App\Models\Page $model
         */
        $model = $models->first();
        $action = new ActionsDuplicatePage();
        $attributes = collect($fields->getAttributes());
        $modelAttributes = $attributes->except(['copy_children'])->toArray();
        $copyChildren = boolval($attributes->get('copy_children'));

        $newModel = $action->handle(
            $model,
            $this->skipFields,
            $modelAttributes,
            $copyChildren
        );

        return Action::visit('/resources/grrr-page/' . $newModel->getKey());
    }

    /**
     * Get the fields available on the action.
     *
     * @return array
     */
    public function fields(\Laravel\Nova\Http\Requests\NovaRequest $request)
    {
        /**
         * @var \App\Models\Page $page
         */
        $page = $this->resource->model();
        return [
            Heading::make('Vul de volgende eigenschappen in voor de kopie:'),
            Text::make('Title')
                ->default(
                    $this->resource->title ? "Kopie van {$page->title}" : ''
                )
                ->rules(['required']),
            Slug::make('Slug')
                ->from('title')
                ->rules(['required']),
            Select::make('Status', 'status')
                ->options($this->resource->getPageStatusOptions())
                ->rules('required')
                ->onlyOnForms()
                ->default($page->status),
            Boolean::make(
                'Wil je ook alle onderliggende pagina\'s kopiëren?',
                'copy_children'
            ),
        ];
    }
}
