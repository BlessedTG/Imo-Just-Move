<?php

namespace App\Nova\Actions;

use App\DeploymentStatus;
use App\Jobs\TriggerStaticSiteDeploymentJob;
use App\Models\StaticSiteDeployment;
use Laravel\Nova\Actions\Action;
use Laravel\Nova\Actions\ActionResponse;

class TriggerStaticSiteDeployment extends Action
{
    public function name(): string
    {
        return __('Trigger Static Site Deployment');
    }

    public function handle(): Action|ActionResponse
    {
        // Is there an existing deployment in progress?
        $existingDeployment = StaticSiteDeployment::whereIn(
            'status',
            enum_string_values(DeploymentStatus::inProgress())
        )->first();
        if ($existingDeployment) {
            Action::danger(
                __('A static site deployment is already in progress.')
            );
        }
        // Ensure a new deployment record is created before dispatching the job,
        // allowing the admin to see the deployment immediately in the index view.
        $deployment = StaticSiteDeployment::create([
            'status' => DeploymentStatus::PENDING,
            'message' => __('Deployment triggered'),
        ]);

        TriggerStaticSiteDeploymentJob::dispatch($deployment);

        return ActionResponse::visit(
            '/resources/static-site-deployments/'
        )->withMessage(__('Static site deployment queued'));
    }
}
