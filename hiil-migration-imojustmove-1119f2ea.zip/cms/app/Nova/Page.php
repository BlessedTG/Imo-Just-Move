<?php

namespace App\Nova;

use App\Models\Page as PageModel;
use App\Nova\Actions\DuplicatePage;
use App\Nova\Flexible\Presets\MyPreset;
use App\NovaSelectOptionsRepository;
use App\Visibility;
use Ebess\AdvancedNovaMediaLibrary\Fields\Images;
use Grrr\Pages\Resources\PageResource;
use Illuminate\Contracts\Database\Eloquent\Builder;
use Laravel\Nova\Fields\Boolean;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\Textarea;
use Laravel\Nova\Http\Requests\NovaRequest;
use Laravel\Nova\Fields\Select;
use Mostafaznv\NovaCkEditor\CkEditor;

class Page extends PageResource
{
    /**
     * @var string
     */
    public static $model = \App\Models\Page::class;

    public function getFlexibleLayouts(): array
    {
        return [];
    }

    public function getFlexiblePreset(): ?string
    {
        return MyPreset::class;
    }

    /**
     * Make sure pages are ordered by url, which should show the hierarchy
     * between parents and children.
     *
     * @param \Laravel\Nova\Http\Requests\NovaRequest $request
     * @param \Illuminate\Database\Eloquent\Builder<PageModel> $query
     */
    public static function indexQuery(NovaRequest $request, $query): void
    {
        $query
            ->select(['id', 'title', 'url', 'status']) // Should be the same as the fields that are shown in the index
            ->when(empty($request->get('orderBy')), function (Builder $q) {
                $q->getQuery()->orders = [];

                return $q->orderBy('url')->orderBy('title');
            });
    }

    /**
     * Create an ordered set of pages, to be used in Select-type fields in Nova.
     * This can be used in userland-provided resources that need to link to
     * pages, for instance.
     *
     * @param ?string $withoutId Omit this page id from the result
     */
    public static function getPageOptionsForSelect(
        ?string $withoutId = null
    ): array {
        return once(function () use ($withoutId) {
            return PageModel::query()
                ->select(['id', 'title', 'url'])
                ->when(
                    $withoutId,
                    fn($builder) => $builder->where('id', '!=', $withoutId)
                )
                ->orderBy('url')
                ->orderBy('title')
                ->cursor()
                ->mapWithKeys(function (PageModel $page) {
                    $novaPage = new self($page);
                    return [
                        $page->id =>
                            str_repeat('-', substr_count($page->url, '/') - 1) .
                            " {$novaPage->title()}",
                    ];
                })
                ->toArray();
        });
    }

    public function basicFields(): array
    {
        $selectOptionsRepository = resolve(NovaSelectOptionsRepository::class);
        $parentFields = parent::basicFields();
        $parentFields[] = Select::make(__('Visibility'), 'metadata->visibility')
            ->options([
                Visibility::Public->value => __('Public'),
                Visibility::Protected->value => __('Protected'),
            ])
            ->default('public')
            ->help(
                __(
                    'Select the visibility of the page. Public pages are visible to everyone, protected pages are only visible to cms users'
                )
            )
            ->displayUsingLabels();
        $parentFields[] = Select::make(
            __('Allowed role'),
            'metadata->allowed_role'
        )
            ->options($selectOptionsRepository->forRoles())
            ->help(
                __(
                    'Select the role that is allowed to see the protected page. If no role is selected, any role is allowed to see the content'
                )
            )
            ->nullable();
        return $parentFields;
    }

    public function fieldsForHome(): array
    {
        return [
            CkEditor::make(__('Subtitle'), 'metadata->subtitle')
                ->required()
                ->rules(['required'])
                ->contentLanguage(app()->getLocale()),
            CkEditor::make(__('Intro text'), 'metadata->intro'),
            Images::make(
                __('Image'),
                'header_home_image'
            )->customPropertiesFields([Text::make(__('Alt-text'), 'alt')]),
            Boolean::make(
                __('Is background image'),
                'metadata->is_background_image'
            )
                ->default(false)
                ->help(
                    __(
                        'When this option is selected, the image will be used as background of the header on the homepage'
                    )
                ),
            Text::make(__('VideoID'), 'metadata->videoID')->help(
                __(
                    'Add the VideoID from the YouTube URL. Example: https://www.youtube.com/watch?v=<strong>VideoID</strong>. Adding a video will overwrite the image, unless the image is used as a background image'
                )
            ),
        ];
    }

    public function fieldsForDefault(): array
    {
        return [
            Text::make(__('Intro text'), 'metadata->intro')->help(
                __('This introduction text will be shown under the page title.')
            ),
            Images::make(__('Image'), 'header_image')
                ->help(__('This image will be shown under the intro text'))
                // ->enableExistingMedia()
                ->customPropertiesFields([Text::make(__('Alt-text'), 'alt')]),
            Text::make(
                __('Page preview subtext'),
                'metadata->page_preview_subtext'
            )->help(
                __(
                    'This text will be shown inside of the page preview below the page title. Try to adhere to a maximum of :number characters.',
                    ['number' => 60]
                )
            ),
        ];
    }

    public function actions(NovaRequest $request)
    {
        return [new DuplicatePage($this)];
    }
}
