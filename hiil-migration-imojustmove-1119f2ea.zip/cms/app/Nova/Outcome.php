<?php

namespace App\Nova;

use App\Nova\Flexible\Presets\MyPreset;
use App\NovaSelectOptionsRepository;
use App\Visibility;
use Eminiarts\Tabs\Tab;
use Eminiarts\Tabs\Tabs;
use Eminiarts\Tabs\Traits\HasTabs;
use Illuminate\Contracts\Database\Eloquent\Builder;
use Illuminate\Support\Str;
use Illuminate\Support\Stringable;
use Laravel\Nova\Fields\Text;
use Laravel\Nova\Fields\ID;
use Laravel\Nova\Fields\DateTime;
use Laravel\Nova\Fields\BelongsTo;
use Laravel\Nova\Fields\BelongsToMany;
use Laravel\Nova\Fields\Select;
use Laravel\Nova\Fields\Slug;
use Laravel\Nova\Http\Requests\NovaRequest;
use Whitecube\NovaFlexibleContent\Flexible;

/**
 * @extends Resource<\App\Models\Outcome>
 */
class Outcome extends Resource
{
    use HasTabs;
    /**
     * The model the resource corresponds to.
     *
     * @var class-string<\App\Models\Outcome>
     */
    public static $model = \App\Models\Outcome::class;

    /**
     * The single value that should be used to represent the resource when being displayed.
     *
     * @var string
     */
    public static $title = 'title';

    public static function label(): string
    {
        return __('Outcomes');
    }

    public static function singularLabel(): string
    {
        return __('Outcome');
    }

    /**
     * The columns that should be searched.
     *
     * @var array
     */
    public static $search = ['slug', 'title'];

    public function title()
    {
        if (!$this->title) {
            return '';
        }
        /**
         * @var \App\Models\TargetAudience|null $targetAudience
         */
        $targetAudience = $this->target_audience;

        /**
         * @var \App\Models\Problem|null $problem
         */
        $problem = $this->problem;

        return Str::of($this->title)
            // Another strategy for displaying the title of the resource in select options
            // example: Outcome title (/outcome/url/path)
            // ->when(
            //     !!$this->resource,
            //     fn(Stringable $string) => !$this->resource?->url
            //         ? $string
            //         : $string->append(
            //             ' (' . $this->resource->url->__toString() . ')'
            //         )
            // )
            ->when(
                !!$targetAudience,
                fn(Stringable $string) => !$targetAudience
                    ? $string
                    : $string->append(' (' . $targetAudience->name)->append(')')
            )
            ->when(
                !!$problem,
                fn(Stringable $string) => !$problem
                    ? $string
                    : $string->append(' - ' . $problem->title)
            )
            ->__toString();
    }
    /**
     * Get the fields displayed by the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function fields(NovaRequest $request)
    {
        $fields = [
            Tabs::make($this->title(), [
                Tab::make(
                    __('pages::pages.panels.basic'),
                    $this->basicFields()
                ),
                Tab::make(
                    __('pages::pages.panels.content'),
                    $this->contentFields()
                ),
            ])->withToolbar(),
            BelongsToMany::make(__('Referrals'), 'referrals', Referral::class),
        ];
        return $fields;
    }

    protected function basicFields(): array
    {
        $selectOptionsRepository = resolve(NovaSelectOptionsRepository::class);
        return [
            ID::make()->sortable(),
            targetAudienceField(__('Target audience'), 'target_audience'),
            Text::make(__('Title'), 'title')
                ->rules('required', 'max:255')
                ->sortable(),
            Slug::make(__('Slug'), 'slug')
                ->from('title')
                ->rules('required', 'max:255')
                ->sortable(),
            Text::make(__('URL'), 'url')
                ->readonly()
                ->displayAsFrontendLink()
                ->hideFromIndex(),
            Select::make(__('Language'), 'language')
                ->options([
                    'en' => __('English'),
                    'ar' => __('Arabic'),
                ])
                ->rules('required'),
            Text::make(__('Description'), 'description')->rules('max:255'),
            BelongsTo::make(__('Problem'), 'problem', Problem::class)->rules(
                'required'
            ),
            DateTime::make(__('Created at'), 'created_at')->onlyOnIndex(),
            Select::make(__('Visibility'), 'visibility')
                ->options([
                    Visibility::Public->value => __('Public'),
                    Visibility::Protected->value => __('Protected'),
                ])
                ->default('public')
                ->help(
                    __(
                        'Select the visibility of the page. Public pages are visible to everyone, protected pages are only visible to cms users'
                    )
                )
                ->displayUsingLabels(),
            Select::make(__('Allowed role'), 'allowed_role')
                ->options($selectOptionsRepository->forRoles())
                ->help(
                    __(
                        'Select the role that is allowed to see the protected page. If no role is selected, any role is allowed to see the content'
                    )
                )
                ->nullable(),
        ];
    }

    protected function contentFields(): array
    {
        $flexible = Flexible::make(__('pages::pages.fields.content'), 'content')
            ->preset(MyPreset::class)
            ->nullable()
            ->collapsed();

        return [$flexible];
    }

    /**
     * Get the cards available for the request.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function cards(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the filters available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function filters(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the lenses available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function lenses(NovaRequest $request)
    {
        return [];
    }

    /**
     * Get the actions available for the resource.
     *
     * @param  \Laravel\Nova\Http\Requests\NovaRequest  $request
     * @return array
     */
    public function actions(NovaRequest $request)
    {
        return [];
    }
}
