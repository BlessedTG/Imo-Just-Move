<?php

namespace App\Events;

use App\Models\Intake;
use Illuminate\Queue\SerializesModels;

class IntakeWasCreated
{
    use SerializesModels;

    public function __construct(public Intake $model) {}
}
