<?php

namespace App\Events;

use App\Models\User;

class UserIsBeingCreated
{
    public function __construct(public User $user) {}
}
