<?php

namespace App\Events;

use App\Models\ReferralStatus;
use Illuminate\Queue\SerializesModels;

class SavingReferralStatus
{
    use SerializesModels;

    public function __construct(public ReferralStatus $referralStatus) {}
}
