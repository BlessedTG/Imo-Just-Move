<?php

namespace App\Events;

use App\Models\Referral;

final class ReferralWasCreated
{
    public function __construct(public Referral $model) {}
}
