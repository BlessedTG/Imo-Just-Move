<?php

namespace App\Events;

use App\Models\Referral;

final class ReferralIsBeingCreated
{
    public function __construct(public Referral $model) {}
}
