<?php

namespace App\Events;

use App\Models\TargetAudience;
use Illuminate\Queue\SerializesModels;

class SavingTargetAudience
{
    use SerializesModels;

    /**
     * Create a new event instance.
     */
    public function __construct(public TargetAudience $targetAudience) {}
}
