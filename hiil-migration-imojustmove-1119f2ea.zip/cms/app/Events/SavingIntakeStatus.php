<?php

namespace App\Events;

use App\Models\IntakeStatus;
use Illuminate\Queue\SerializesModels;

class SavingIntakeStatus
{
    use SerializesModels;

    public function __construct(public IntakeStatus $intakeStatus) {}
}
