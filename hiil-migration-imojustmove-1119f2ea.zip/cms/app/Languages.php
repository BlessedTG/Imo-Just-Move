<?php namespace App;

class Languages
{
    /**
     * @param array<string> $languages
     * @param string $defaultLanguage
     */
    public function __construct(
        protected array $languages,
        protected string $defaultLanguage
    ) {}

    /**
     * @return array<string>
     */
    public function all(): array
    {
        return $this->languages;
    }

    public function default(): string
    {
        return $this->defaultLanguage;
    }
}
