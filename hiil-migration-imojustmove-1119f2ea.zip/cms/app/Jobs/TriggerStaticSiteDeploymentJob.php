<?php

namespace App\Jobs;

use App\DeploymentStatus;
use App\Models\StaticSiteDeployment;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class TriggerStaticSiteDeploymentJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Indicate if the job should be marked as failed on timeout.
     *
     * @var bool
     */
    public $failOnTimeout = true;

    /**
     * The number of seconds the job can run before timing out.
     *
     * @var int
     */
    public $timeout = 600;

    public function __construct(public StaticSiteDeployment $deployment) {}

    public function handle(): void
    {
        $startTime = microtime(true);

        // Check if the deployment is not in a pending state.
        // This is a safety check to ensure we don't start a deployment
        // that is already in progress or completed.
        // This should never happen because we always dispatch this job
        // after creating a new deployment with status PENDING, but let's be safe.
        if ($this->deployment->status !== DeploymentStatus::PENDING) {
            logger('Deployment is not in pending state, skipping job.', [
                'deployment_id' => $this->deployment->id,
                'status' => $this->deployment->status,
            ]);
            return;
        }

        $this->deployment->update([
            'status' => DeploymentStatus::RUNNING,
            'message' => 'Deployment started',
        ]);

        try {
            $websiteBuildPath = base_path('website');
            /** @var string|null $staticSitePublicPath */
            $staticSitePublicPath = config('custom.static_site_public_path');

            if (!$staticSitePublicPath) {
                throw new \Exception(
                    'Static site public path is not configured.'
                );
            }
            // Run the static site build (adjust command as needed)
            $buildOutput = [];
            $buildStatus = 0;

            /**
             * @var array{"via_cron": boolean, "node_bin_dir": string, "npm_path": string} $queueWorkerConfig
             */
            $queueWorkerConfig = config('custom.queue_worker');

            $npmPath = $queueWorkerConfig['npm_path'];
            $nodeBinDir = $queueWorkerConfig['node_bin_dir'];
            $buildCommand = sprintf(
                'cd %s && PATH=%s:$PATH %s run build 2>&1',
                escapeshellarg($websiteBuildPath),
                escapeshellarg($nodeBinDir),
                escapeshellarg($npmPath)
            );
            $result = exec($buildCommand, $buildOutput, $buildStatus);
            logger('Result of build command: ', ['result' => $result]);
            logger('Output of build command: ', ['output' => $buildOutput]);

            if ($buildStatus !== 0) {
                $this->deployment->update([
                    'status' => DeploymentStatus::FAILED,
                    'message' => 'Build failed: ' . implode("\n", $buildOutput),
                    'duration' => (int) round(microtime(true) - $startTime),
                ]);
                return;
            }
            // Copy the out directory (adjust paths as needed)
            $copyOutput = [];
            $copyStatus = 0;
            $copyCommand = sprintf(
                'rsync -av --delete %s/out/ %s/',
                escapeshellarg($websiteBuildPath),
                escapeshellarg($staticSitePublicPath)
            );
            $result = exec($copyCommand, $copyOutput, $copyStatus);
            logger('Result of copy command: ', ['result' => $result]);
            logger('Output of copy command: ', ['output' => $copyOutput]);

            if ($copyStatus !== 0) {
                $this->deployment->update([
                    'status' => DeploymentStatus::FAILED,
                    'message' => 'Copy failed: ' . implode("\n", $copyOutput),
                    'duration' => (int) round(microtime(true) - $startTime),
                ]);
                return;
            }

            $this->deployment->update([
                'status' => DeploymentStatus::SUCCESS,
                'message' => 'Deployment completed successfully.',
                'duration' => (int) round(microtime(true) - $startTime),
            ]);
        } catch (\Throwable $e) {
            $this->deployment->update([
                'status' => DeploymentStatus::FAILED,
                'message' => $e->getMessage(),
                'duration' => (int) round(microtime(true) - $startTime),
            ]);
        }
    }

    public function failed(\Throwable $exception): void
    {
        // Could be that the job failed due to a timeout or other error.
        // If we didn't already set the status to FAILED in the handle method,
        // we should set it here.
        if ($this->deployment->status !== DeploymentStatus::FAILED) {
            $this->deployment->update([
                'status' => DeploymentStatus::FAILED,
                'message' => $exception->getMessage(),
                'duration' => (int) round(
                    microtime(true) -
                        (float) $this->deployment->created_at?->timestamp
                ),
            ]);
        }
    }
}
