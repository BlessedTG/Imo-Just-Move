<?php

namespace App\Jobs;

use App\Actions\GenerateScaledImages;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Spatie\MediaLibrary\MediaCollections\Models\Media;

class GenerateScaledImagesJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * The number of times the job may be attempted.
     *
     * @var int
     */
    public $tries = 3;

    /**
     * The number of seconds the job can run before timing out.
     *
     * @var int
     */
    public $timeout = 600;

    /**
     * The media item to process
     *
     * @var Media
     */
    private $media;

    /**
     * Create a new job instance.
     *
     * @param Media $media
     * @return void
     */
    public function __construct(Media $media)
    {
        $this->media = $media;
    }

    /**
     * Execute the job.
     *
     * @param GenerateScaledImages $generator
     * @return void
     */
    public function handle(GenerateScaledImages $generator): void
    {
        $generator->execute($this->media);
    }
}
