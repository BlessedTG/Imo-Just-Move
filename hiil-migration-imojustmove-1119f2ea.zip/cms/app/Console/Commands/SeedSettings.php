<?php

namespace App\Console\Commands;

use Database\Seeders\SettingsSeeder;
use Database\Seeders\SettingsSeederParameter;
use Illuminate\Console\Command;

class SeedSettings extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:seed-settings 
                            {--overwrite} : Overwrite all settings, regardless of their current value}
                            {--overwrite-if-empty : Overwrite settings, but only if they are empty}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Seeds the settings with defaults defined in the SettingsSeeder class.';

    /**
     * Execute the console command.
     */
    public function handle(): void
    {
        $overwriteIfEmpty = $this->option('overwrite-if-empty');
        $overwrite = $this->option('overwrite');

        $seederParameter = match (true) {
            $overwriteIfEmpty => SettingsSeederParameter::OverwriteIfEmpty,
            $overwrite => SettingsSeederParameter::Overwrite,
            default => SettingsSeederParameter::Default,
        };

        $seedMessage = match ($seederParameter) {
            SettingsSeederParameter::Overwrite
                => 'This will overwrite all settings with default values.',
            SettingsSeederParameter::OverwriteIfEmpty
                => 'This will overwrite settings that are empty with default values.',
            default => 'This will only create settings that are missing.',
        };

        $this->info($seedMessage);
        if (
            $seederParameter === SettingsSeederParameter::Overwrite ||
            $seederParameter === SettingsSeederParameter::OverwriteIfEmpty
        ) {
            $confirmation = $this->confirm(
                'Are you sure you want to do this? This action cannot be undone.'
            );
            if (!$confirmation) {
                $this->info('Aborting seed-settings command.');
                return;
            }
        }

        $seeder = resolve(SettingsSeeder::class);
        $seeder->run($seederParameter);
        $this->info('Settings seeded successfully.');
    }
}
