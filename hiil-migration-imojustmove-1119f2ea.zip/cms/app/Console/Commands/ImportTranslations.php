<?php

namespace App\Console\Commands;

use App\TranslationsRepository;
use Illuminate\Console\Command;
use Illuminate\Support\Str;

class ImportTranslations extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:import-translations 
                            {sourcePath : Source path of the csv file} 
                            {locale : Locale of the translations} 
                            {defaultColumn : Header name of default column of the translations} 
                            {translatedColumn : Header name of translated column of the translations}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import translations from a csv file';

    /**
     * Execute the console command.
     */
    public function handle(TranslationsRepository $translationsRepository): void
    {
        $sourcePath = $this->argument('sourcePath');
        $locale = $this->argument('locale');
        $defaultColumn = $this->argument('defaultColumn');
        $translatedColumn = $this->argument('translatedColumn');
        if (
            !$this->confirm(
                "This will overwrite the existing translations for the locale $locale"
            )
        ) {
            $this->error('Aborting import');
            return;
        }
        $this->info('Importing translations from a csv file');
        $this->table(
            ['Source path', 'Locale', 'Default column', 'Translated column'],
            [[$sourcePath, $locale, $defaultColumn, $translatedColumn]]
        );

        // Read the CSV file
        $csvContent = file_get_contents($sourcePath);
        if (!$csvContent) {
            throw new \Exception('Failed to read the CSV file');
        }
        $lines = explode(PHP_EOL, $csvContent);

        // Extract the header and convert it into a collection.
        $header = collect(str_getcsv(array_shift($lines)));

        // Transform csv content in to translations
        $translations = collect($lines)
            // Map through the rows and combine them with the header to produce the final collection.
            ->map(fn($row) => $header->combine(str_getcsv($row)))
            // Filter out rows with empty default values
            ->filter(fn($row) => !!$row[$defaultColumn])
            // Create a key-value pair from the default and translated columns
            ->mapWithKeys(
                fn($row) => [$row[$defaultColumn] => $row[$translatedColumn]]
            )
            ->toArray();

        try {
            $translationsRepository->save($locale, $translations);
        } catch (\Exception $e) {
            $this->error('Failed to save translations');
            $this->error($e->getMessage());
        }
    }
}
