<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Spatie\Permission\Models\Role;

use function Laravel\Prompts\select;

class AssignRole extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'assign:role';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Assign role to user';

    /**
     * Execute the console command.
     */
    public function handle(): void
    {
        $userId = select(
            label: 'Select user',
            options: User::query()->pluck('name', 'id')
        );

        $roleId = select(
            label: 'Select role',
            options: Role::query()->pluck('name', 'id')
        );

        $user = User::find($userId);
        $role = Role::find($roleId);

        if ($user && $role) {
            $user->assignRole($role);
            $this->info("Role {$role->name} assigned to {$user->name}");
        } else {
            $this->error('Invalid user or role selection.');
        }
    }
}
