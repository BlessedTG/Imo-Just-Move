<?php

namespace App\Console\Commands;

use App\Actions\ImportFeedback as ImportFeedbackAction;
use Illuminate\Console\Command;

class ImportFeedback extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:import-feedback';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create feedback items from form submissions';

    /**
     * Execute the console command.
     */
    public function handle(ImportFeedbackAction $action): void
    {
        $this->info('Executing import feedback command...');
        $action->handle();
    }
}
