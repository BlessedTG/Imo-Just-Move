<?php

namespace App\Console\Commands;

use App\Actions\ImportReferralRequests as ImportReferralRequestsAction;
use Illuminate\Console\Command;

class ImportReferralRequests extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:import-referral-requests';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create referrals from referral_form submissions';

    /**
     * Execute the console command.
     */
    public function handle(ImportReferralRequestsAction $action): void
    {
        $this->info('Executing import referral requests command...');
        $action->handle();
    }
}
