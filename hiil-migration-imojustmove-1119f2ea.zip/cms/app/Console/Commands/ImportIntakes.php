<?php

namespace App\Console\Commands;

use App\Actions\ImportIntakes as ImportIntakesAction;
use Illuminate\Console\Command;

class ImportIntakes extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:import-intakes';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle(ImportIntakesAction $action): void
    {
        $this->info('Executing import intakes command...');
        $action->handle();
    }
}
