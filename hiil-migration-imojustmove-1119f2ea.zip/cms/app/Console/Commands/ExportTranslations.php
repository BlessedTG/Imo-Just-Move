<?php

namespace App\Console\Commands;

use App\Translations;
use App\TranslationsRepository;
use Illuminate\Console\Command;

class ExportTranslations extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:export-translations';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export translations to a csv file';

    /**
     * Execute the console command.
     */
    public function handle(TranslationsRepository $translationsRepository): void
    {
        $translations = $translationsRepository->get('en');

        $this->exportToCsv($translations);
    }

    protected function exportToCsv(Translations $translations): void
    {
        $this->info('Exporting translations to a csv file');

        $handle = fopen('translations.csv', 'w');
        if (!$handle) {
            throw new \Exception('Failed to open file for writing');
        }

        // Write header
        fputcsv($handle, ['default_value', 'translated_value']);

        // Write translations
        foreach ($translations->toArray() as $key => $value) {
            fputcsv($handle, [$value, '']);
        }

        fclose($handle);

        $this->info('Translations exported successfully to translations.csv');
    }
}
