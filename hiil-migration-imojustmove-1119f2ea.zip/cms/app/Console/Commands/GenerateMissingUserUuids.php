<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class GenerateMissingUserUuids extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:generate-missing-user-uuids';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Generates uuids for users that are missing them';

    /**
     * Execute the console command.
     */
    public function handle(): void
    {
        DB::transaction(function () {
            // Generate UUID for existing users
            DB::table('users')
                ->whereNull('uuid')
                ->get()
                ->each(function ($user) {
                    DB::table('users')
                        ->where('id', $user->id)
                        ->update(['uuid' => Str::uuid()]);
                });
        });
    }
}
