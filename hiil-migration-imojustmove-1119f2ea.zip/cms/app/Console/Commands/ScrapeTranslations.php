<?php

namespace App\Console\Commands;

use App\TranslationsRepository;
use Illuminate\Console\Command;

class ScrapeTranslations extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:scrape-translations';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Scrape default translations from php files';

    /**
     * Execute the console command.
     */
    public function handle(TranslationsRepository $translationsRepository): void
    {
        // Looking for files in the app/Nova directory and its subdirectories

        /** @var array<int, string> */
        $novaFiles = glob(app_path('Nova/{,*/,*/*/,*/*/*/}*.php'), GLOB_BRACE);
        $translations = [];

        // Process Nova files
        foreach ($novaFiles as $file) {
            $content = file_get_contents($file);
            if (!$content) {
                continue;
            }
            if (preg_match_all("/__\('([^']+)'\)/", $content, $matches)) {
                $translations = array_merge($translations, $matches[1]);
            }
            // Also match double quoted strings
            if (preg_match_all('/__\("([^"]+)"\)/', $content, $matches)) {
                $translations = array_merge($translations, $matches[1]);
            }
        }

        // Remove duplicates and sort
        $translations = array_unique($translations);
        sort($translations);

        $translationsRepository->save(
            'en',
            collect($translations)
                ->mapWithKeys(
                    fn($translation) => [$translation => $translation]
                )
                ->toArray()
        );
    }
}
