<?php

namespace App\Console\Commands;

use App\Actions\ScanAndGenerateScaledImages;
use Illuminate\Console\Command;

class GenerateScaledImagesCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'media:generate-scaled-images';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Scan all media items and generate scaled images for those without them';

    /**
     * Execute the console command.
     *
     * @param ScanAndGenerateScaledImages $action
     * @return int
     */
    public function handle(ScanAndGenerateScaledImages $action): int
    {
        $this->info(
            'Starting to scan media items for scaled image generation...'
        );

        $stats = $action->execute();

        $this->info('Scan completed with the following results:');
        $this->table(
            ['Total', 'Processed', 'Skipped', 'Errors'],
            [
                [
                    $stats['total'],
                    $stats['processed'],
                    $stats['skipped'],
                    $stats['errors'],
                ],
            ]
        );

        if ($stats['processed'] > 0) {
            $this->info(
                'Image scaling jobs have been dispatched to the queue.'
            );
            $this->info(
                'Make sure your queue worker is running to process them.'
            );
        }

        return Command::SUCCESS;
    }
}
