<?php
/**
 * @author BadinanSoft
 * @package BadinanSoft\LanguageSwitch
 * @license MIT
 * @link https://badinansoft.com
 */

return [
    /**
     * List of languages that your application supports
     * array <string, string>
     */
    'supported-languages' => match (env('APP_LANGUAGES', 'en')) {
        'ar' => ['ar' => 'Arabic'],
        'en' => ['en' => 'English'],
        'ar,en' => ['ar' => 'Arabic', 'en' => 'English'],
        'en,ar' => ['en' => 'English', 'ar' => 'Arabic'],
        default => ['en' => 'English', 'ar' => 'Arabic'],
    },

    /**
     * Languages That need RTL support
     * string
     */
    'rtl-languages' => ['ar'],
];
