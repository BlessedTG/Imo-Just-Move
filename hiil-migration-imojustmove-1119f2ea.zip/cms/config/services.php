<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'google' => [
        'recaptcha' => [
            'secret_key' => env('GOOGLE_RECAPTCHA_SECRET_KEY', ''),
            'minimum_score' => env('GOOGLE_RECAPTCHA_MINIMUM_SCORE', 0.5),
            'recaptcha_field_name' => env(
                'GOOGLE_RECAPTCHA_FIELD_NAME',
                'g-recaptcha-response'
            ),
        ],
    ],

    'honeypot' => [
        'field_name' => env('HONEYPOT_FIELD_NAME', 'h o n e y p o t'),
    ],

    'postmark' => [
        'token' => env('POSTMARK_TOKEN'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],
];
