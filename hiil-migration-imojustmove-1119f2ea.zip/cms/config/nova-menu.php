<?php

return [
    /*
    |------------------|
    | Required options |
    |------------------|
    */

    /*
    |--------------------------------------------------------------------------
    | Table names
    |--------------------------------------------------------------------------
    */

    'menus_table_name' => 'nova_menu_menus',
    'menu_items_table_name' => 'nova_menu_menu_items',

    /*
    |--------------------------------------------------------------------------
    | Locales
    |--------------------------------------------------------------------------
    |
    | Set all the available locales as either [key => name] pairs, a closure
    | or a callable (ie 'locales' => 'nova_get_locales').
    |
    */

    'locales' => match (env('APP_LANGUAGES', 'en')) {
        'ar' => ['ar' => 'Arabic'],
        'en' => ['en' => 'English'],
        'ar,en' => ['ar' => 'Arabic', 'en' => 'English'],
        'en,ar' => ['en' => 'English', 'ar' => 'Arabic'],
        default => ['en' => 'English', 'ar' => 'Arabic'],
    },

    /*
    |--------------------------------------------------------------------------
    | Menus
    |--------------------------------------------------------------------------
    |
    | Set all the possible menus in a keyed array of arrays with the options
    | 'name' and optionally 'menu_item_types' and unique.
    /  Unique is true by default
    |
    | For example: ['header' => ['name' => 'Header', 'unique' => true, 'menu_item_types' => []]]
    |
    */

    'menus' => [
        'main' => [
            'name' => 'Main menu',
            'menu_item_types' => [
                \Grrr\Pages\MenuItemTypes\PageMenuItem::class,
            ],
        ],
        'footerPrimary' => [
            'name' => 'Footer primary menu',
            'menu_item_types' => [
                \Grrr\Pages\MenuItemTypes\PageMenuItem::class,
                \App\MenuItemTypes\MenuItemHeaderType::class,
            ],
        ],
        'footerSecondary' => [
            'name' => 'Footer secondary menu',
            'menu_item_types' => [
                \Grrr\Pages\MenuItemTypes\PageMenuItem::class,
                \App\MenuItemTypes\MenuItemHeaderType::class,
            ],
        ],
        'footerService' => [
            'name' => 'Footer service menu',
            'key' => 'footerService',
            'menu_item_types' => [
                \Grrr\Pages\MenuItemTypes\PageMenuItem::class,
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Menu item types
    |--------------------------------------------------------------------------
    |
    | Set all the available menu item types as an array.
    |
    */

    'menu_item_types' => [
        \Outl1ne\MenuBuilder\MenuItemTypes\MenuItemTextType::class,
        \Outl1ne\MenuBuilder\MenuItemTypes\MenuItemStaticURLType::class,
    ],

    /*
    |--------------------------------|
    | Optional configuration options |
    |--------------------------------|
    */
    'show_duplicate' => true,

    'collapsed_as_default' => true,

    /*
    |--------------------------------------------------------------------------
    | Resource
    |--------------------------------------------------------------------------
    |
    | Optionally override the original Menu resource.
    |
    */

    'resource' => Outl1ne\MenuBuilder\Nova\Resources\MenuResource::class,

    /*
    |--------------------------------------------------------------------------
    | Menu Model
    |--------------------------------------------------------------------------
    |
    | Optionally override the original Menu model.
    |
    */

    'menu_model' => Outl1ne\MenuBuilder\Models\Menu::class,

    /*
    |--------------------------------------------------------------------------
    | MenuItem Model
    |--------------------------------------------------------------------------
    |
    | Optionally override the original Menu Item model.
    |
    */

    'menu_item_model' => Outl1ne\MenuBuilder\Models\MenuItem::class,

    /*
    |--------------------------------------------------------------------------
    | Auto-load migrations
    |--------------------------------------------------------------------------
    |
    | Allow auto-loading of migrations (without the need to publish them)
    |
    */

    'auto_load_migrations' => true,
];
