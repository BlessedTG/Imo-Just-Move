<?php

return [
    'languages' => [
        'en' => 'English',
        'ar' => 'Arabic',
    ],
    'defaultLanguage' => 'en',

    // Disable for unilingual websites.
    'allowTranslations' => false, // TODO: Make Nova Pages Tool queries more performant and enable this again

    'pageResourceClass' => \App\Nova\Page::class,

    'templates' => [
        \App\Models\Page::TEMPLATE_DEFAULT,
        \App\Models\Page::TEMPLATE_HOME,
        \App\Models\Page::TEMPLATE_WHAT_TO_EXPECT,
        \App\Models\Page::TEMPLATE_PROBLEM_IDENTIFICATION,
    ],

    'defaultTemplate' => \App\Models\Page::TEMPLATE_DEFAULT,

    'seoImagesDisk' => env('SEO_IMAGE_DISK', 'public'),

    // The URL to the front-end. Use this when you're using Nova as a headless
    // CMS and the links from the CMS to the front-end should go to another
    // host.
    'frontendUrl' => env('FRONTEND_URL', ''),
];
