<?php

return [
    'flexible_content' => [
        /*
        |--------------------------------------------------------------------------
        | Media suffix prefix
        |--------------------------------------------------------------------------
        |
        | This value is used to prefix the suffix of media collections used by
        | flex blocks. Using this prefix we can recognize flex block media in
        | the JSON API. See also App\Nova\Flexible\Concerns\HasMediaLibrary.
        |
        */

        'media_suffix_prefix' => '_flex_',
    ],
    /*
    |--------------------------------------------------------------------------
    | Frontend URL
    |--------------------------------------------------------------------------
    |
    | The URL to your frontend. In a headless architecture this is not the
    | URL where your CMS is located!
    |
    */
    'frontend_url' => env('FRONTEND_URL', 'https://example.com'),

    /**
     * Publish strategy. This determines which tools we use to publish from Nova
     *
     * Possible values:
     * - 'github'
     * - 'local'
     */
    'static_site_publish_strategy' => env(
        'STATIC_SITE_PUBLISH_STRATEGY',
        'github'
    ),

    /**
     * Static site public path
     *
     * Only used when the static site publish strategy is 'local'.
     */
    'static_site_public_path' => env('STATIC_SITE_PUBLIC_PATH'),

    /*
    |--------------------------------------------------------------------------
    | Form submissions database
    |--------------------------------------------------------------------------
    |
    | The database used to store form submissions. This can be either 'eloquent'
    | 'log' or 'in-memory'
    |
    */
    'form_submissions_database' => env('FORM_SUBMISSIONS_DATABASE', 'log'),

    /**
     * Queue work via cron job
     */
    'queue_worker' => [
        'via_cron' => env('QUEUE_WORKER_VIA_CRON', false),
        'node_bin_dir' => env(
            'QUEUE_WORKER_NODE_BIN_DIR_PATH',
            '/usr/local/bin/'
        ),
        'npm_path' => env('QUEUE_WORKER_NPM_PATH', '/usr/local/bin/npm'),
    ],
];
