<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', fn() => redirect('/admin'));

Route::middleware('auth')->get('/frontend-login', function (Request $request) {
    $redirectUrl =
        config('app.frontend_url') .
        '/frontend-login/?intended=' .
        $request->get('intended');

    return redirect($redirectUrl);
});
Route::get('/frontend-logout', function () {
    Auth::logout();
    return redirect(config('app.frontend_url'));
});

Route::middleware('auth')->get('/users/me', function (Request $request) {
    $user = $request->user();
    $userData = [
        'uuid' => $user->uuid,
        'name' => $user->name,
        'roles' => $user->roles->pluck('name')->toArray(),
    ];
    return response()->json($userData);
});
