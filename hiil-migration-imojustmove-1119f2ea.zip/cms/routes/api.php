<?php

use App\FormHandler\Http\Controllers\SubmitForm;
use Illuminate\Support\Facades\Route;
use LaravelJsonApi\Laravel\Facades\JsonApiRoute;
use LaravelJsonApi\Laravel\Http\Controllers\JsonApiController;
use LaravelJsonApi\Laravel\Routing\Relationships;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::middleware(['recaptcha', 'honeypot'])->post(
    'v1/submit',
    SubmitForm::class
);

JsonApiRoute::server('v1')
    ->prefix('v1')
    ->middleware('auth:sanctum')
    ->resources(function ($server) {
        $server
            ->resource('menus', JsonApiController::class)
            ->readOnly()
            ->relationships(function (Relationships $relationships) {
                $relationships->hasMany('menu-items')->readOnly();
            });
        $server->resource('menu-items', JsonApiController::class)->readOnly();
        $server
            ->resource('pages', JsonApiController::class)
            ->readOnly()
            ->relationships(function (Relationships $relationships) {
                $relationships->hasMany('translations')->readOnly();
            });
        $server->resource('settings', JsonApiController::class)->readOnly();

        $server->resource('problems', JsonApiController::class)->readonly();
        $server
            ->resource('problem-categories', JsonApiController::class)
            ->relationships(function (Relationships $relationships) {
                $relationships->hasMany('problems')->readOnly();
            })
            ->readonly();
        $server
            ->resource('outcomes', JsonApiController::class)
            ->readonly()
            ->relationships(function (Relationships $relationships) {
                $relationships->hasMany('referrals')->readOnly();
                $relationships->hasOne('problem')->readOnly();
            });
        $server
            ->resource('referrals', JsonApiController::class)
            ->readOnly()
            ->relationships(function (Relationships $relationships) {
                $relationships->hasOne('region')->readOnly();
            });
        $server->resource('feedback', JsonApiController::class)->only('store');
        $server
            ->resource('questionnaires', JsonApiController::class)
            ->readonly();
        $server->resource('regions', JsonApiController::class)->readonly();
        $server
            ->resource('target-audiences', JsonApiController::class)
            ->readonly();
    });
