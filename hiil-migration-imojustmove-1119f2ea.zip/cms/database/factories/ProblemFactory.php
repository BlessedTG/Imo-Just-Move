<?php

namespace Database\Factories;

use App\Models\Page;
use App\Models\ProblemCategory;
use App\Models\TargetAudience;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Problem>
 */
class ProblemFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => $this->faker->sentence,
            'description' => $this->faker->paragraph,
            'status' => Page::STATUS_PUBLISHED,
            'language' => 'en',
            'know_your_rights' => $this->faker->randomHtml(),
            'problem_category_id' => ProblemCategory::factory()->create()->id,
            'target_audience_id' => TargetAudience::factory()->create()->id,
        ];
    }
}
