<?php

namespace Database\Factories;

use App\Models\TargetAudience;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Questionnaire>
 */
class QuestionnaireFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => $this->faker->sentence,
            'language' => 'en',
            'target_audience_id' => TargetAudience::factory()->create()->id,
        ];
    }
}
