<?php

namespace Database\Factories;

use App\Models\Problem;
use App\Models\TargetAudience;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Outcome>
 */
class OutcomeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'title' => $this->faker->sentence,
            'description' => $this->faker->sentence,
            'language' => 'en',
            'problem_id' => Problem::factory()->create()->id,
            'content' => [],
            'target_audience_id' => TargetAudience::factory()->create()->id,
        ];
    }
}
