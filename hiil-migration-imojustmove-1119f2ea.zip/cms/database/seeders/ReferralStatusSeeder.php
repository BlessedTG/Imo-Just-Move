<?php

namespace Database\Seeders;

use App\Languages;
use App\Models\ReferralStatus;
use Illuminate\Database\Seeder;

class ReferralStatusSeeder extends Seeder
{
    public function __construct(protected Languages $languages) {}

    public function run(): void
    {
        // When there are no referral statuses in the database,
        // we create one that is the default referral status.
        if (\App\Models\ReferralStatus::count() === 0) {
            $label = collect($this->languages->all())
                ->mapWithKeys(fn($language) => [$language => 'New'])
                ->toArray();
            ReferralStatus::create([
                'label' => $label,
                'is_default' => true,
            ]);
        }
    }
}
