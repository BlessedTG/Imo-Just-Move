<?php

namespace Database\Seeders;

use App\Languages;
use App\SettingKey;
use Gwd\SeoMeta\Helper\Seo;
use Illuminate\Database\Seeder;
use Illuminate\Support\Collection;
use Outl1ne\NovaSettings\Models\Settings as SettingsModel;

/**
 * Seeder for setting defaults.
 *
 * I have added this mainly because settings defaults to nova settings is not working
 * when it's translatable. And it is a lot of work filling in the defaults manually.
 *
 * This seeder will fill in the defaults for the settings that are missing, or have an empty value.
 * Important: These defaults are English and will be used for all configured languages.
 *
 */
class SettingsSeeder extends Seeder
{
    protected array $defaults = [
        # General
        SettingKey::BackButtonLabel->value => 'Go back',
        SettingKey::EmailShareSubject->value => 'Share this page',

        # Problems
        SettingKey::ProblemDesiredOutcomesTitle->value =>
            'Choose your desired outcome',
        SettingKey::ProblemDesiredOutcomesDescription->value => 'Make a choice',

        # Step titles
        SettingKey::FirstStepLabel->value => 'Determine your issue',
        SettingKey::SecondStepLabel->value => 'Know your rights',
        SettingKey::ThirdStepLabel->value => 'Choose your desired outcome',
        SettingKey::FourthStepLabel->value => 'Our advice',

        # Outcomes
        SettingKey::OutcomeHelpTitle->value =>
            'Here are people that can help you:',

        # Referral filter
        SettingKey::ReferralFilterLabel->value => 'All regions',
        SettingKey::ReferralFilterAllOption->value => 'All',

        # Notification overlay content
        SettingKey::NotificationOverlayTitle->value =>
            'First page visit notification',
        SettingKey::NotificationOverlayDescription->value =>
            'First page visit description',
        SettingKey::NotificationOverlayChangeButtonLabel->value =>
            'This is not the content for me',
        SettingKey::NotificationOverlayResumeButtonLabel->value => 'Continue',

        # Emergency overlay content
        SettingKey::EmergencyOverlayTitle->value => 'Emergency Call',
        SettingKey::EmergencyOverlayDescription->value =>
            'Are you in an emergency situation?',
        SettingKey::EmergencyOverlayLinkLabel->value => 'Make emergency call',
        SettingKey::EmergencyOverlayPhoneNumber->value => '',

        # Close questionnaire overlay content
        SettingKey::CloseQuestionnaireOverlayTitle->value =>
            'Close questionnaire',
        SettingKey::CloseQuestionnaireOverlayDescription->value =>
            'Are you sure you want to stop?',
        SettingKey::CloseQuestionnaireOverlayLinkLabel->value =>
            'Close questionnaire',

        # Questionnaire
        SettingKey::QuestionnaireRestartButtonLabel->value => 'Restart',
        SettingKey::QuestionnaireResultsTitle->value => 'View results',
        SettingKey::QuestionnaireOutcomeButtonLabel->value => 'Show outcome',
        SettingKey::QuestionnaireAnalysisTitle->value => 'Analysis',
        SettingKey::QuestionnaireResultSubtitle->value =>
            'It seems you are dealing with',
        SettingKey::QuestionnaireNoResultTitle->value => 'No results',
        SettingKey::QuestionnaireRequestAssistanceButtonLabel->value =>
            'Request assistance',

        # Referral form
        SettingKey::ReferralFormTitle->value => 'Sign up as referral',
        SettingKey::ReferralFormDescription->value => '',

        SettingKey::ReferralFormSuccessTitle->value => 'Success!',
        SettingKey::ReferralFormSuccessMessage->value =>
            'The form has been submitted successfully. A representative will get in touch with you.',
        SettingKey::ReferralFormErrorTitle->value => 'Error!',
        SettingKey::ReferralFormErrorMessage->value =>
            'The form has not been successfully submitted. Please see if you have filled in all the forms correctly.',

        SettingKey::ReferralFormNameLabel->value => 'Name',
        SettingKey::ReferralFormNameInstruction->value => '',
        SettingKey::ReferralFormSurnameLabel->value => 'Surname',
        SettingKey::ReferralFormSurnameInstruction->value => '',
        SettingKey::ReferralFormPhoneNumberLabel->value => 'Phone number',
        SettingKey::ReferralFormPhoneNumberInstruction->value => '',
        SettingKey::ReferralFormEmailLabel->value => 'Email',
        SettingKey::ReferralFormEmailInstruction->value => '',
        SettingKey::ReferralFormLocationLabel->value => 'Location',
        SettingKey::ReferralFormLocationInstruction->value => '',
        SettingKey::ReferralFormExpertiseLabel->value => 'Expertise',
        SettingKey::ReferralFormExpertiseInstruction->value => '',
        SettingKey::ReferralFormRoleLabel->value => 'Role',
        SettingKey::ReferralFormRoleInstruction->value => '',
        SettingKey::ReferralFormEnrolmentNumberLabel->value => 'Enrolment',
        SettingKey::ReferralFormEnrolmentNumberInstruction->value => '',
        SettingKey::ReferralFormAdditionalMessageLabel->value =>
            'Anything else that you would like us to know?',
        SettingKey::ReferralFormAdditionalMessageInstruction->value => '',
        SettingKey::ReferralFormSubmitButtonLabel->value => 'Submit',

        # Intake form
        SettingKey::IntakeFormTitle->value => 'Save intake',
        SettingKey::IntakeFormDescription->value => '',

        SettingKey::IntakeFormSuccessTitle->value => 'Success!',
        SettingKey::IntakeFormSuccessMessage->value =>
            'The form has been submitted successfully. A representative will get in touch with you.',
        SettingKey::IntakeFormErrorTitle->value => 'Error!',
        SettingKey::IntakeFormErrorMessage->value =>
            'The form has not been successfully submitted. Please see if you have filled in all the forms correctly.',

        SettingKey::IntakeFormNameLabel->value => 'Name',
        SettingKey::IntakeFormNameInstruction->value => '',
        SettingKey::IntakeFormSurnameLabel->value => 'Surname',
        SettingKey::IntakeFormSurnameInstruction->value => '',
        SettingKey::IntakeFormPhoneNumberLabel->value => 'Phone number',
        SettingKey::IntakeFormPhoneNumberInstruction->value => '',
        SettingKey::IntakeFormEmailLabel->value => 'Email',
        SettingKey::IntakeFormEmailInstruction->value => '',
        SettingKey::IntakeFormLocationLabel->value => 'Location',
        SettingKey::IntakeFormLocationInstruction->value => '',
        SettingKey::IntakeFormAdditionalMessageLabel->value =>
            'Anything else that you would like us to know?',
        SettingKey::IntakeFormAdditionalMessageInstruction->value => '',
        SettingKey::IntakeFormSubmitButtonLabel->value => 'Submit',
        SettingKey::IntakeFormConfirmationEmailSubject->value =>
            'Confirmation of your intake',
        SettingKey::IntakeFormConfirmationEmailBody->value =>
            'Your reference id is {reference_id}.',

        # Request support form (form inputs are the same as in the intake form)
        SettingKey::RequestSupportFormTitle->value => 'Request support',
        SettingKey::RequestSupportFormDescription->value => '',

        # Feedback form
        SettingKey::FeedbackFormTitle->value => 'Give feedback',
        SettingKey::FeedbackFormDescription->value => '',

        SettingKey::FeedbackFormSuccessTitle->value => 'Success!',
        SettingKey::FeedbackFormSuccessMessage->value =>
            'Thank you for your feedback',
        SettingKey::FeedbackFormErrorTitle->value => 'Error!',
        SettingKey::FeedbackFormErrorMessage->value =>
            'The form has not been successfully submitted. Please see if you have filled in all the forms correctly.',

        SettingKey::FeedbackFormNegativeLabel->value => 'Negative',
        SettingKey::FeedbackFormPositiveLabel->value => 'Positive',
        SettingKey::FeedbackFormMessageLabel->value =>
            'Did you find the information on this page useful?',
        SettingKey::FeedbackFormMessageInstruction->value => '',

        SettingKey::FeedbackFormSubmitButtonLabel->value => 'Submit',

        # User login
        SettingKey::LoginButtonLabel->value => 'Login',
        SettingKey::LoggedInAs->value => 'Logged in as',
        SettingKey::LoginSuspenseMessage->value =>
            'Please wait while we log you in',
        SettingKey::LogoutButtonLabel->value => 'Logout',
        SettingKey::LoggingOutMessage->value =>
            'Please wait while we log you out',
        SettingKey::LoginOverlayTitle->value => 'Login to your account',
        SettingKey::NotLoggedIn->value => 'You are not logged in',

        # Protected page
        SettingKey::ProtectedPageNotAuthorizedMessage->value =>
            'You are not authorized to view this page',
        SettingKey::ProtectedPageHomeButtonText->value => 'Go to homepage',

        # Cookies
        SettingKey::CookieBannerTitle->value => 'Cookies',
        SettingKey::CookieBannerIntroduction->value =>
            'This site uses cookies. Read our Cookie Policy for more details.',
        SettingKey::CookieBannerFunctionalCookiesName->value =>
            'Functional cookies',
        SettingKey::CookieBannerFunctionalCookiesDescription->value =>
            'Required for core functionality and basic analytics without personal data. These cannot be disabled.',
        SettingKey::CookieBannerMarketingCookiesName->value =>
            'Marketing cookies',
        SettingKey::CookieBannerMarketingCookiesDescription->value =>
            'Used to display embedded YouTube videos.',
        SettingKey::CookieBannerAcceptAllLabel->value => 'Accept all',
        SettingKey::CookieBannerSavePreferencesLabel->value =>
            'Save preferences',
        SettingKey::CookieBannerChangeConsentLinkLabel->value =>
            'Change cookie preferences',
        SettingKey::CookieBannerMarketingCookiesRequiredMessage->value =>
            'Accept marketing cookies to view this content',
    ];

    public function __construct(protected Languages $languages) {}

    /**
     * Run the database seeds.
     */
    public function run(SettingsSeederParameter $param): void
    {
        $this->defaults()->each(function (string $value, string $key) use (
            $param
        ) {
            /**
             * @var SettingsModel|null $setting
             */
            $setting = SettingsModel::find($key);
            if ($setting === null) {
                $this->createSetting($key, $value);
                return;
            }
            $setting = match ($param) {
                SettingsSeederParameter::Overwrite => $this->setValue($setting),
                SettingsSeederParameter::OverwriteIfEmpty
                    => $this->setValueIfEmpty($setting),
                default => $setting,
            };
            $setting->save();
        });
    }

    /**
     * Get the default settings.
     *
     * @return Collection<string, string>
     */
    public function defaults(): Collection
    {
        return collect($this->defaults);
    }

    protected function createSetting(string $key, string $value): SettingsModel
    {
        $setting = new SettingsModel([
            'key' => $key,
            'value' => $this->makeValueMultilingual($value),
        ]);
        $setting->save();
        return $setting;
    }

    protected function setValue(SettingsModel $setting): SettingsModel
    {
        $setting->value = $this->makeValueMultilingual(
            $this->defaults[$setting->key]
        );
        return $setting;
    }

    /**
     * If the settings value is empty (falsy), set it to the default value.
     * Null check is done for each language.
     */
    protected function setValueIfEmpty(SettingsModel $setting): SettingsModel
    {
        /** @var array<string, string|null> $decodedValue */
        $decodedValue = json_decode($setting->value, true);
        foreach ($this->languages->all() as $language) {
            if (empty($decodedValue[$language])) {
                $decodedValue[$language] = $this->defaults[$setting->key];
            }
        }
        $setting->value = json_encode($decodedValue);
        return $setting;
    }

    protected function makeValueMultilingual(string $value): array
    {
        $languages = $this->languages->all();
        $valueObject = [];
        foreach ($languages as $language) {
            $valueObject[$language] = $value;
        }
        return $valueObject;
    }
}
