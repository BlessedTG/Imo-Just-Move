<?php

namespace Database\Seeders;

use App\Models\User;
use App\Permissions;
use App\Roles;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use ReflectionClass;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;

/**
 * Seeds the database with permissions defined it the Permissions class
 * and assigns all permissions to the superadmin role.
 *
 * This seeder also seeds roles defined in the Roles class.
 * But Nova users will be able to create new roles in the CMS.
 *
 * It also create a 'fake' user with the site generator role.
 * The site generator role should have the permission to view site content.
 *
 */
class RolesAndPermissionsSeeder extends Seeder
{
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[
            \Spatie\Permission\PermissionRegistrar::class
        ]->forgetCachedPermissions();

        $this->seedRoles();
        $this->seedPermissions();

        // Give superadmin all permissions
        $superadmin = Role::firstOrCreate([
            'name' => Roles::SUPERADMIN_ROLE,
        ]);
        $superadmin->givePermissionTo(Permission::all());

        // Create a user that have the site generator role
        $siteGeneratorUser = User::firstOrCreate(
            [
                'name' => 'Site generator',
                'email' => 'site-generator@fake-email.com',
            ],
            [
                'password' => bcrypt(Str::random(16)),
            ]
        );
        $siteGeneratorRole = Role::firstOrCreate([
            'name' => Roles::SITE_GENERATOR_ROLE,
        ]);
        $siteGeneratorRole->givePermissionTo(Permissions::VIEW_SITE_CONTENT);
        $siteGeneratorUser->assignRole($siteGeneratorRole);
    }

    protected function seedRoles(): void
    {
        collect(Roles::ALL)->each(function ($role) {
            Role::firstOrCreate([
                'name' => $role,
            ]);
        });
    }

    protected function seedPermissions(): void
    {
        collect(Permissions::ALL)->each(function ($permission) {
            Permission::firstOrCreate([
                'group' => 'All',
                'name' => $permission,
            ]);
        });
    }
}
