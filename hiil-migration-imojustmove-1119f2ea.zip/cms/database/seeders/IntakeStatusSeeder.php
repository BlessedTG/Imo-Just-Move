<?php

namespace Database\Seeders;

use App\Languages;
use App\Models\IntakeStatus;
use Illuminate\Database\Seeder;

class IntakeStatusSeeder extends Seeder
{
    public function __construct(protected Languages $languages) {}

    public function run(): void
    {
        // When there are no intake statuses in the database,
        // we create one that is the default intake status.
        if (\App\Models\IntakeStatus::count() === 0) {
            $label = collect($this->languages->all())
                ->mapWithKeys(fn($language) => [$language => 'New'])
                ->toArray();
            IntakeStatus::create([
                'label' => $label,
                'is_default' => true,
            ]);
        }
    }
}
