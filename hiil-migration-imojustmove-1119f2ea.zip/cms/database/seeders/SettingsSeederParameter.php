<?php namespace Database\Seeders;

enum SettingsSeederParameter
{
    case Overwrite; // Overwrite all settings
    case OverwriteIfEmpty; // Overwrite settings, but only if they are empty
    case Default; // Only create settings that are missing
}
