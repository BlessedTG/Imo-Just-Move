<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('intakes', function (Blueprint $table) {
            $table->dropColumn('client_name');
            $table->dropColumn('message');

            $table->string('name');
            $table->string('surname');
            $table->string('phone_number');
            $table->string('email')->nullable();
            $table->string('location');
            $table->string('problem_identified');
            $table->string('outcome');

            $table->text('additional_notes')->nullable();
            $table->string('reference_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('intakes', function (Blueprint $table) {
            $table->dropColumn('name');
            $table->dropColumn('surname');
            $table->dropColumn('phone_number');
            $table->dropColumn('email');
            $table->dropColumn('location');
            $table->dropColumn('problem_identified');
            $table->dropColumn('outcome');
            $table->dropColumn('additional_notes');
            $table->dropColumn('reference_id');

            $table->string('client_name');
            $table->text('message');
        });
    }
};
