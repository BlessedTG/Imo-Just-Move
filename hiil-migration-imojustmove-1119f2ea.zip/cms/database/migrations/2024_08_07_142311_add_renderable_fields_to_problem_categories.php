<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('problem_categories', function (Blueprint $table) {
            $table->string('slug');
            $table->string('language');

            $table->index(['slug', 'language']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('problem_categories', function (Blueprint $table) {
            $table->dropIndex(['slug', 'language']);

            $table->dropColumn('slug');
            $table->dropColumn('language');
        });
    }
};
