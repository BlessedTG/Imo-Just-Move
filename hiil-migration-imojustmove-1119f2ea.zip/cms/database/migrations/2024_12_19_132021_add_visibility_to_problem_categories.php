<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('problem_categories', function (Blueprint $table) {
            $table->string('visibility')->default('public');
            $table->string('allowed_role')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('problem_categories', function (Blueprint $table) {
            $table->dropColumn('visibility');
            $table->dropColumn('allowed_role');
        });
    }
};
