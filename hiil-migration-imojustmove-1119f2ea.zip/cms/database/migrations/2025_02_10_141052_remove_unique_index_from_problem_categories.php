<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        if (
            Schema::hasIndex(
                'problem_categories',
                ['slug', 'language', 'target_audience_id'],
                'unique'
            )
        ) {
            Schema::table('problem_categories', function (Blueprint $table) {
                $table->dropUnique(['slug', 'language', 'target_audience_id']);
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // We can't restore the unique index because it would be a duplicate key violation with the existing data
    }
};
