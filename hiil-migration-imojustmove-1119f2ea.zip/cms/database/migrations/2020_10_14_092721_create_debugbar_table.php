<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDebugbarTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('phpdebugbar', function (Blueprint $table) {
            $table->string('id')->primary()->index();
            $table->longText('data');
            $table->text('meta_utime');
            $table->text('meta_datetime');
            $table->text('meta_uri');
            $table->text('meta_ip');
            $table->text('meta_method');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('phpdebugbar');
    }
}
