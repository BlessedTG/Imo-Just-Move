<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /** Custom index name because Laravel's auto generated one is to long */
    const UNIQUE_INDEX_NAME = 'unique_slug_language_target_audience_problem_category';
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('problems', function (Blueprint $table) {
            $table
                ->unsignedBigInteger('target_audience_id')
                ->nullable(false)
                ->change();
        });

        Schema::table('problems', function (Blueprint $table) {
            $table->unique(
                [
                    'slug',
                    'language',
                    'target_audience_id',
                    'problem_category_id',
                ],
                self::UNIQUE_INDEX_NAME
            );
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('problems', function (Blueprint $table) {
            $table->dropUnique(self::UNIQUE_INDEX_NAME);
        });

        Schema::table('problems', function (Blueprint $table) {
            $table
                ->unsignedBigInteger('target_audience_id')
                ->nullable(true)
                ->change();
        });
    }
};
