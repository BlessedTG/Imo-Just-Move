<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('referrals', function (Blueprint $table) {
            // Change enrolment column
            $table->dropColumn('enrollment_number');
            $table->string('enrolment_number')->nullable();

            // Remove slug column
            $table->dropColumn('slug');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('referrals', function (Blueprint $table) {
            $table->dropColumn('enrolment_number');
            $table->bigInteger('enrollment_number')->nullable();

            $table->string('slug');
        });
    }
};
