<?php

use App\Languages;
use App\Models\TargetAudience;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $existingDefaultTargetAudience = TargetAudience::query()
            ->where('is_default', true)
            ->first();

        if ($existingDefaultTargetAudience) {
            logger('Default target audience already exists');
            return;
        }

        $languages = resolve(Languages::class);
        TargetAudience::create([
            'name' => $this->multiLingual($languages, 'Guest'),
            'is_default' => true,
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {}

    /**
     * Creates a multi-lingual associative array, where each language is mapped to the same value.
     *
     * @param Languages $languages
     * @param string $value
     * @return array<string,string>
     */
    protected function multiLingual(Languages $languages, string $value): array
    {
        return collect($languages->all())
            ->mapWithKeys(fn(string $language) => [$language => $value])
            ->toArray();
    }
};
