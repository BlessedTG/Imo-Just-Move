<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('questionnaires', function (Blueprint $table) {
            $table->dropIndex(['slug', 'language']);
            $table->foreignId('target_audience_id')->nullable()->constrained();
            $table->unique(['slug', 'language', 'target_audience_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (
            Schema::hasIndex(
                'questionnaires',
                ['slug', 'language', 'target_audience_id'],
                'unique'
            )
        ) {
            Schema::table('questionnaires', function (Blueprint $table) {
                $table->dropUnique(['slug', 'language', 'target_audience_id']);
            });
        }
        Schema::table('questionnaires', function (Blueprint $table) {
            $table->dropForeign(['target_audience_id']);
            $table->dropColumn('target_audience_id');
            $table->index(['slug', 'language']);
        });
    }
};
