<?php

use App\Models\Page;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('referrals', function (Blueprint $table) {
            $table->renameColumn('phonenumber', 'phone_number');
            $table->string('slug');
            $table->string('status')->default(Page::STATUS_DRAFT);
            $table->string('language')->default('en');

            $table->index(['slug', 'language']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('referrals', function (Blueprint $table) {
            $table->dropIndex(['slug', 'language']);
            $table->dropColumn('slug');
            $table->dropColumn('status');
            $table->dropColumn('language');
            $table->renameColumn('phone_number', 'phonenumber');
        });
    }
};
