<?php

use App\Models\ProblemCategory;
use App\Models\TargetAudience;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $existingDefaultTargetAudience = TargetAudience::query()
            ->where('is_default', true)
            ->first();

        if (!$existingDefaultTargetAudience) {
            logger('Default target audience does not exist');
            logger('Cannot set default target audience for outcomes');
            return;
        }

        DB::transaction(function () use ($existingDefaultTargetAudience) {
            ProblemCategory::query()
                ->whereNull('target_audience_id')
                ->update([
                    'target_audience_id' => $existingDefaultTargetAudience->id,
                ]);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {}
};
