<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('questions', function (Blueprint $table) {
            $table->dropForeign(['questionnaire_id']);
        });
        Schema::dropIfExists('questions');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::create('questions', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->foreignId('questionnaire_id')->constrained();
            $table->timestamps();
        });
    }
};
