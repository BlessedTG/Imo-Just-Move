<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('questionnaires', function (Blueprint $table) {
            $table
                ->unsignedBigInteger('target_audience_id')
                ->nullable(false)
                ->change();
        });

        Schema::table('questionnaires', function (Blueprint $table) {
            $table->unique(['slug', 'language', 'target_audience_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('questionnaires', function (Blueprint $table) {
            $table->dropUnique(['slug', 'language', 'target_audience_id']);
        });

        Schema::table('questionnaires', function (Blueprint $table) {
            $table
                ->unsignedBigInteger('target_audience_id')
                ->nullable(true)
                ->change();
        });
    }
};
