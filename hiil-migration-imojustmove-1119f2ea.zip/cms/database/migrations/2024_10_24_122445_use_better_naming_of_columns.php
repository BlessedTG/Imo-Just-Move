<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('referrals', function (Blueprint $table) {
            $table->renameColumn('field_of_expertise', 'expertise');
            $table->renameColumn('notes', 'additional_message');
        });
        Schema::table('intakes', function (Blueprint $table) {
            $table->renameColumn('additional_notes', 'additional_message');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('referrals', function (Blueprint $table) {
            $table->renameColumn('expertise', 'field_of_expertise');
            $table->renameColumn('additional_message', 'notes');
        });
        Schema::table('intakes', function (Blueprint $table) {
            $table->renameColumn('additional_message', 'additional_notes');
        });
    }
};
