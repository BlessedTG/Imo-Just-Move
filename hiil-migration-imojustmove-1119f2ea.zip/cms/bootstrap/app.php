<?php

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Sentry\Laravel\Integration;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up'
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'recaptcha' =>
                \App\FormHandler\Http\Middleware\VerifyGoogleReCaptcha::class,
            'honeypot' => \App\FormHandler\Http\Middleware\CheckHoneypot::class,
        ]);
        $middleware->web(\App\Http\Middleware\NoIndex::class);
        $middleware->web(
            \Badinansoft\LanguageSwitch\Http\Middleware\LanguageSwitch::class
        );
        $middleware->statefulApi();
    })
    ->withExceptions(function (Exceptions $exceptions) {
        Integration::handles($exceptions);
    })
    ->withSchedule(function (Schedule $schedule) {
        /**
         * @var array{"via_cron": boolean, "node_bin_dir": string, "npm_path": string} $queueWorkerConfig
         */
        $queueWorkerConfig = config('custom.queue_worker');
        if ($queueWorkerConfig['via_cron']) {
            logger(
                'Enable queue work via cron: ' . $queueWorkerConfig['via_cron']
            );
            // Run the queue worker every minute via cron
            $schedule
                ->command('queue:work --stop-when-empty --timeout=600')
                ->everyMinute()
                ->withoutOverlapping();
        }
        $schedule->command('debugbar:clear')->dailyAt('01:00');
        $schedule
            ->command('app:import-intakes')
            ->everyFiveMinutes()
            ->withoutOverlapping();
        $schedule
            ->command('app:import-feedback')
            ->everyFiveMinutes()
            ->withoutOverlapping();
        $schedule
            ->command('app:import-referral-requests')
            ->everyFiveMinutes()
            ->withoutOverlapping();
    })
    ->create();
