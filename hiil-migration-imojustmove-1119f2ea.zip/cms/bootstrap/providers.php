<?php

return [
    App\Providers\AuthServiceProvider::class,
    App\Providers\AppServiceProvider::class,
    App\Providers\EventServiceProvider::class,
    App\Providers\NovaServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
];
