<?php
/**
 * These slugs are used for generating frontend urls for renderable resources.
 */
return [
    'problems' => 'mushkila',
    'outcomes' => 'alnatayij',
    'problem-categories' => 'fiat-almushkila',
    'questionnaires' => 'aistibyan',
];
