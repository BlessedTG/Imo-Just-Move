<?php
/**
 * These slugs are used for generating frontend urls for renderable resources.
 */
return [
    'problems' => 'problems',
    'outcomes' => 'outcomes',
    'problem-categories' => 'problem-categories',
    'questionnaires' => 'questionnaires',
];
