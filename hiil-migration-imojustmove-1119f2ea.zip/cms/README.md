# HiiL CMS

The CMS for HiiL Justice Advise Tool.

## Table of Contents

- [Table of Contents](#table-of-contents)
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
    - [Users](#users)
- [Documentation](#documentation)
- [Resources](#resources)
- [Development](#development)
    - [Troubleshooting](#troubleshooting)
    - [Debugbar](#debugbar)
    - [History](#history)
    - [API](#api)

## Features

[Return To Top](#hiil-cms)

- NoIndex: Adds a `X-Robots-Tag: noindex` header when `APP_ENV` isn't production.
- [PHPUnit](#testing)
- PHPStan: `composer static-analysis`, change configuration in `phpstan.neon.dist`.
- Sentry: Add the Sentry DSN to `.env`: `SENTRY_LARAVEL_DSN=....`
- [Debugbar](#debugbar): Helps you debug during development

## Requirements

[Return To Top](#hiil-cms)

- PHP 8.2
- MySQL (5.6, 5.7, 8) or SQLite
- npm

Create a Laravel Nova license key at https://nova.laravel.com.
Add this key to the environment variables as `NOVA_LICENSE_KEY` and to your GitHub secrets if you want to deploy this from GitHub.

## Installation

[Return To Top](#hiil-cms)

```shell script
git clone ...
composer install
npm install
cp .env.example .env
php artisan key:generate
# Configure DATABASE_* variables in .env
php artisan migrate --seed
php artisan storage:link
php artisan serve --port 8000
open http://127.0.0.1:8000
```

## Users

### Add yourself as user

```shell
php artisan nova:user
```

### Assign role to user

Run this command to assign a role to a user. Select 'Superadmin' to give the user all permissions.

```shell script
php artisan assign:role
```

## Documentation

### Site Variant

The HiiL Justice Advice Tool is being developed for use in multiple countries. These countries are defined as 'SITE_VARIANT' in the CMS's .env file. Each site variant has its own logo and theme. These variants are:

- Tunisia
- Nigeria-Ogun-State
- Nigeria-Imo-State

```
# Site variant (tunisia, nigeria-ogun-state, and nigeria-imo-state)
SITE_VARIANT=nigeria-imo-state
```

### Media Scaling

The application includes a command to generate scaled versions of images for improved performance:

```bash
php artisan media:generate-scaled-images
```

This command scans all media items in the library and generates optimized, scaled versions at predefined widths for any images that don't already have them.

When executed, the command provides statistics about the process including total images scanned, processed, skipped, and any errors encountered. Scaling jobs are dispatched to the queue, so ensure your queue worker is running to process them.

### Roles and permissions

For roles and permissions we use [Spatie's Laravel Permission](https://spatie.be/docs/laravel-permission/v6/introduction) package. This package allows you to manage user permissions and roles in a database.

To manage these roles and permissions in Nova, we use [Laravel Nova 4 Roles & Permissions](https://github.com/serenysoft/nova-permissions) package.

The Nova package comes with it's own policies for managing roles and permissions. We substitute these policies with our own, like not being able to delete or create permissions. This is done in the `NovaServiceProvider` when registering the tool.

[Return To Top](#hiil-cms)

### Target Audiences

With this app you can make separate problem identification flows for different target audiences. The slug of the target audiences is used in generating the full URL of the resource.
We hide the slug of the default target audience in the url.

For example, the URL for a questionnaire for a 'guest' should be `/questionnaire/example-questionnaire`,
but the URL for another questionnaire tailored for an 'employer' target audience should be `employer/example-questionnaire`.

We had to create a model for these because these target audiences should be made configurable per implementation. And the URLs should be multilingual.

We make sure only one target audience can be the default.

> [!IMPORTANT]
> In a previous version a user's uuid wasn't generated on user creation. If you have users in your database that have no uuid, you should use the artisan command `php artisan app:generate-missing-user-uuids`

### Form submissions

Form submissions are handled by the `/api/v1/submit-form` endpoint and is routed to the `App\FormhHandler\Http\Controllers\SubmitForm` controller. The configuration of the forms can be found in the `config/forms` folder. All form submissions will be saved in the form submissions table. Every 5 minutes the form submissions will be imported as Intakes, Referrals or Feedback in the respective databases.

### Macros

In the NovaServiceProvider we defined 1 macro. When you add new macro's please add them to this list.

`Text::displayAsFrontendLink()`

The `displayAsFrontendLink` macro is specific for the Nova Text Field. It displays the value as a link to the frontend url. The value of the field must be a relative path.

### Settings

We use Nova Settings for general content that will be used on multiple locations in the site. Each settings has a unique `key` and the value is multilingual.

For type safety of these keys in the frontend, there is a code generation step.

The keys that are used for the settings should be defined in the `app\SettingKey.php` file. This file is used to generate a TypeScript type for the frontend.
Use `composer generate-types` to generate the `type SettingKey` and copy it to the frontend.

After that define the fields in Nova. Nova Settings are defined in the NovaServiceProvider class and you organize them in groups. The fields groups are located in the `app\Nova\Settings` folder.

### Seeding settings.

Because default values for Nova Settings doesn't work when used when it's translatable. For this reason I have added a command to seed the settings.
`php artisan app:seed-settings`

## Resources

- [CMS Guide for HiiL](https://docs.google.com/presentation/d/1B1wlDbmuevDRz15YjAhmD6ZpJ0f6z9dNlqpYWoagTL4/edit?usp=sharing)

## Development

[Return To Top](#hiil-cms)

### Troubleshooting

### Prettier not working in VSCode

When using the Prettier extension in VSCode, prettier for PHP files might not work.
Make sure you add the following to your `settings.json`:

```json
{
    "prettier.documentSelectors": ["**/*.php"]
}
```

#### Unable to load FFProbe

When uploading videos in the CMS, you might get an error:

`Unable to load FFProbe`

The error might also be silent, but stills won't be generated from the uploaded video.

In both cases it's important to configure the path to FFMpeg and FFProbe in the `.env` file:

```
FFPROBE_PATH=/usr/local/bin/ffprobe
FFMPEG_PATH=/usr/local/bin/ffmpeg
```

You can find the correct paths by running:

```
which ffmpeg
```

and

```
which ffprobe
```

### Debugbar

When `APP_DEBUG` or `DEBUGBAR_ENABLED` is true the debugbar will be shown.

To support multiple nodes the logs are stored in the database (table `debugbar`). This generates a lot of data overtime. Enable Laravel Task Scheduling (see [docs](https://laravel.com/docs/11.x/scheduling)) to truncate that table every night at 01:00.

### History

See the git log and [TECHNICAL_SPECIFICATIONS.md](../TECHNICAL_SPECIFICATIONS.md) for background on the project.

### Testing

Create a `.env.testing` file by `cp .env.example .env.testing` and update the database credentials.

Run unit and feature tests by calling `composer test`. Parallel execution of the tests is enable. Disable it by removing the `--parallel` flag in `composer.json`, but it helps a lot in reducing execution time. [Freek van der Herten wrote about it](https://ohdear.app/blog/making-our-laravel-test-suite-ready-for-parallel-testing).

Change configuration in `phpunit.xml`.

### API

Run this command to show all API-endpoints:

```shell script
php artisan route:list | grep api/v1
```

### API Authentication

The frontend will need to have a token to authenticate with the API. So you need a to add a user with the 'View site content' permission and generate a token for this user. Use this token in the frontend to fetch data to generate the site.
